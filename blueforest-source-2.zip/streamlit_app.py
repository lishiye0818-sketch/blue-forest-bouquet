"""Community Cloud entrypoint for the unchanged Blue Forest application."""

import json
import os
from pathlib import Path
import sys

import streamlit as st

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from runtime.fetch_model import prepare_model
from runtime.state import prepare_state

os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")


@st.cache_resource(show_spinner="Preparing flower photo search. The first launch may take a few minutes…")
def prepare_host():
    database = prepare_state(ROOT, ROOT / ".blueforest-state")
    manifest = json.loads((ROOT / "runtime/model-manifest.json").read_text())
    model = prepare_model(ROOT / "models/clip", manifest)
    return str(database), str(model)


database, model = prepare_host()
os.environ["BLUEFOREST_MATERIAL_DB"] = database
os.environ["BLUEFOREST_CLIP_MODEL_DIR"] = model

from product_search.app.customer_app import main

main()
