"""Initialize persistent state once, then start the existing Streamlit app."""

import os
from pathlib import Path
import shutil
import sqlite3
import sys
from uuid import uuid4


def prepare_state(root, state_dir, database=None):
    root, state_dir = Path(root).resolve(), Path(state_dir).resolve()
    state_dir.mkdir(parents=True, exist_ok=True)
    database = Path(database).resolve() if database else state_dir / "flower_materials.sqlite3"
    database.parent.mkdir(parents=True, exist_ok=True)
    seed = root / "runtime/seed/flower_materials.sqlite3"
    if not database.exists():
        temporary = database.with_name(database.name + "." + uuid4().hex + ".tmp")
        try:
            with sqlite3.connect(f"file:{seed}?mode=ro", uri=True) as source, sqlite3.connect(temporary) as target:
                source.backup(target)
            # Never replace a database initialized by another process.
            try:
                os.link(temporary, database)
            except FileExistsError:
                pass
        finally:
            temporary.unlink(missing_ok=True)
    images = state_dir / "images"
    images.mkdir(exist_ok=True)
    for source in (root / "runtime/seed/images").rglob("*"):
        if source.is_file():
            target = images / source.relative_to(root / "runtime/seed/images")
            target.parent.mkdir(parents=True, exist_ok=True)
            if not target.exists():
                temporary = target.with_name(target.name + "." + uuid4().hex + ".tmp")
                try:
                    shutil.copyfile(source, temporary)
                    try:
                        os.link(temporary, target)
                    except FileExistsError:
                        pass
                finally:
                    temporary.unlink(missing_ok=True)
    local_images = root / "data/images"
    local_images.parent.mkdir(parents=True, exist_ok=True)
    if local_images.is_symlink():
        if local_images.resolve() != images:
            raise ValueError("data/images already points to another location; retain it for manual migration.")
    elif local_images.exists():
        raise ValueError("data/images already exists. Use the generated deployment package; no images were removed.")
    else:
        local_images.symlink_to(images, target_is_directory=True)
    (images / "material_uploads").mkdir(exist_ok=True)
    return database


def main():
    root = Path(__file__).resolve().parents[1]
    port = int(os.environ.get("PORT", "8501"))
    if not 1 <= port <= 65535:
        raise ValueError("PORT must be between 1 and 65535.")
    database = prepare_state(root, os.environ.get("BLUEFOREST_STATE_DIR", "/var/lib/blueforest"),
                             os.environ.get("BLUEFOREST_MATERIAL_DB"))
    os.environ["BLUEFOREST_MATERIAL_DB"] = str(database)
    os.environ.setdefault("BLUEFOREST_CLIP_MODEL_DIR", str(root / "models/clip"))
    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
    os.chdir(root)
    os.execv(sys.executable, [sys.executable, "-m", "streamlit", "run", "product_search/app/customer_app.py",
                             "--server.address=0.0.0.0", f"--server.port={port}", "--server.headless=true",
                             "--server.fileWatcherType=none", "--browser.gatherUsageStats=false"])


if __name__ == "__main__":
    main()
