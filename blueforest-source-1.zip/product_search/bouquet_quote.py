"""Internal mock material costing from human-entered quantities, never head counts."""

from decimal import Decimal, ROUND_HALF_UP

from product_search.custom_bouquet import validate_review

MOCK_QUOTE_NOTICE = "Mock quotation draft — For review only, not a supplier or customer quotation"
CENT = Decimal("0.01")


def money(value):
    return str(value.quantize(CENT, rounding=ROUND_HALF_UP))


def build_mock_quote(rows, materials, provenance):
    reviewed = validate_review(rows, materials)
    lookup = {material["id"]: material for material in materials}
    lines, issues = [], []
    subtotal = Decimal("0")
    has_quantity = False
    for row in reviewed:
        material = lookup.get(row["material_id"])
        quantity = row.get("Florist quantity")
        cost = Decimal(str(material["mock_unit_cost_hkd"])) if material else None
        amount = None
        if material is None:
            issues.append("Resolve Unknown material and its pricing unit.")
        elif quantity is None:
            issues.append(f"Enter a florist quantity for {row['Flower']}, or remove the row.")
        else:
            has_quantity = has_quantity or quantity > 0
            amount = (cost * Decimal(str(quantity))).quantize(CENT, rounding=ROUND_HALF_UP)
            subtotal += amount
        lines.append({
            "material_id": row["material_id"], "flower": row["Flower"],
            "quantity": quantity, "pricing_unit": row["pricing_unit"],
            "mock_unit_cost_hkd": money(cost) if cost is not None else None,
            "mock_line_cost_hkd": money(amount) if amount is not None else None,
            "notes": row.get("Florist notes", ""),
        })
    if not has_quantity:
        issues.append("Enter at least one positive florist quantity to prepare a material-cost draft.")
    return {
        "label": MOCK_QUOTE_NOTICE, "status": "incomplete" if issues else "draft",
        "currency": "HKD", "is_mock": True, "human_review_required": True,
        "provenance": provenance, "lines": lines,
        "known_materials_subtotal_hkd": money(subtotal),
        "complete_materials_total_hkd": None if issues else money(subtotal),
        "issues": issues,
        "exclusions": ["labour", "wrapping", "delivery", "markup", "tax", "supplier availability"],
    }


def quote_draft_text(quote):
    lines = [MOCK_QUOTE_NOTICE, quote["provenance"]["label"],
             f"Status: {quote['status']} · Currency: HKD", ""]
    for line in quote["lines"]:
        quantity = "unverified" if line["quantity"] is None else f"{line['quantity']:g}"
        cost = line["mock_unit_cost_hkd"]
        amount = line["mock_line_cost_hkd"]
        lines.append(f"{line['flower']}: {quantity} {line['pricing_unit']} · mock unit cost "
                     f"{('HK$' + cost) if cost is not None else 'unresolved'} · "
                     f"{('HK$' + amount) if amount is not None else 'not priced'}")
        if line["notes"]:
            lines.append(f"  Florist notes: {line['notes']}")
    lines.extend(["", f"Known mock material subtotal: HK${quote['known_materials_subtotal_hkd']}"])
    if quote["issues"]:
        lines.extend(["Incomplete — outstanding review:", *[f"- {issue}" for issue in quote["issues"]]])
    lines.extend(["", "Excludes " + ", ".join(quote["exclusions"]) + ".",
                  "Visible heads and filler usage were not converted into stems, bunches or portions.",
                  "Human review required. No final selling price or customer commitment is created."])
    return "\n".join(lines) + "\n"
