import hashlib
import csv
import json
import os
import tempfile
from pathlib import Path

from product_search.models.vector_db import VectorDatabase
from product_search.utils.images import local_image_path


def catalog_fingerprint(data_path):
    path = Path(data_path)
    digest = hashlib.sha256(path.read_bytes())
    # Local photos can change without a CSV edit. Include their content to avoid
    # serving vectors or session results built from previous image bytes.
    with path.open(encoding="utf-8-sig", newline="") as source:
        for row in csv.DictReader(source):
            value = (row.get("image") or row.get("product_images") or "").strip()
            if not value or "://" in value:
                continue
            try:
                image_path = local_image_path(value, path.resolve().parent)
            except ValueError:
                continue  # The data loader reports invalid image paths.
            digest.update(value.encode())
            digest.update(image_path.read_bytes() if image_path.is_file() else b"missing")
    return digest.hexdigest()


def index_key(data_path, kind, model_id):
    signature = {"catalog": catalog_fingerprint(data_path), "kind": kind,
                 "model": model_id, "preprocessing": 1, "task": "text" if kind == "text" else "image"}
    return hashlib.sha256(json.dumps(signature, sort_keys=True).encode()).hexdigest()


def load_or_build(data_path, df, indexes_dir, kind, model_id, generator_factory):
    key = index_key(data_path, kind, model_id)
    root = Path(indexes_dir)
    destination = root / key
    db = VectorDatabase()
    if destination.exists():
        db.load_indices(destination)
        return db, json.loads((destination / "build.json").read_text())
    generator = generator_factory()
    if kind == "text":
        vectors = generator.generate_text_embedding(df["text_for_embedding"].tolist())
        db.add_text_embeddings(vectors, list(range(len(df))))
        db.set_product_texts(df["text_for_embedding"].tolist())
        failed = []
        count = len(df)
    elif kind == "image":
        vectors, ids, failed = generator.generate_batch_image_embeddings(df["image_url"].tolist(), root / "images")
        if not ids:
            raise ValueError("No catalog images could be indexed. Check the image URLs and network connection.")
        db.add_image_embeddings(vectors, ids)
        count = len(ids)
    else:
        raise ValueError("Index kind must be text or image.")
    report = {"kind": kind, "model": model_id, "catalog_sha256": catalog_fingerprint(data_path),
              "indexed": count, "total": len(df), "failed_image_ids": failed}
    root.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="build-", dir=root) as staging:
        db.save_indices(staging)
        (Path(staging) / "build.json").write_text(json.dumps(report, indent=2))
        try:
            os.rename(staging, destination)
        except OSError:
            if not destination.exists():
                raise
    return db, report
