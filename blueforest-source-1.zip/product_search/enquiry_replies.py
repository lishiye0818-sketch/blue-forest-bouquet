"""Private inline Staff drafts and explicit, versioned customer replies."""

from copy import deepcopy
import hashlib
import json

from product_search.app.enquiry_session import publish_proposal, queue, save_workspace, update_alias
from product_search.material_store import amount
from product_search.selling_pricing import calculate_selling_price


def use_inline_replies(state):
    """Adopt existing session enquiries without repricing or publishing anything."""
    for record in queue(state).values():
        record["reply_mode"] = "inline"
    if state.get("staff_loaded_enquiry"):
        # Retain any older editor draft without publishing it during adoption.
        save_workspace(state)
        state.pop("staff_loaded_enquiry", None)


def reply_materials(record, catalog):
    """Keep captured units/prices for requested flowers; use current new choices."""
    source = reply_source(record)
    snapshot = source.get("price_snapshot") or record["submitted"].get("price_snapshot") or {}
    captured = {row.get("id", row.get("material_id")): row
                for row in (record.get("design") or {}).get("materials", [])}
    lookup = {row["id"]: deepcopy(row) for row in catalog}
    for line in snapshot.get("lines", []):
        material_id = line["material_id"]
        row = lookup.get(material_id) or deepcopy(captured.get(material_id, {}))
        row.update(id=material_id, material_id=material_id, name=line["flower"], name_en=line["flower"],
                   pricing_unit=line["pricing_unit"], unit_selling_price_hkd=line["unit_selling_price_hkd"])
        row.setdefault("name_zh", "")
        row.setdefault("display_category", "Main Flower")
        row.setdefault("reference_image", row.get("image_path", ""))
        row.setdefault("is_active", False)
        lookup[material_id] = row
    return list(lookup.values())


def reply_source(record):
    if record.get("proposal"):
        return record["proposal"]["public"]
    if record.get("customer_response", {}).get("decision") == "changes_requested" and record.get("proposal_history"):
        return record["proposal_history"][-1]["public"]
    return record["public"]


def reply_draft(record, catalog):
    if record.get("reply_draft") is not None:
        record["reply_draft"].setdefault("base_counter", record["proposal_counter"])
        record["reply_draft"].setdefault("generation", record.get("reply_draft_generation", 0))
        return record["reply_draft"]
    source = reply_source(record)
    materials = reply_materials(record, catalog)
    lines = (source.get("price_snapshot") or {}).get("lines", [])
    quantities = {line["material_id"]: line["quantity"] for line in lines}
    if not lines and source["option"] == "B":
        names = {row["name"]: row["id"] for row in materials}
        for index, flower in enumerate(source.get("flowers", [])):
            material_id = names.get(flower["flower"])
            if material_id is None:
                # Unmapped historical flowers remain visible and removable,
                # rather than silently disappearing from an older enquiry.
                material_id = f"legacy_{index}"
                materials.append(dict(id=material_id, material_id=material_id, name=flower["flower"],
                                      name_en=flower["flower"], name_zh="", pricing_unit=flower["unit"],
                                      display_category="Main Flower", reference_image="", is_active=False,
                                      unit_selling_price_hkd=None))
            quantities[material_id] = flower["quantity"]
    record["reply_draft_generation"] = record.get("reply_draft_generation", 0) + 1
    draft = {"materials": materials, "quantities": quantities, "message": "", "manual_price": False,
             "generation": record["reply_draft_generation"],
             "provenance": deepcopy((source.get("price_snapshot") or {}).get("provenance") or
                                     (record.get("design") or {}).get("provenance") or {}),
             "final_price": source.get("price_hkd"), "base_version": record.get("proposal", {}).get("version"),
             "base_counter": record["proposal_counter"],
             "product": deepcopy(record.get("offered_bouquet") or record.get("bouquet") or source.get("bouquet"))}
    if source["option"] == "B":
        try:
            calculated = calculate_reply(draft)["total_selling_price_hkd"]
            draft["manual_price"] = amount(draft["final_price"], "Final quoted price") != calculated
        except ValueError:
            draft["manual_price"] = True
    record["reply_draft"] = draft
    return draft


def calculate_reply(draft):
    quote = calculate_selling_price([{"material_id": key, "quantity": value}
                                     for key, value in draft["quantities"].items()], draft["materials"], draft.get("provenance"))
    if not quote["lines"]:
        raise ValueError("Please select at least one flower with a positive quantity.")
    return quote


def submit_reply(state, reference, draft):
    """Publish only on Submit reply; preserve previous versions and reject stale edits."""
    record = queue(state)[reference]
    if record["workflow_status"] in ("cancelled", "completed"):
        raise ValueError("This enquiry is closed. Its quotation cannot be changed.")
    message = str(draft["message"]).strip()
    if len(message) > 1000:
        raise ValueError("The reply must be at most 1,000 characters.")
    public = deepcopy(record["submitted"])
    if public["option"] == "B":
        quote = calculate_reply(draft)
        final_price = amount(draft["final_price"], "Final quoted price") if draft["manual_price"] else quote["total_selling_price_hkd"]
        # Keep the shared SUM formula intact. Only this version's final reviewed
        # amount can differ, explicitly labelled in quotation summaries.
        quote["final_reviewed_price_hkd"] = final_price
        quote["price_override"] = final_price != quote["total_selling_price_hkd"]
        public.update(price_snapshot=quote, price_hkd=final_price, status="quotation_approved_mock",
                      price_label="Florist-reviewed price",
                      quotation={"final_reviewed_price_hkd": final_price,
                                 "delivery_notes": reply_source(record).get("quotation", {}).get("delivery_notes", "")},
                      flowers=[{"flower": line["flower"], "quantity": line["quantity"], "unit": line["pricing_unit"]}
                               for line in quote["lines"]])
    else:
        product = draft["product"]
        if product.get("price_hkd") is None:
            raise ValueError("Choose a bouquet with a confirmed selling price.")
        public.update(bouquet={key: product[key] for key in ("id", "name", "price_hkd")},
                      price_hkd=amount(product["price_hkd"], "Bouquet selling price"), status="reviewed_mock")
        if product.get("price_snapshot"):
            public["price_snapshot"] = deepcopy(product["price_snapshot"])
    public["proposal_notes"] = message
    submission = hashlib.sha256(json.dumps([draft["base_version"], draft["base_counter"], public], sort_keys=True).encode()).hexdigest()
    if record.get("last_reply_submission") == submission:
        return  # A repeated callback must not duplicate versions or history.
    if (draft["base_version"] != record.get("proposal", {}).get("version")
            or draft["base_counter"] != record["proposal_counter"]):
        raise ValueError("This enquiry has changed. Reopen it before submitting another reply.")
    previous = record.get("proposal")
    # Persist first: database failure must leave the in-session proposal intact.
    publish_proposal(record, public)
    if previous:
        record.setdefault("proposal_history", []).append(deepcopy(previous))
    if public["option"] == "A":
        record["offered_bouquet"] = deepcopy(draft["product"])
    record["reply_mode"] = "inline"
    record["last_reply_submission"] = submission
    record.pop("reply_draft", None)
    update_alias(state, record)
