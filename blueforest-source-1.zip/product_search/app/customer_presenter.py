"""Customer view models. Existing review, pricing and quotation rules stay authoritative."""

from uuid import uuid4
import re

from product_search.custom_bouquet import review_rows, validate_review
from product_search.selling_pricing import calculate_selling_price


def history_with_messages(history, proposals=()):
    """Recover earlier public replies from saved proposals without rewriting history.

    New events hold their own reply snapshot. Older sessions have ordered proposal
    archives; align their proposal events from the end because the first legacy
    proposal may predate event recording. Never apply the latest reply to all rows.
    """
    snapshots = {proposal["version"]: proposal for proposal in proposals if proposal}
    ready = [index for index, item in enumerate(history) if item["action"] == "Proposal ready for confirmation"]
    legacy = dict(zip(ready[-len(snapshots):], list(snapshots.values())[-len(ready):]))
    items = []
    for index, event in enumerate(history):
        item = dict(event)
        if item["action"] == "Proposal ready for confirmation" and item.get("actor") == "Staff":
            snapshot = (snapshots.get(item["proposal_version"]) if item.get("proposal_version") else legacy.get(index))
            if "florist_message" not in item and snapshot:
                item["florist_message"] = snapshot["public"].get("proposal_notes", "")
        items.append(item)
    return items


def customer_history(history, proposals=()):
    """Public progress, selling prices, replies, change messages and cancellation reasons.

    Do not pass arbitrary staff audit events or their free-text details to the
    customer, including events introduced by a future staff workflow.
    """
    actions = {"Enquiry submitted": "Enquiry submitted", "Processing started": "Florist review started",
               "Proposal ready for confirmation": "Proposal ready for confirmation",
               "Proposal withdrawn for review": "Proposal being updated",
               "Proposal confirmed · Enquiry completed": "Proposal confirmed",
               "Changes requested": "Changes requested", "Enquiry cancelled": "Enquiry cancelled"}
    items = []
    for event in history_with_messages(history, proposals):
        action = event.get("action")
        if action not in actions:
            continue
        item = {"action": actions[action], "at": event["at"],
                "actor": "You" if action in ("Enquiry submitted", "Changes requested", "Enquiry cancelled",
                                             "Proposal confirmed · Enquiry completed") else "Florist",
                "detail": ""}
        if action == "Enquiry cancelled" and event.get("actor") == "Staff":
            item["actor"] = "Florist"
        if action == "Proposal ready for confirmation" and re.fullmatch(r"HK\$\d+(?:\.\d{1,2})?", event.get("detail", "")):
            item["detail"] = event["detail"]
        elif action == "Changes requested" and event.get("actor") == "Customer":
            item["detail"] = event.get("detail", "")
        elif action == "Enquiry cancelled" and event.get("actor") in ("Staff", "Customer"):
            item["detail"] = event.get("cancellation_reason", "")
        if action == "Proposal ready for confirmation" and event.get("actor") == "Staff" and event.get("florist_message"):
            item["florist_message"] = event["florist_message"]
        items.append(item)
    return items


def requested_rows(materials, analysis, quantities):
    rows = review_rows(materials, analysis)
    ids = {material["name"]: material["id"] for material in materials}
    return [{"Flower": row["Flower"], "Quantity": quantities.get(ids.get(row["Flower"]))} for row in rows]


def review_from_request(records, materials, analysis):
    """Map desired quantities to review inputs, keeping observed counts separate."""
    observations = {row["Flower"]: row for row in review_rows(materials, analysis)}
    rows = []
    for record in records:
        observation = observations.get(record.get("Flower"), {})
        rows.append({"Flower": record.get("Flower"),
                     "Reviewed visible count": observation.get("Reviewed visible count"),
                     "Filler usage": observation.get("Filler usage"),
                     "Florist quantity": record.get("Quantity"), "Florist notes": ""})
    return validate_review(rows, materials)


def preliminary_price(rows, materials, provenance):
    try:
        return calculate_selling_price(rows, materials, provenance)["total_selling_price_hkd"]
    except ValueError:
        return None


def customer_flowers(rows):
    return [{"flower": row["Flower"], "quantity": row["Florist quantity"], "unit": row["pricing_unit"]}
            for row in rows]


def public_preferences(preferences):
    name = str(preferences.get("name", "")).strip()
    contact = str(preferences.get("contact", "")).strip()
    if not name or not contact:
        raise ValueError("Please enter a name and a demo email or phone number.")
    if preferences.get("fulfilment") == "Delivery" and not str(preferences.get("address", "")).strip():
        raise ValueError("Please enter a delivery area or address, or choose Collection.")
    return {key: str(preferences.get(key, "")).strip() for key in
            ("name", "contact", "fulfilment", "date", "address", "preferences")}


def pending_custom_enquiry(*, photo_sha256, preferences, amount, flowers):
    """Submit a request for review, without representing an approved quotation."""
    if not flowers:
        raise ValueError("Please add at least one flower to your bouquet.")
    return {"reference": f"BF-B-{uuid4().hex[:8].upper()}", "is_mock": True,
            "label": "Mock Data — Local demo enquiry", "status": "awaiting_florist_review",
            "option": "B", "photo_sha256": photo_sha256, "currency": "HKD", "price_hkd": amount,
            "price_label": "Preliminary estimate · Pending florist review",
            "preferences": public_preferences(preferences),
            "flowers": [{key: row[key] for key in ("flower", "quantity", "unit")} for row in flowers]}


def mock_enquiry(option, *, photo_sha256, preferences, amount, bouquet=None, flowers=None, quotation=None):
    """An explicit public projection: never serialize internal pricing or reviews."""
    if option not in ("A", "B") or (option == "A" and not bouquet):
        raise ValueError("Please select a bouquet before creating an enquiry.")
    if option == "B":
        if (not quotation or quotation.get("status") != "finalized_mock"
                or quotation.get("florist_review", {}).get("approved") is not True):
            raise ValueError("A florist must confirm your custom bouquet before you create an enquiry.")
        amount = quotation["final_reviewed_price_hkd"]
    result = {"reference": f"BF-{option}-{uuid4().hex[:8].upper()}", "is_mock": True,
              "label": "Mock Data — Local demo enquiry", "status": "enquiry_created_mock",
              "option": option, "photo_sha256": photo_sha256, "currency": "HKD", "price_hkd": amount,
              "price_label": "Mock catalog price" if option == "A" else "Florist-reviewed mock price",
              "preferences": public_preferences(preferences)}
    if bouquet:
        result["bouquet"] = {key: bouquet[key] for key in ("id", "name", "price_hkd")}
    if flowers is not None:
        result["flowers"] = [{key: flower[key] for key in ("flower", "quantity", "unit")} for flower in flowers]
    if quotation:
        result["quotation"] = {key: quotation[key] for key in ("final_reviewed_price_hkd", "delivery_notes")}
    return result
