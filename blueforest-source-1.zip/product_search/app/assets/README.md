# Homepage image

`blue-forest-floral-hero.png` is the original floral photograph supplied by the
user for the Phase 4D homepage. It is copied without alteration from the provided
attachment. The application serves it locally and applies a CSS overlay for text
contrast. No additional licence or creator attribution was supplied; this file
is not part of the licensed retrieval catalogue or the recognition fixtures.
