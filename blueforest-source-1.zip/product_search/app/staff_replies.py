"""Reply and edit the current enquiry in one place, using existing flower rows."""

import sqlite3

import streamlit as st

from product_search.app.flower_materials import add_flower, selected_material_rows
from product_search.enquiry_replies import calculate_reply, reply_draft, submit_reply
from product_search.shop_bouquets import shop_products


def remember_field(draft, field, key):
    draft[field] = st.session_state[key]
    if field == "final_price":
        draft["manual_price"] = True


def use_calculated_price(draft):
    draft["manual_price"] = False


def publish_reply(reference, draft):
    try:
        submit_reply(st.session_state, reference, draft)
    except (ValueError, OSError, sqlite3.Error) as exc:
        st.session_state.staff_reply_error = {"reference": reference, "message": str(exc)}
    else:
        st.session_state.pop("staff_reply_error", None)


def choose_product(draft, key, products):
    draft["product"] = next(row for row in products if row["id"] == st.session_state[key])


def staff_reply_editor(record, materials, *, actions):
    if record["workflow_status"] in ("completed", "cancelled"):
        return
    reference = record["reference"]
    draft = reply_draft(record, materials)
    prefix = f"staff_reply_{reference}_{record['proposal_counter']}"
    if st.session_state.get(prefix + "_context") != draft["generation"]:
        # Customer change requests can replace a private draft without advancing
        # the proposal counter. Do not reuse the old draft's widget values.
        for key in list(st.session_state):
            if key.startswith((prefix + "_quantity_", prefix + "_replacement_")):
                st.session_state.pop(key, None)
        st.session_state[prefix + "_price"] = draft["final_price"] or ""
        st.session_state[prefix + "_message"] = draft["message"]
        if draft["product"]:
            st.session_state[prefix + "_bouquet"] = draft["product"]["id"]
        st.session_state[prefix + "_context"] = draft["generation"]
    error = st.session_state.get("staff_reply_error", {})
    if error.get("reference") == reference:
        st.error(error["message"])
    st.subheader("Reply to customer")
    valid = True
    if record["submitted"]["option"] == "B":
        draft_key = prefix + "_materials"
        st.session_state[draft_key] = draft["quantities"]
        lookup = {row["id"]: row for row in draft["materials"]}
        with st.expander("Edit flowers & quantities"):
            st.caption("Changes apply to this enquiry. Quantities use the unit shown.")
            selected_material_rows(lookup, draft_key=draft_key, prefix=prefix)
            choices = [key for key in lookup if key not in draft["quantities"] and lookup[key]["is_active"]]
            if choices:
                with st.popover("Add material"):
                    chosen = st.selectbox("Flower material", choices, key=prefix + "_add_choice",
                                          format_func=lambda key: lookup[key]["name"])
                    st.button("Add to quotation", key=prefix + "_add", on_click=add_flower,
                              args=(chosen, draft_key, prefix))
        try:
            quote = calculate_reply(draft)
            calculated = quote["total_selling_price_hkd"]
            if not draft["manual_price"]:
                draft["final_price"] = calculated
                st.session_state[prefix + "_price"] = calculated
            st.caption("Calculated material price · HK$" + calculated)
        except ValueError as exc:
            st.info(str(exc))
            valid = False
        st.session_state.setdefault(prefix + "_price", draft["final_price"] or "")
        st.text_input("Final quoted price (HKD)", key=prefix + "_price", on_change=remember_field,
                      args=(draft, "final_price", prefix + "_price"))
        if draft["manual_price"]:
            st.caption("This final amount is set by Staff for this quotation.")
            st.button("Use calculated price", key=prefix + "_calculate", on_click=use_calculated_price, args=(draft,))
    else:
        products = [row for row in shop_products() if row["price_hkd"] is not None]
        product = draft["product"]
        # Retain the captured bouquet and price until Staff explicitly chooses a different design.
        products = [product, *[row for row in products if row["id"] != product["id"]]]
        st.selectbox("Proposed bouquet", [row["id"] for row in products], key=prefix + "_bouquet",
                     index=0, format_func=lambda key: next(row["name"] + f" · HK${row['price_hkd']:.2f}"
                                                           for row in products if row["id"] == key),
                     on_change=choose_product, args=(draft, prefix + "_bouquet", products))
    st.session_state.setdefault(prefix + "_message", draft["message"])
    st.text_area("Message for customer (optional)", key=prefix + "_message", max_chars=1000,
                 on_change=remember_field, args=(draft, "message", prefix + "_message"))
    actions.button("Submit reply", type="primary", key=prefix + "_submit", disabled=not valid,
                   on_click=publish_reply, args=(reference, draft))
