"""Small public selling-price panels; reuse the established quotation approval UI."""

from html import escape

import streamlit as st

from product_search.app.bouquet_pricing import invalidate_pricing, render_quotation_approval
from product_search.app.flower_materials import card_thumbnail
from product_search.bouquet_pricing import signature
from product_search.utils.images import local_image_path


def render_selling_summary(quote, *, title="Bouquet selling price", compact=False, materials=None):
    by_id = {row.get("id", row.get("material_id")): row for row in materials or []}
    rows = []
    for line in quote["lines"]:
        visual = ''
        if materials is not None:
            material = by_id.get(line.get("material_id"), {})
            image_path = material.get("reference_image") or material.get("image_path")
            try:
                source = local_image_path(image_path)
                thumbnail = card_thumbnail(image_path, source.stat().st_mtime_ns, size=(80, 80))
            except (OSError, ValueError, TypeError):
                thumbnail = None
            visual = ('<img class="selling-line-image" width="40" height="40" src="' + thumbnail +
                      '" alt="' + escape(line["flower"], quote=True) + '" loading="lazy">' if thumbnail else
                      '<div class="selling-line-image selling-line-placeholder" role="img" '
                      'aria-label="Photo coming soon">—</div>')
        rows.append('<li><div class="selling-line-material">' + visual +
                    '<div class="selling-line-copy"><strong>' + escape(line["flower"]) + '</strong><span>' +
                    str(line["quantity"]) + ' ' + escape(line["pricing_unit"]) + ' × HK$' +
                    escape(line["unit_selling_price_hkd"]) + '</span></div></div><b>HK$' +
                    escape(line["line_subtotal_hkd"]) + '</b></li>')
    breakdown = '<ul>' + ''.join(rows) + '</ul>'
    if compact:
        breakdown = ('<details><summary>' + str(len(rows)) + ' materials · Price breakdown</summary>' +
                     breakdown + '</details>')
    extra_class = ' selling-summary--compact' if compact else ''
    final = quote.get("final_reviewed_price_hkd", quote["total_selling_price_hkd"])
    override = final != quote["total_selling_price_hkd"]
    reviewed_total = ('<div class="selling-total"><strong>Final quoted price</strong><strong>HK$' +
                      escape(final) + '</strong></div>' if override else '')
    st.html('<section class="selling-summary' + extra_class + '" aria-label="Selling price summary" aria-live="polite">'
            '<h3>' + escape(title) + '</h3>' + breakdown +
            '<div class="selling-total"><strong>' + ('Calculated material price' if override else 'Total') + '</strong><strong>HK$' +
            escape(quote["total_selling_price_hkd"]) + '</strong></div>' + reviewed_total + '</section>')


def render_selling_workflow(quote, *, show_quotation, actions=None):
    context = signature(quote)
    if st.session_state.get("phase3b_material_context") != context:
        invalidate_pricing()
        st.session_state.phase3b_material_context = context
    st.subheader("Quotation" if show_quotation else "Materials & selling price")
    render_selling_summary(quote)
    st.session_state.phase3b_final_price = quote["total_selling_price_hkd"]
    st.text_input("Calculated selling price (HKD)", value=None, key="phase3b_final_price", disabled=True)
    st.session_state.setdefault("phase3b_delivery_notes", "Collection at the shop; date to be confirmed.")
    delivery_notes = st.text_input("Delivery or collection notes", value=None,
                                   key="phase3b_delivery_notes", max_chars=2000)
    if show_quotation:
        render_quotation_approval(quote, delivery_notes, presentation=True, actions=actions)
