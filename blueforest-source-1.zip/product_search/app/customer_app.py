"""Two independent customer journeys with a separate local staff demonstration."""

import base64
from datetime import datetime
from zoneinfo import ZoneInfo
from copy import deepcopy
import hashlib
import sqlite3
from html import escape
from pathlib import Path
from urllib.parse import quote

import streamlit as st
from PIL import ImageOps

from product_search.app.customer_presenter import (
    customer_flowers, customer_history, history_with_messages, mock_enquiry, pending_custom_enquiry,
    preliminary_price, requested_rows, review_from_request,
)
from product_search.app.enquiry_session import (
    WORKFLOW_LABELS, add_enquiry, cancel_enquiry, confirm_proposal, customer_enquiry, filtered_enquiries,
    point_customer_at, queue, request_proposal_changes, workflow_counts,
)
from product_search.app.flower_materials import customer_material_picker, staff_materials
from product_search.app.page_actions import page_header, page_navigation
from product_search.app.selling_prices import render_selling_summary
from product_search.app.staff_replies import staff_reply_editor
from product_search.enquiry_replies import use_inline_replies
from product_search.app.presentation_app import PRICING_INPUT_KEYS, local_model
from product_search.bouquet_pricing import signature
from product_search.config import ROOT
from product_search.custom_bouquet import prepare_photo
from product_search.customer_demo import load_customer_samples, match_customer_photo
from product_search.material_store import initialize_database, list_materials, pricing_materials
from product_search.selling_pricing import calculate_selling_price
from product_search.shop_bouquets import initialize_shop_bouquets, shop_products
from product_search.shop_search import (
    SHOP_EMBEDDING_METHOD, search_shop_bouquets, searchable_shop_products, shop_catalog_fingerprint,
)
from product_search.utils.images import local_image_path, load_image

NAV = ["Home", "Find Similar", "Custom Bouquet", "Your enquiries"]
A_STAGES = ["photo", "results", "details", "enquiry", "success"]
B_STAGES = ["photo", "composition", "estimate", "enquiry", "success"]


def navigate(page, stage=None):
    clear_customer_enquiry()
    st.session_state.shop_nav = page
    if stage:
        st.session_state["shop_a_stage" if page == "Find Similar" else "shop_b_stage"] = stage


def move(option, stage):
    st.session_state[f"shop_{option}_stage"] = stage


def reset_photo_work():
    for key in list(st.session_state):
        if key.startswith(("shop_a_", "shop_b_", "shop_form_")):
            st.session_state.pop(key, None)


def choose_photo(raw, source, samples):
    try:
        prepare_photo(raw)
    except ValueError as exc:
        reset_photo_work()
        st.session_state.pop("shop_photo", None)
        st.session_state.shop_photo_error = str(exc)
        return
    digest = hashlib.sha256(raw).hexdigest()
    if st.session_state.get("shop_photo", {}).get("sha256") != digest:
        had_design = "shop_b_material_draft" in st.session_state
        reset_photo_work()
        if had_design:
            st.session_state.shop_b_reference_reset = True
    sample = next((sample for sample in samples if sample["sha256"] == digest), None)
    st.session_state.shop_photo = {"raw": raw, "sha256": digest,
                                   "name": sample["name"] if sample else "Your reference bouquet", "source": source}
    st.session_state.pop("shop_photo_error", None)


def choose_sample(sample, samples):
    choose_photo(local_image_path(sample["photo"]).read_bytes(), "Demo sample", samples)
    st.session_state.shop_upload_generation = st.session_state.get("shop_upload_generation", 0) + 1


def upload_photo(key, samples):
    uploaded = st.session_state.get(key)
    if uploaded is None:
        clear_photo()
    else:
        choose_photo(uploaded.getvalue(), "Your photo", samples)


def clear_photo():
    reset_photo_work()
    st.session_state.pop("shop_photo", None)
    st.session_state.pop("shop_photo_error", None)
    st.session_state.shop_upload_generation = st.session_state.get("shop_upload_generation", 0) + 1


def money(amount):
    return f"HK${float(amount):,.2f}"


def show_image(source, size=(600, 420), *, caption=None, crop=False):
    image = prepare_photo(source) if isinstance(source, bytes) else load_image(str(source), ROOT / "indexes/images")
    image = ImageOps.fit(image, size, centering=(.5, .35)) if crop else ImageOps.pad(image, size, color="#ECEEE5")
    st.image(image, width="stretch", caption=caption)


def show_reference_photo(photo, size=(420, 340), *, natural=False):
    if photo:
        if natural:
            st.image(prepare_photo(photo["raw"]), width="stretch")
        else:
            show_image(photo["raw"], size)
    else:
        st.html('<div class="shop-no-reference"><strong>Your custom bouquet</strong>'
                '<p>Designed without a reference photo</p></div>')


def credits():
    with st.popover("About & credits"):
        attribution = (ROOT / "data/PRESENTATION_IMAGE_CREDITS.md").read_text()
        # Show photography attribution; keep the academic presentation notes in
        # the source document rather than the customer interface.
        _, separator, photography = attribution.partition("\n## ")
        if separator:
            attribution = "## " + photography
        st.markdown(attribution.replace("[IMAGE_CREDITS.md](IMAGE_CREDITS.md)", "the catalogue credits download below"))
        st.download_button("Download catalogue photography credits", (ROOT / "data/IMAGE_CREDITS.md").read_text(),
                           file_name="blue-forest-photography-credits.md", mime="text/markdown", key="shop_photography_credits")


def header(*, landing=False):
    with st.container(key="shop_header"):
        staff = st.session_state.shop_role == "Staff"
        columns = st.columns([4.05, 1] if staff else [1.4, 2.65, 1],
                             gap="medium", vertical_alignment="center")
        brand, profile = columns[0], columns[-1]
        with brand:
            st.html('<header class="shop-brand' + (' shop-landing' if landing else '') + '">'
                    '<span class="brand-leaf" aria-hidden="true"><i></i><i></i></span>'
                    '<div><strong>blue forest</strong><span>florist</span></div></header>')
        if not staff:
            with columns[1]:
                navigation()
        with profile, st.container(key="shop_profile"):
            with st.popover(st.session_state.shop_role, icon=":material/person_outline:", key="shop_profile_menu"):
                picker = f"shop_role_picker_{st.session_state.get('shop_role_generation', 0)}"
                st.radio("View as", ["Customer", "Staff"], index=0 if st.session_state.shop_role == "Customer" else 1,
                         key=picker, on_change=change_role, args=(picker,),
                         captions=["Browse and order bouquets", "Manage enquiries and quotations"],
                         label_visibility="collapsed")


def navigation():
    st.radio("Main navigation", NAV, horizontal=True,
             key="shop_nav", label_visibility="collapsed", width="stretch", on_change=clear_customer_enquiry)


def clear_customer_enquiry():
    st.session_state.pop("shop_customer_enquiry_reference", None)


def release_staff_workspace():
    st.session_state.pop("staff_loaded_enquiry", None)


def open_materials():
    release_staff_workspace()
    st.session_state.staff_nav = "Flower Materials"


def change_role(picker):
    # Keep the active role outside the popover widget: closed popovers can retain
    # old client-side values after a programmatic return to Customer. A fresh
    # picker generation prevents that stale value from changing the next page.
    st.session_state.shop_role = st.session_state[picker]
    st.session_state.shop_role_generation = st.session_state.get("shop_role_generation", 0) + 1
    if st.session_state.shop_role == "Customer":
        st.session_state.pop("staff_loaded_enquiry", None)
    st.session_state.setdefault("staff_nav", "Dashboard")
    st.query_params.pop("workspace", None)
    st.query_params.pop("demo_role", None)


def open_customer_enquiry(reference):
    point_customer_at(st.session_state, reference)
    navigate("Your enquiries")
    st.session_state.shop_customer_enquiry_reference = reference


def open_staff_enquiry(reference, page="Customer Enquiries", task=None):
    release_staff_workspace()
    st.session_state.staff_active_enquiry = reference
    st.session_state.staff_detail_reference = reference
    st.session_state.staff_nav = "Customer Enquiries"


@st.cache_data(show_spinner=False)
def hero_background():
    # Serve the supplied photograph locally; no remote image or model requests.
    photo = Path(__file__).with_name("assets") / "blue-forest-floral-hero.png"
    return "data:image/png;base64," + base64.b64encode(photo.read_bytes()).decode("ascii")


def home(samples):
    st.html('<section class="shop-hero" aria-labelledby="hero-headline">'
            f'<img class="shop-hero-photo" src="{hero_background()}" alt="" loading="eager" fetchpriority="high">'
            '<div class="shop-hero-content"><h1 id="hero-headline">Every Bouquet Begins With an Idea</h1>'
            '<p>Upload your inspiration and discover the perfect bouquet for your occasion.</p>'
            '<a class="shop-hero-cta" href="#shop-flowers">Shop Flowers</a></div></section>')
    with st.container(key="shop_choices"):
        st.html('<div class="shop-choice-heading" id="shop-flowers" tabindex="-1">'
                '<h2>How would you like to begin?</h2>'
                '<p>Two ways to find your bouquet. Choose the one that suits your idea.</p></div>')
        for column, option, sample in zip(st.columns(2, gap="large"), ("a", "b"), samples):
            with column, st.container(border=True, key=f"shop_home_{option}"):
                show_image(local_image_path(sample["photo"]), (760, 260), crop=True)
                title = "Find Similar Bouquets" if option == "a" else "Create Your Own Bouquet"
                st.subheader(title)
                description = ("Find existing bouquets based on your reference image." if option == "a" else
                               "Analyse your reference image and create a customised bouquet.")
                st.html(f'<p class="shop-choice-copy">{description}</p>')
                st.button(title, key=f"shop_home_{option}_open", type="primary", width="stretch",
                          on_click=navigate, args=("Find Similar" if option == "a" else "Custom Bouquet",))


def customer_enquiries():
    records = queue(st.session_state)
    reference = st.session_state.get("shop_customer_enquiry_reference")
    if reference in records:
        point_customer_at(st.session_state, reference)
        enquiry_confirmation(records[reference]["public"]["option"].lower())
        return
    st.title("Your enquiries")
    if not records:
        st.info("You haven't made an enquiry yet. Explore our bouquets or create your own to get started.")
        return
    for record in reversed(list(records.values())):
        public = record["public"]
        summary, action = st.columns([3, 1], vertical_alignment="center")
        with summary:
            st.write(f"**{public['reference']}** · " + (public.get("bouquet", {}).get("name") or "Custom bouquet"))
            status_badge(public)
        with action:
            st.button("View status", key="shop_view_" + record["reference"],
                      on_click=open_customer_enquiry, args=(record["reference"],))


def journey(option, stage):
    labels = (["Reference Photo", "Similar Bouquets", "Bouquet Selection", "Preferences", "Enquiry Ready"]
              if option == "a" else
              ["Reference Photo", "Flower Composition", "Estimated Price", "Preferences", "Enquiry Status"])
    stages = A_STAGES if option == "a" else B_STAGES
    current = stages.index(stage)
    items = "".join(f'<li class="{"active" if i == current else "done" if i < current else ""}"'
                    f'{" aria-current=\"step\"" if i == current else ""}>{label}</li>'
                    for i, label in enumerate(labels))
    st.html('<nav aria-label="' + ("Existing bouquet" if option == "a" else "Custom bouquet") +
            ' journey"><ul class="shop-steps">' + items + '</ul></nav>')


def photo_picker(samples):
    selected = st.session_state.get("shop_photo")
    if selected:
        with st.container(key="shop_reference"):
            preview, actions = st.columns([1, 1.16], gap="large", vertical_alignment="center")
            with preview, st.container(border=True, key="shop_reference_photo"):
                st.image(prepare_photo(selected["raw"]), width="stretch")
            with actions:
                st.html('<div class="shop-reference-copy"><h1>Your reference is ready</h1>'
                        '<p>Use this photo for either bouquet option. You can switch between them in the navigation above.</p></div>')
                photo_controls(samples, selected=True)
    else:
        photo_controls(samples, selected=False)
    if st.session_state.get("shop_photo_error"):
        st.error(st.session_state.shop_photo_error)
    return selected


def photo_controls(samples, *, selected):
    with st.expander("Change reference photo" if selected else "Choose a reference photo", expanded=not selected):
        upload, example = st.columns([1.2, 1], gap="medium")
        with upload:
            key = f"shop_upload_{st.session_state.get('shop_upload_generation', 0)}"
            st.file_uploader("Upload a bouquet photo", type=["jpg", "jpeg", "png"], key=key,
                             max_upload_size=15, on_change=upload_photo, args=(key, samples))
            st.caption("JPG or PNG · Up to 15 MB")
        for sample in samples[:1]:
            with example:
                show_image(local_image_path(sample["photo"]), (480, 230))
                st.markdown(f"**{sample['name']}**")
                st.button("Try an example", key="shop_sample_" + sample["sample_id"], width="stretch",
                          on_click=choose_sample, args=(sample, samples))
        if selected:
            st.button("Clear photo", key="shop_clear_photo", on_click=clear_photo)


def reference_strip():
    photo = st.session_state.get("shop_photo")
    if not photo:
        st.caption("Created without a reference photo.")
        return
    image, description = st.columns([1, 5], gap="medium")
    with image:
        show_image(photo["raw"], (300, 180))
    with description:
        st.markdown(f"**Inspired by {photo['name']}**")
        st.caption("Your selected reference photo")


def select_bouquet(product):
    if st.session_state.get("shop_a_selected", {}).get("id") != product["id"]:
        st.session_state.pop("shop_a_enquiry", None)
        for key in list(st.session_state):
            if key.startswith("shop_form_a_"):
                st.session_state.pop(key, None)
    st.session_state.shop_a_selected = product
    move("a", "details")


def shop_bouquet_choices(products, *, matched=False, offset=0):
    for rank, (column, product) in enumerate(zip(st.columns(min(2, len(products)), gap="medium"), products), offset + 1):
        with column, st.container(border=True, key=f"shop_product_{rank}"):
            show_image(product["image_url"], (560, 300))
            st.subheader(product["id"] + " · " + product["name"])
            if matched:
                st.caption("Photo match " + str(rank))
            st.markdown(f"**{money(product['price_hkd'])}**")
            st.button("Select Bouquet", key=f"shop_a_select_{rank}", width="stretch",
                      on_click=select_bouquet, args=(product,))


def existing_bouquets(samples, materials):
    stage = st.session_state.get("shop_a_stage", "photo")
    photo = st.session_state.get("shop_photo")
    if not photo and stage != "success":
        stage = "photo"
    journey("a", stage)
    if stage == "photo":
        navigation, actions = page_header("Find Similar Bouquets" if not photo else None, key="a_photo")
        with navigation:
            st.button("Back to Home", key="shop_a_home", on_click=navigate, args=("Home",))
        if not photo:
            st.write("Find an existing bouquet with the colours and feel of your inspiration.")
        photo = photo_picker(samples)
        with actions:
            if st.button("Find Similar Bouquets", type="primary", key="shop_a_search", disabled=photo is None):
                try:
                    with st.spinner("Finding bouquets for you…"):
                        products = searchable_shop_products()
                        st.session_state.shop_a_results = search_shop_bouquets(photo["raw"], local_model(), products)
                    move("a", "results")
                    st.rerun()
                except (OSError, ValueError, ImportError, RuntimeError):
                    st.error("Bouquet search is unavailable right now. Please try again or ask a florist for help.")
    elif stage == "results":
        navigation, _ = page_header("A few bouquets you may love", key="a_results", caption="Your Top 2 photo matches")
        with navigation:
            st.button("Back to photo", key="shop_a_back_photo", on_click=move, args=("a", "photo"))
        results = st.session_state.get("shop_a_results")
        products = searchable_shop_products()
        if (results and results["upload_sha256"] == photo["sha256"]
                and results.get("embedding_method") != SHOP_EMBEDDING_METHOD):
            try:
                with st.spinner("Updating your photo matches…"):
                    results = search_shop_bouquets(photo["raw"], local_model(), products)
                st.session_state.shop_a_results = results
            except (OSError, ValueError, ImportError, RuntimeError):
                st.error("Bouquet search is unavailable right now. Please try again or ask a florist for help.")
                return
        if (not results or results["upload_sha256"] != photo["sha256"]
                or results.get("catalog_source") != "shop_bouquets"
                or results.get("catalog_fingerprint") != shop_catalog_fingerprint(products)):
            move("a", "photo")
            st.rerun()
        st.subheader("Choose a shop bouquet")
        if not products:
            st.info("Our shop bouquet designs are being updated. You can still create your own bouquet.")
        current = {product["id"]: product for product in products}
        matches = [current[product_id] for product_id in results["ids"]][:2]
        if matches:
            shop_bouquet_choices(matches, matched=True)
        others = [product for product in products if product["id"] not in results["ids"]]
        if others:
            with st.expander("Browse the rest of the shop collection"):
                shop_bouquet_choices(others, offset=len(matches))
    elif stage == "details":
        product = st.session_state.shop_a_selected
        product = next((row for row in shop_products() if row["id"] == product["id"]), product)
        st.session_state.shop_a_selected = product
        navigation, actions = page_header(product["name"], key="a_details")
        with navigation:
            st.button("Back to bouquets", key="shop_a_back_results", on_click=move, args=("a", "results"))
        with actions:
            st.button("Continue to preferences", type="primary", key="shop_a_preferences",
                      on_click=move, args=("a", "enquiry"), disabled=product["price_hkd"] is None)
        image, detail = st.columns([1.1, 1], gap="large")
        with image:
            show_image(product["image_url"], (650, 450))
        with detail:
            if product.get("price_snapshot"):
                render_selling_summary(product["price_snapshot"], materials=materials)
            elif product["price_hkd"] is None:
                st.info(product["pricing_error"])
    elif stage == "enquiry":
        enquiry_form("a")
    else:
        enquiry_confirmation("a")


def analyse_custom(samples):
    photo = st.session_state.get("shop_photo")
    context = photo["sha256"] if photo else "no-reference"
    if ("shop_b_material_draft" in st.session_state
            and (st.session_state.get("shop_b_suggestion_context") == context
                 or ("shop_b_suggestion_context" not in st.session_state
                     and st.session_state["shop_b_material_draft"]
                     and st.session_state.get("shop_b_provenance", {}).get("photo_sha256") == (photo or {}).get("sha256")))):
        st.session_state.shop_b_suggestion_context = context
        move("b", "composition")
        return
    result = match_customer_photo(photo["raw"], samples) if photo else None
    active = {row["id"]: row for row in pricing_materials(list_materials(active_only=True))}
    quantities = {key: value for key, value in (result or {}).get("demo_florist_quantities", {}).items() if key in active}
    analysis = deepcopy(result["analysis"]) if result else None
    if analysis:
        analysis["flowers"] = [row for row in analysis["flowers"] if row["material_id"] in active]
    st.session_state.shop_b_analysis = analysis
    st.session_state.shop_b_provenance = ({key: value for key, value in result.items()
                                          if key not in ("analysis", "demo_florist_quantities")} if result else
                                        {"source": "manual_review", "label": "Manual design · No AI inference",
                                         "photo_sha256": (photo or {}).get("sha256")})
    st.session_state.shop_b_quantities = quantities
    st.session_state.shop_b_material_draft = dict(quantities)
    st.session_state.shop_b_suggestion_context = context
    st.session_state.pop("shop_b_editor_base", None)
    for key in list(st.session_state):
        if key.startswith("shop_b_quantity_"):
            st.session_state.pop(key, None)
    move("b", "composition")


def start_without_photo(samples):
    if st.session_state.get("shop_photo"):
        clear_photo()
    st.session_state.shop_b_without_photo = True
    analyse_custom(samples)


def save_customer_plan(records, materials):
    active = [row for row in materials if row.get("is_active", True)]
    allowed = {row["name"] for row in active}
    if any(record.get("Flower") not in allowed for record in records):
        raise ValueError("A selected material is no longer available. Please review your flowers.")
    rows = review_from_request(records, materials, st.session_state.get("shop_b_analysis"))
    price_snapshot = calculate_selling_price(rows, materials, st.session_state.shop_b_provenance)
    if not rows or not any((row["Florist quantity"] or 0) > 0 for row in rows):
        raise ValueError("Please add at least one flower to your bouquet.")
    context = signature(rows)
    if st.session_state.get("shop_b_design_context") != context:
        for key in ("shop_b_requested", "shop_b_enquiry", "shop_b_enquiry_reference"):
            st.session_state.pop(key, None)
    st.session_state.shop_b_design_context = context
    st.session_state.shop_b_plan = rows
    st.session_state.shop_b_editor_base = records
    st.session_state.shop_b_material_snapshot = deepcopy(materials)
    st.session_state.shop_b_price_snapshot = price_snapshot
    return rows


def custom_bouquet(materials, samples):
    stage = st.session_state.get("shop_b_stage", "photo")
    if stage == "confirmation":  # Continue an open Phase 4E design in the new request-first flow.
        move("b", "enquiry")
        stage = "enquiry"
    if not st.session_state.get("shop_photo") and not st.session_state.get("shop_b_without_photo") and stage != "success":
        stage = "photo"
    journey("b", stage)
    if stage == "photo":
        navigation, actions = page_header("Create Your Own Bouquet" if not st.session_state.get("shop_photo") else None,
                                          key="b_photo")
        with navigation:
            st.button("Back to Home", key="shop_b_home", on_click=navigate, args=("Home",))
        if not st.session_state.get("shop_photo"):
            st.write("Start with your inspiration, then choose the flowers and quantities that feel right for you.")
        photo = photo_picker(samples)
        with actions:
            st.button("Start without a photo", key="shop_b_manual", on_click=start_without_photo, args=(samples,))
            if st.button("Explore Flower Composition", type="primary", key="shop_b_analyse", disabled=photo is None):
                analyse_custom(samples)
                st.rerun()
    elif stage == "composition":
        navigation, composition_actions = page_header("Make it your bouquet", key="b_composition",
            caption="We've prepared a suggested flower selection based on this sample bouquet. Feel free to personalise it."
                    if st.session_state.get("shop_b_analysis") is not None else
                    "Create your bouquet by choosing your favourite flowers below.")
        with navigation:
            st.button("Back to photo", key="shop_b_back_photo", on_click=move, args=("b", "photo"))
        if st.session_state.pop("shop_b_reference_reset", False):
            st.info("Reference photo changed. The previous flower selection was cleared for this new design.")
        active = [row for row in materials if row["is_active"]]
        records = st.session_state.get("shop_b_editor_base") or requested_rows(
            materials, st.session_state.get("shop_b_analysis"), st.session_state.get("shop_b_quantities", {}))
        live_price_panel = st.container()
        records = customer_material_picker(materials, records)
        try:
            names = {row["name"]: row["id"] for row in active}
            price = calculate_selling_price([{"material_id": names[row["Flower"]], "quantity": row["Quantity"]}
                                             for row in records], active, st.session_state.shop_b_provenance)
            with live_price_panel:
                render_selling_summary(price, compact=True, materials=active)
        except ValueError as exc:
            with live_price_panel:
                st.info(str(exc))
        # Render in the header, after collecting the current quantities below it.
        with composition_actions:
            if st.button("Continue to estimated price", key="shop_b_estimate", type="primary"):
                try:
                    save_customer_plan(records, materials)
                    move("b", "estimate")
                    st.rerun()
                except ValueError as exc:
                    st.error(str(exc).replace("Florist quantities", "Requested quantities").replace("Florist quantity", "Requested quantity"))
    elif stage == "estimate":
        navigation, actions = page_header("Your bouquet, taking shape", key="b_estimate")
        with navigation:
            st.button("Back to your flowers", key="shop_b_back_composition", on_click=move,
                      args=("b", "composition"))
        with actions:
            st.button("Continue to preferences", type="primary", key="shop_b_request",
                      on_click=move, args=("b", "enquiry"))
        reference_strip()
        snapshot = st.session_state.get("shop_b_material_snapshot", materials)
        amount = preliminary_price(st.session_state.shop_b_plan, snapshot, st.session_state.shop_b_provenance)
        if amount is not None:
            st.markdown(f"### Preliminary estimate · {money(amount)}")
            st.caption("An indicative bouquet price, pending florist confirmation.")
            render_selling_summary(st.session_state.shop_b_price_snapshot, materials=snapshot)
        else:
            st.info("A florist needs to resolve your flower choices before a price can be estimated.")
    elif stage == "enquiry":
        if not st.session_state.get("shop_b_plan"):
            move("b", "photo")
            st.rerun()
        enquiry_form("b", materials)
    else:
        if customer_enquiry(st.session_state, "b") is None:
            move("b", "photo")
            st.rerun()
        enquiry_confirmation("b")


def enquiry_form(option, materials=None):
    if option == "b":
        materials = st.session_state.get("shop_b_material_snapshot", materials)
    with page_navigation("preferences_back_" + option):
        st.button("Back", key=f"shop_{option}_enquiry_back", on_click=move,
                  args=(option, "details" if option == "a" else "estimate"))
    if option == "a":
        bouquet = st.session_state.shop_a_selected
        amount = f"{bouquet['price_hkd']:.2f}"
    else:
        bouquet = None
        amount = preliminary_price(st.session_state.shop_b_plan, materials, st.session_state.shop_b_provenance)
    with st.form(f"shop_{option}_enquiry_form", border=False):
        _, actions = page_header("A few details for your bouquet", key="preferences_" + option)
        if option == "a":
            st.markdown(f"**{bouquet['name']} · {money(amount)}**")
        else:
            st.markdown("**Your custom bouquet**" + (f" · {money(amount)}" if amount is not None else " · Price to be confirmed"))
            st.caption("Preliminary estimate. A florist will review your request and confirm a quotation after you submit.")
        left, right = st.columns(2)
        with left:
            name = st.text_input("Your name", key=f"shop_form_{option}_name", max_chars=80)
            contact = st.text_input("Email or phone", key=f"shop_form_{option}_contact", max_chars=160)
            fulfilment = st.selectbox("Delivery or collection", ["Collection", "Delivery"], key=f"shop_form_{option}_fulfilment")
        with right:
            date = st.date_input("Preferred date (optional)", value=None, key=f"shop_form_{option}_date")
            address = st.text_input("Delivery area or address", key=f"shop_form_{option}_address", max_chars=300,
                                    help="Required for a delivery enquiry.")
            preferences = st.text_area("Occasion, colours or other preferences", key=f"shop_form_{option}_preferences", max_chars=1000, height=100)
        with actions:
            submitted = st.form_submit_button("Create enquiry", type="primary")
    if submitted:
        try:
            preferences = {"name": name, "contact": contact, "fulfilment": fulfilment,
                           "date": date.isoformat() if date else "To be confirmed", "address": address, "preferences": preferences}
            if option == "a":
                enquiry = mock_enquiry("A", photo_sha256=st.session_state.shop_photo["sha256"], amount=amount,
                                       bouquet=bouquet, preferences=preferences)
                design = None
                if bouquet.get("price_snapshot"):
                    enquiry["price_snapshot"] = deepcopy(bouquet["price_snapshot"])
            else:
                enquiry = pending_custom_enquiry(photo_sha256=(st.session_state.get("shop_photo") or {}).get("sha256"), amount=amount,
                                                 flowers=customer_flowers(st.session_state.shop_b_plan), preferences=preferences)
                enquiry["price_snapshot"] = deepcopy(st.session_state.shop_b_price_snapshot)
                design = {"plan": st.session_state.shop_b_plan, "analysis": st.session_state.shop_b_analysis,
                          "provenance": st.session_state.shop_b_provenance, "quantities": st.session_state.shop_b_quantities,
                          "context": st.session_state.shop_b_design_context, "materials": deepcopy(materials)}
            add_enquiry(st.session_state, enquiry, st.session_state.get("shop_photo"), design=design, bouquet=bouquet)
            move(option, "success")
            st.rerun()
        except ValueError as exc:
            st.error(str(exc))


def enquiry_confirmation(option):
    enquiry = customer_enquiry(st.session_state, option)
    if not enquiry:
        st.info("Choose a bouquet to create an enquiry.")
        return
    stage = enquiry["workflow_status"]
    navigation, actions = page_header({"pending": "Enquiry received",
                                       "awaiting_confirmation": "Your proposal is ready", "completed": "Enquiry completed",
                                       "cancelled": "Enquiry cancelled"}[stage], key="customer_enquiry")
    with navigation:
        if st.session_state.shop_nav == "Your enquiries":
            st.button("Back to enquiries", key="shop_customer_enquiries_back", on_click=clear_customer_enquiry)
        else:
            st.button("Back to Home", key=f"shop_{option}_finish", on_click=navigate, args=("Home",))
        if option == "b" and st.session_state.get("shop_b_plan"):
            st.button("Create another design", key="shop_b_change_design", on_click=navigate,
                      args=("Custom Bouquet", "composition"))
        elif option == "a":
            st.button("Choose another bouquet", key="shop_a_change_bouquet", on_click=navigate,
                      args=("Find Similar", "photo"))
    response_panel = st.container()
    record = queue(st.session_state)[enquiry["reference"]]
    enquiry_overview(enquiry, record)
    show_price_versions(record)
    with response_panel:
        customer_response_controls(enquiry, navigation=navigation, actions=actions)
    proposals = [*record.get("proposal_history", []), record.get("proposal")]
    enquiry_history(customer_history(record["history"], proposals),
                    expanded=stage == "awaiting_confirmation" and bool(enquiry.get("proposal_notes")))


def enquiry_overview(public, record):
    with st.container(key="shop_enquiry_overview"):
        photo, details = st.columns([.85, 2.15], gap="large", vertical_alignment="center")
        with photo:
            product = record.get("offered_bouquet") or record.get("bouquet")
            if product:
                show_image(product["image_url"], (420, 340))
            else:
                show_reference_photo(record.get("photo"))
        with details:
            name = public.get("bouquet", {}).get("name", "Your custom bouquet")
            price = money(public["price_hkd"]) if public["price_hkd"] is not None else "Price to be confirmed"
            price_label = ("Confirmed price" if public.get("quotation") else "Preliminary estimate · Pending florist review") if public["option"] == "B" else ""
            if public["workflow_status"] == "cancelled" and public["option"] == "B":
                price_label = "Previous quotation" if public.get("quotation") else "Previous estimate"
            preferences = public["preferences"]
            date = preferences["date"]
            if date != "To be confirmed":
                try:
                    date = datetime.fromisoformat(date).strftime("%d %b %Y")
                except ValueError:
                    pass
            notes = []
            for label, content in (("Your preferences", preferences["preferences"]),
                                   ("Delivery address", preferences["address"] if preferences["fulfilment"] == "Delivery" else ""),
                                   ("Collection / delivery notes", public.get("quotation", {}).get("delivery_notes", ""))):
                if content:
                    notes.append('<div class="enquiry-note"><strong>' + escape(label) + '</strong><p>' + escape(content) + '</p></div>')
            st.html('<div class="enquiry-overview-copy">' + status_badge_html(public) +
                    '<h2>' + escape(name) + '</h2><p class="enquiry-overview-price">' + escape(price) + '</p>' +
                    ('<p class="enquiry-price-label">' + escape(price_label) + '</p>' if price_label else '') +
                    '<p class="enquiry-reference">Reference ' + escape(public["reference"]) + '</p>' +
                    '<p class="enquiry-fulfilment">' + escape(preferences["fulfilment"] + " · " + date) + '</p>' +
                    ''.join(notes) + '</div>')


def respond_to_proposal(reference, version, decision, message_key=None):
    try:
        if decision == "confirm":
            confirm_proposal(st.session_state, reference, version)
        else:
            request_proposal_changes(st.session_state, reference, version, st.session_state.get(message_key, ""))
        st.session_state.pop("shop_response_error", None)
        st.session_state.pop("shop_changes_open", None)
    except ValueError as exc:
        st.session_state.shop_response_error = {"reference": reference, "message": str(exc)}


def customer_response_controls(public, *, navigation, actions):
    reference = public["reference"]
    error = st.session_state.get("shop_response_error", {})
    if error.get("reference") == reference:
        st.error(error["message"])
    if public["workflow_status"] in ("completed", "cancelled"):
        return
    if st.session_state.get("shop_cancel_open") == reference:
        st.html('<div class="enquiry-cancel-prompt"><strong>Cancel this enquiry?</strong>'
                '<p>The enquiry will close. Your history will be kept.</p></div>')
        with navigation:
            st.button("Keep enquiry", key="shop_keep_enquiry", on_click=lambda: st.session_state.pop("shop_cancel_open", None))
        with actions:
            st.button("Confirm cancellation", key="shop_confirm_cancellation", type="primary",
                      on_click=cancel_customer_enquiry, args=(reference,))
        return
    with actions:
        st.button("Cancel enquiry", key="shop_cancel_enquiry", on_click=open_cancellation, args=(reference,))
    response = public.get("customer_response", {})
    if public["workflow_status"] == "pending" and response.get("decision") == "changes_requested":
        st.html('<div class="enquiry-note"><strong>Your requested changes</strong><p>' +
                escape(response["message"]) + '</p></div>')
    elif public["workflow_status"] == "awaiting_confirmation":
        version = public["proposal_version"]
        if st.session_state.get("shop_changes_open") == reference:
            message_key = f"shop_change_message_{reference}_{version}"
            st.text_area("What would you like to change?", key=message_key, max_chars=1000)
            with actions:
                st.button("Submit changes", type="primary", on_click=respond_to_proposal,
                          args=(reference, version, "changes", message_key))
            with navigation:
                st.button("Back to proposal", key="shop_cancel_changes", on_click=lambda: st.session_state.pop("shop_changes_open", None))
        else:
            with actions:
                st.button("Request changes", key="shop_request_changes", on_click=lambda: st.session_state.update(shop_changes_open=reference))
                st.button("Confirm proposal", key=f"shop_confirm_{reference}_{version}", type="primary",
                          on_click=respond_to_proposal, args=(reference, version, "confirm"))
            return


def open_cancellation(reference):
    st.session_state.shop_cancel_open = reference
    st.session_state.pop("shop_changes_open", None)


def cancel_customer_enquiry(reference):
    try:
        cancel_enquiry(st.session_state, reference)
        st.session_state.pop("shop_changes_open", None)
        st.session_state.pop("shop_response_error", None)
    except ValueError as exc:
        st.session_state.shop_response_error = {"reference": reference, "message": str(exc)}
    st.session_state.pop("shop_cancel_open", None)


def status_badge_html(public):
    stage = public.get("workflow_status", "pending")
    return (f'<span class="enquiry-status enquiry-status-{escape(stage)}" role="status">'
            f'{escape(WORKFLOW_LABELS[stage])}</span>')


def status_badge(public):
    st.html(status_badge_html(public))


def local_time(value):
    return datetime.fromisoformat(value).astimezone(ZoneInfo("Asia/Hong_Kong")).strftime("%d %b %Y · %H:%M")


def staff_back_to_list():
    release_staff_workspace()
    st.session_state.pop("staff_detail_reference", None)
    st.session_state.staff_nav = "Customer Enquiries"


def cancel_staff_enquiry(reference, reason_key):
    try:
        cancel_enquiry(st.session_state, reference, actor="Staff", reason=st.session_state.get(reason_key, ""))
        st.session_state.pop("staff_cancel_error", None)
        st.session_state.staff_status_filter = "cancelled"
        st.session_state.pop("staff_cancel_open", None)
    except ValueError as exc:
        st.session_state.staff_cancel_error = {"reference": reference, "message": str(exc)}


def staff_cancellation_controls(record, *, navigation, actions):
    reference = record["reference"]
    error = st.session_state.get("staff_cancel_error", {})
    if error.get("reference") == reference:
        st.error(error["message"])
    if record["workflow_status"] not in ("pending", "awaiting_confirmation"):
        return False
    if st.session_state.get("staff_cancel_open") == reference:
        st.html('<div class="enquiry-cancel-prompt"><strong>Cancel this enquiry?</strong>'
                '<p>The enquiry will close. Your quotation versions and history will be kept.</p></div>')
        reason_key = "staff_cancel_reason_" + reference
        st.text_area("Cancellation reason (optional)", key=reason_key, max_chars=1000, height=100,
                     help="This reason will be visible to the customer.")
        with navigation:
            st.button("Keep enquiry", key="staff_keep_enquiry",
                      on_click=lambda: st.session_state.pop("staff_cancel_open", None))
        with actions:
            st.button("Confirm cancellation", key="staff_confirm_cancellation", type="primary",
                      on_click=cancel_staff_enquiry, args=(reference, reason_key))
        return True
    with actions:
        st.button("Cancel enquiry", key="staff_cancel_enquiry",
                  on_click=lambda: st.session_state.update(staff_cancel_open=reference))
    return False


def staff_inbox():
    counts = workflow_counts(st.session_state)
    choices = list(WORKFLOW_LABELS)
    if st.session_state.get("staff_status_filter") not in choices:
        st.session_state.staff_status_filter = "pending"
    with st.container(key="staff_status_filters"):
        st.radio("Enquiry status", choices, key="staff_status_filter", horizontal=True, label_visibility="collapsed",
                 format_func=lambda stage: WORKFLOW_LABELS[stage] + f" ({counts[stage]})")
    records = filtered_enquiries(st.session_state, st.session_state.staff_status_filter)
    if not queue(st.session_state):
        st.info("New customer enquiries will appear here.")
    elif not records:
        st.write("No enquiries in this status.")
    for record in records:
        public = record["public"]
        preferences = public["preferences"]
        with st.container(key="staff_enquiry_row_" + record["reference"]):
            thumbnail, summary, status, action = st.columns([.7, 2.5, 1.7, 1], gap="medium", vertical_alignment="center")
            with thumbnail:
                product = record.get("offered_bouquet") or record.get("bouquet")
                if product:
                    show_image(product["image_url"], (180, 140))
                else:
                    show_reference_photo(record.get("photo"), (180, 140))
            with summary:
                st.html('<div class="enquiry-row-copy"><strong>' + escape(preferences["name"]) + '</strong><p>' +
                        escape(public.get("bouquet", {}).get("name", "Custom bouquet")) + '</p><small>' +
                        escape(preferences["fulfilment"] + " · " + preferences["date"]) + '</small></div>')
            with status:
                price = '<p class="enquiry-row-price">' + money(public["price_hkd"]) + '</p>' if public["price_hkd"] is not None else ''
                st.html('<div>' + status_badge_html(public) + price + '</div>')
            with action:
                st.button("Open enquiry", key="staff_open_" + record["reference"],
                          on_click=open_staff_enquiry, args=(record["reference"],))


def customer_feedback(record):
    response = record.get("customer_response", {})
    if response.get("decision") == "changes_requested":
        st.html('<div class="enquiry-feedback"><strong>Changes requested</strong><p>' +
                escape(response["message"]) + '</p></div>')


def enquiry_history(items, *, expanded=False):
    with st.expander("Enquiry history", expanded=expanded):
        rows = []
        for item in reversed(items):
            action = "Proposal confirmed" if item["action"] == "Proposal confirmed · Enquiry completed" else item["action"]
            detail = item.get("detail", "")
            amount = detail if item["action"] == "Proposal ready for confirmation" and detail.startswith("HK$") else ""
            message = item.get("florist_message", "")
            rows.append('<li><div class="enquiry-history-action"><strong>' + escape(action) + '</strong>' +
                        ('<span>' + escape(amount) + '</span>' if amount else '') + '</div>' +
                        '<p class="enquiry-history-meta"><time datetime="' + escape(item["at"], quote=True) + '">' +
                        escape(local_time(item["at"])) + '</time> · ' + escape(item["actor"]) + '</p>' +
                        ('<p class="enquiry-history-detail">' + escape(detail) + '</p>' if detail and not amount else '') +
                        ('<div class="enquiry-history-message"><strong>Florist message</strong><p>' +
                         escape(message) + '</p></div>' if message else '') + '</li>')
        st.html('<ol class="enquiry-history" aria-label="Enquiry history, newest first">' + ''.join(rows) + '</ol>')


def staff_workspace(materials):
    page = st.session_state.staff_nav
    if page == "Flower Materials":
        with page_navigation("staff_materials"):
            st.button("Back to enquiries", key="materials_back", on_click=staff_back_to_list)
        staff_materials(materials)
        return
    records = queue(st.session_state)
    reference = st.session_state.get("staff_detail_reference")
    if page == "Dashboard" or reference not in records:
        navigation, _ = page_header("Customer enquiries", key="staff_inbox")
        with navigation:
            st.button("Flower Materials", key="staff_flower_materials", on_click=open_materials)
        staff_inbox()
        return
    record = records[reference]
    public = record["public"]
    navigation, actions = page_header(public["preferences"]["name"], key="staff_enquiry")
    with navigation:
        st.button("Back to enquiries", key="staff_back_to_list", on_click=staff_back_to_list)
    cancelling = staff_cancellation_controls(record, navigation=navigation, actions=actions)
    status_badge(public)
    customer_feedback(record)
    staff_request_details(record)
    if not cancelling:
        staff_reply_editor(record, materials, actions=actions)
    show_price_versions(record)
    enquiry_history(history_with_messages(record["history"], [*record.get("proposal_history", []), record.get("proposal")]))


def staff_request_details(record):
    public = record["public"]
    images, details = st.columns([1.15, 1], gap="large", vertical_alignment="top")
    with images, st.container(key="staff_reference_images"):
        product = record.get("offered_bouquet") or record.get("bouquet")
        slots = st.columns(2, gap="small") if product else [st.container()]
        with slots[0]:
            st.caption("Reference photo")
            show_reference_photo(record.get("photo"), natural=True)
        if product:
            with slots[1]:
                st.caption("Proposed bouquet" if record.get("offered_bouquet") else "Selected bouquet")
                show_image(product["image_url"], (420, 360))
    with details:
        staff_information_panel(record)


def show_price_versions(record):
    original = record["submitted"].get("price_snapshot")
    if not original:
        if record["submitted"].get("price_hkd") is not None:
            with st.expander("Original quotation"):
                st.write("Captured price · " + money(record["submitted"]["price_hkd"]))
        return
    # Photos are presentation metadata only: quantities, names, units and prices
    # must continue to come from each captured quotation, never today's catalog.
    try:
        photos = {row["material_id"]: row for row in list_materials()}
    except (sqlite3.Error, OSError, ValueError):
        photos = {}
    for material in (record.get("design") or {}).get("materials", []):
        try:
            if local_image_path(material.get("reference_image") or material.get("image_path")).is_file():
                photos[material.get("id", material.get("material_id"))] = material
        except (OSError, ValueError, TypeError):
            pass
    materials = list(photos.values())
    with st.expander("Quotation versions"):
        render_selling_summary(original, title="Original request", materials=materials)
        for index, proposal in enumerate([*record.get("proposal_history", []), record.get("proposal")], 1):
            if proposal and proposal["public"].get("price_snapshot"):
                render_selling_summary(proposal["public"]["price_snapshot"], title=f"Reviewed proposal {index}",
                                       materials=materials)


def staff_information_panel(record):
    public = record["public"]
    preferences = public["preferences"]
    contact = preferences["contact"]
    contact_html = escape(contact)
    if "@" in contact and not any(char.isspace() for char in contact):
        contact_html = '<a href="mailto:' + quote(contact, safe="@.+") + '">' + contact_html + '</a>'
    date = preferences["date"]
    if date != "To be confirmed":
        try:
            date = datetime.fromisoformat(date).strftime("%d %b %Y")
        except ValueError:
            pass
    fields = '<div><dt>Contact</dt><dd>' + contact_html + '</dd></div>'
    fields += '<div><dt>' + escape(preferences["fulfilment"]) + '</dt><dd>' + escape(date) + '</dd></div>'
    if preferences["address"]:
        fields += '<div><dt>Address</dt><dd>' + escape(preferences["address"]) + '</dd></div>'
    notes = []
    for label, content in (("Customer preferences", preferences["preferences"]),
                           ("Collection / delivery notes", public.get("quotation", {}).get("delivery_notes", ""))):
        if content:
            notes.append('<div class="staff-detail-note"><strong>' + escape(label) + '</strong><p>' + escape(content) + '</p></div>')
    price = money(public["price_hkd"]) if public["price_hkd"] is not None else "To be confirmed"
    price_label = ("Catalogue price" if public["option"] == "A" else
                   "Florist-reviewed price" if public.get("quotation") else "Preliminary estimate")
    if public["workflow_status"] == "cancelled":
        price_label = "Previous " + price_label.lower()
    st.html('<section class="staff-detail-panel" aria-label="Enquiry details">'
            '<div class="staff-detail-heading"><h2>' + escape(public.get("bouquet", {}).get("name", "Custom bouquet")) + '</h2>' +
            '<div class="staff-detail-price"><strong>' + escape(price) + '</strong><span>' + escape(price_label) + '</span></div></div>' +
            '<dl class="staff-detail-fields">' + fields + '</dl>' + ''.join(notes) +
            '<footer class="staff-detail-meta"><p>Submitted ' + escape(local_time(record["submitted_at"])) + '</p>' +
            '<p>Reference ' + escape(record["reference"]) + '</p></footer></section>')


def preserve_inputs():
    # Keep form/price input values while their screens are not rendered. Explicit
    # photo/design invalidation still removes them. Never assign button values.
    for name in PRICING_INPUT_KEYS:
        key = "phase3b_" + name
        if key in st.session_state:
            st.session_state[key] = st.session_state[key]
    for key in list(st.session_state):
        if (key.startswith(("shop_form_", "shop_change_message_", "staff_proposal_", "staff_cancel_reason_"))
                or (key.startswith("staff_reply_") and key.endswith(("_price", "_message", "_bouquet", "_add_choice")))
                or key in ("shop_staff_stage", "shop_nav", "staff_nav", "shop_role", "staff_active_enquiry", "staff_status_filter")):
            st.session_state[key] = st.session_state[key]


def main():
    st.session_state.setdefault("shop_role", "Staff" if st.query_params.get("demo_role") == "staff" else "Customer")
    st.session_state.setdefault("shop_nav", "Home")
    st.session_state.setdefault("staff_nav", "Dashboard")
    if st.session_state.shop_nav not in NAV:
        st.session_state.shop_nav = "Home"
    workspace = st.query_params.get("workspace")
    if workspace in ("technical", "presentation") and st.session_state.shop_role == "Staff":
        st.sidebar.caption("Staff workspace")
        st.sidebar.link_button("Open staff workspace", "?demo_role=staff")
        if workspace == "technical":
            from product_search.app.streamlit_app import main as original
        else:
            from product_search.app.presentation_app import main as original
        original()
        return
    st.set_page_config(page_title="blue forest florist", layout="wide", initial_sidebar_state="collapsed")
    preserve_inputs()
    use_inline_replies(st.session_state)
    if st.session_state.staff_nav in ("Shop Bouquets", "Pricing & Quotations"):
        st.session_state.staff_nav = "Customer Enquiries"
    st.html(Path(__file__).with_name("customer.css"))
    catalog_unavailable = False
    try:
        initialize_database()
        initialize_shop_bouquets()
        materials = pricing_materials(list_materials())
    except (OSError, ValueError, sqlite3.Error):
        # Keep the independent existing-bouquet journey and saved enquiries usable.
        materials = []
        catalog_unavailable = True
    try:
        samples = load_customer_samples(materials or None)
    except (OSError, ValueError, sqlite3.Error):
        st.error("Our bouquet references are temporarily unavailable. Please try again later.")
        return
    staff = st.session_state.shop_role == "Staff"
    page = st.session_state.staff_nav if staff else st.session_state.shop_nav
    header(landing=not staff and page == "Home")
    if not staff and page == "Home":
        home(samples)
    else:
        with st.container(key="shop_content"):
            if staff:
                if catalog_unavailable and page == "Flower Materials":
                    with page_navigation("staff_catalog_error"):
                        st.button("Back to enquiries", key="materials_back", on_click=staff_back_to_list)
                    st.error("The material database is temporarily unavailable. Please try again later.")
                else:
                    staff_workspace(materials)
            elif page == "Find Similar":
                existing_bouquets(samples, materials)
            elif page == "Your enquiries":
                customer_enquiries()
            elif page == "Custom Bouquet":
                if catalog_unavailable and st.session_state.get("shop_b_stage") != "success":
                    st.error("Our flower catalog is temporarily unavailable. Please try again later.")
                else:
                    custom_bouquet(materials, samples)
    st.session_state.shop_last_page = page
    with st.container(key="shop_footer"):
        brand, attribution = st.columns([1, 1], vertical_alignment="center")
        with brand:
            st.html('<p class="shop-footer-brand">blue forest florist</p>')
        with attribution:
            credits()


if __name__ == "__main__":
    main()
