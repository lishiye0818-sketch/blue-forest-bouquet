import time
from pathlib import Path

import streamlit as st
from dotenv import load_dotenv
from PIL import Image, ImageOps

from product_search.config import BOUQUET_CATALOG, DEFAULT_CATALOG, INDEXES_DIR, ROOT, catalog_path
from product_search.search.explanations import product_evidence
from product_search.search.indexes import catalog_fingerprint, load_or_build
from product_search.search.keyword import KeywordSearch
from product_search.utils.data_loader import ProductDataLoader, is_web_url
from product_search.utils.images import image_source_available, load_image

load_dotenv(ROOT / ".env")
MODES = ["Semantic", "Semantic + keywords", "Keyword"]

st.set_page_config(page_title="Blue Forest AI Bouquet Copilot", layout="wide")
st.html(Path(__file__).with_name("style.css"))


@st.cache_resource
def catalog(data_path, fingerprint):
    loader = ProductDataLoader(data_path)
    df = loader.preprocess_data()
    return df, loader, KeywordSearch(df["text_for_embedding"].tolist())


@st.cache_resource
def text_model():
    from product_search.models.text_embedding import TextEmbeddingGenerator
    return TextEmbeddingGenerator()


@st.cache_resource
def image_model():
    try:
        from product_search.models.image_embedding import ImageEmbeddingGenerator
    except ImportError as exc:
        raise ImportError("Image search needs the optional dependencies. Run `uv sync --extra image`.") from exc
    return ImageEmbeddingGenerator()


@st.cache_resource
def search_index(kind, data_path, fingerprint):
    if kind == "text":
        from product_search.models.text_embedding import MODEL_ID
        factory = text_model
    else:
        from product_search.models.image_embedding import MODEL_ID
        factory = image_model
    df, _, _ = catalog(data_path, fingerprint)
    return load_or_build(data_path, df, INDEXES_DIR, kind, MODEL_ID, factory)


@st.cache_data(max_entries=100)
def catalog_image(url, fingerprint):
    try:
        return load_image(url, INDEXES_DIR / "images")
    except Exception:
        return None


def show_product(product, rank=None, query=""):
    image = catalog_image(product["image_url"], st.session_state.active_catalog[1]) if product["image_url"] else None
    if image is not None:
        st.image(ImageOps.pad(image, (600, 760), color="#ECEBE5"), width="stretch")
    else:
        label = "Mock product · Photo not supplied" if product.get("is_mock") else "Image unavailable"
        st.markdown(f'<div class="image-missing">{label}</div>', unsafe_allow_html=True)
    name = product["name"] if "price_hkd" in product else product["name"].capitalize()
    st.markdown(f"#### {f'{rank}. ' if rank else ''}{name}")
    if "price_hkd" in product:
        st.write(f"HK${product['price_hkd']:,.2f}" + (" · Mock price" if product["is_mock"] else ""))
        st.caption(f"Colour: {product['colour']} · Style: {product['style']} · Occasion: {product['occasion']}")
    with st.expander("View details"):
        if query:
            label, excerpts = product_evidence(product, query)
            st.caption(label)
            for excerpt in excerpts:
                st.text(excerpt)
            st.divider()
        st.text(product["details"] or "No description is available.")
        if product.get("image_source_url"):
            st.caption(f"Photo: {product['image_creator']} · {product['image_license']} · Wikimedia thumbnail, padded for display.")
            st.link_button("Photo source", product["image_source_url"])
            if is_web_url(product.get("image_license_url", "")):
                st.link_button("Photo license", product["image_license_url"])
        if product.get("is_mock"):
            st.caption("Mock catalog entry · No real product listing or availability.")
        elif is_web_url(product["link"]):
            st.link_button("Original listing", product["link"])


def show_results(products, query=""):
    for start in range(0, len(products), 3):
        for offset, (column, product) in enumerate(zip(st.columns(3), products[start:start + 3])):
            with column:
                show_product(product, start + offset + 1, query)


def find_similar_bouquets():
    catalogs = {"Blue Forest bouquets — mock": BOUQUET_CATALOG, "Original ZARA jackets": DEFAULT_CATALOG}
    configured = catalog_path()
    if configured != DEFAULT_CATALOG:
        catalogs = {f"Configured catalog — {configured.name}": configured, **catalogs}
    selected = st.selectbox("Product catalog", list(catalogs))
    data_path = catalogs[selected]
    try:
        fingerprint = catalog_fingerprint(data_path)
        df, loader, keyword = catalog(str(data_path), fingerprint)
    except (OSError, ValueError) as exc:
        st.error(f"Catalog could not be loaded. {exc}")
        return
    identity = (str(data_path), fingerprint)
    if st.session_state.get("active_catalog") != identity:
        for key in ("text_results", "image_results", "query", "search_method", "reference_photo"):
            st.session_state.pop(key, None)
        st.session_state.active_catalog = identity
        st.session_state.catalog_generation = st.session_state.get("catalog_generation", 0) + 1
    widget_suffix = st.session_state.catalog_generation
    bouquet = loader.is_bouquet
    mock = bool(df["is_mock"].any())
    st.title("Blue Forest AI Bouquet Copilot" if bouquet else "Semantic Product Search")
    st.caption(f"{'Bouquet' if bouquet else 'Jacket'} search · {len(df)} products")
    if mock:
        st.warning("University project · Rows marked Mock contain example names, descriptions, prices, colours and occasions. They are not verified Blue Forest products.")
    if bouquet:
        with st.expander("Browse bouquet catalog"):
            st.dataframe(df[["product_name", "description", "price_hkd", "colour", "style", "occasion", "is_mock"]], hide_index=True)
    text_tab, image_tab = st.tabs(["Describe it", "Use a photo"])
    with text_tab:
        with st.form("text_search", border=False):
            field, options, action = st.columns([6, 2, 1.5], vertical_alignment="bottom")
            with field:
                query = st.text_input("Describe a bouquet" if bouquet else "Describe a jacket", key=f"query_{widget_suffix}",
                                      placeholder="e.g. pink roses for a birthday" if bouquet else "e.g. a cropped denim jacket")
            with options:
                with st.popover("Search options", width="stretch"):
                    mode = st.radio("Search method", MODES, index=2 if bouquet else 0, key=f"search_method_{widget_suffix}")
                    if bouquet:
                        st.caption("Keyword search works without credentials. Semantic search requires an OpenRouter embedding API key.")
            with action:
                submitted = st.form_submit_button("Search", type="primary", width="stretch")
        if submitted:
            st.session_state.pop("text_results", None)
            if not query.strip():
                st.warning("Describe a product to start searching.")
            else:
                try:
                    if mode == "Keyword":
                        start = time.perf_counter()
                        ids = keyword.search(query)
                    else:
                        with st.spinner("Preparing semantic search on first use…"):
                            db, _ = search_index("text", str(data_path), fingerprint)
                            model = text_model()
                        start = time.perf_counter()
                        with st.spinner("Finding matches…"):
                            embedding = model.generate_text_embedding(query)
                            _, indices = db.search_by_text(embedding, query_text=query, keyword_boost=mode == "Semantic + keywords")
                            ids = indices[0].tolist()
                    st.session_state.text_results = {"ids": ids, "query": query, "mode": mode,
                                                     "ms": (time.perf_counter() - start) * 1000}
                except Exception as exc:
                    st.error(f"Text search could not finish. {exc}")
        results = st.session_state.get("text_results")
        if results:
            st.subheader(f"Results for “{results['query']}”")
            count = len(results["ids"])
            st.caption(f"{count} product{'s' if count != 1 else ''} · {results['mode']}")
            if not results["ids"]:
                st.info("No matching words found. Try a different description or search method.")
            show_results(loader.get_product_details(results["ids"]), results["query"])
    with image_tab:
        has_images = bool(df["image_url"].map(image_source_available).any())
        if not has_images:
            st.info("This catalog has no usable product photos yet. Add permitted local images or image URLs to enable photo search. You can search descriptions with Keyword now.")
        with st.form("image_search", border=False):
            uploaded = st.file_uploader("Reference photo", type=["jpg", "jpeg", "png"], max_upload_size=15,
                                        key=f"reference_photo_{widget_suffix}", disabled=not has_images)
            submitted_image = st.form_submit_button("Find similar bouquets" if bouquet else "Find similar pieces", type="primary", disabled=not has_images)
        sample_submitted = False
        sample_path = ROOT / "data/images/references/independent-rose-bouquet.jpg"
        if data_path == BOUQUET_CATALOG and sample_path.is_file():
            sample_submitted = st.button("Try a sample bouquet photo", key="sample_bouquet_photo")
            st.caption("Try a separate reference photo that is not in the catalog, or upload your own above.")
        if submitted_image or sample_submitted:
            st.session_state.pop("image_results", None)
            if uploaded is None and not sample_submitted:
                st.warning("Choose a reference photo first.")
            else:
                try:
                    if sample_submitted:
                        reference = load_image(str(sample_path), INDEXES_DIR / "images")
                    else:
                        with Image.open(uploaded) as source:
                            reference = ImageOps.exif_transpose(source).convert("RGB")
                    with st.spinner("Preparing image search on first use…"):
                        db, report = search_index("image", str(data_path), fingerprint)
                        model = image_model()
                    start = time.perf_counter()
                    embedding = model.generate_embedding_from_pil_image(reference)
                    _, ids = db.search_by_image(embedding, k=3 if bouquet else 5)
                    st.session_state.image_results = {"ids": ids[0].tolist(), "reference": reference,
                                                      "ms": (time.perf_counter() - start) * 1000, "report": report,
                                                      "sample": sample_submitted}
                except Exception as exc:
                    st.error(f"Image search could not finish. {exc}")
        results = st.session_state.get("image_results")
        if results:
            st.image(results["reference"], width=160, caption="Your reference")
            if results.get("sample"):
                st.caption("Sample photo: Cendy00 · [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) · "
                           "[Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Fresh_flower_bouquet.jpg) · Resized for display.")
            st.subheader("Top 3 visually similar bouquets" if bouquet else "Visually similar pieces")
            st.caption(f"{results['report']['indexed']} of {len(df)} catalog photos searchable")
            show_results(loader.get_product_details(results["ids"]))
    st.divider()
    if bouquet:
        st.caption("Blue Forest AI Bouquet Copilot · University project · Catalog search · Availability not tracked")
    else:
        st.caption("Taiwu Chen · Archival ZARA catalog · Availability not tracked · Not affiliated with ZARA")


def main():
    search_tab, custom_tab = st.tabs(["Find Similar Bouquets", "Custom Bouquet"])
    with search_tab:
        find_similar_bouquets()
    with custom_tab:
        from product_search.app.custom_bouquet import render_custom_bouquet
        render_custom_bouquet()


if __name__ == "__main__":
    main()
