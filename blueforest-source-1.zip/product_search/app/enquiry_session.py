"""Local demo queue and isolated adapters for the existing staff review widgets.

This is in-session workflow state, not authentication, storage or a pricing engine.
Only explicit public projections are ever returned to a customer.
"""

from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json

from product_search.app.customer_presenter import mock_enquiry

INPUT_NAMES = ("packaging", "overhead", "labour", "markup", "waste", "delivery_enabled", "delivery",
               "budget_enabled", "budget", "final_price", "delivery_notes", "draft_text", "reviewer", "approved")
PRICING_KEYS = {"phase3b_" + name for name in INPUT_NAMES} | {
    "phase3b_material_context", "phase3b_base_context", "phase3b_draft", "phase3b_finalized", "phase3b_approval_context"}
REVIEW_KEYS = {"custom_review", "custom_review_input", "custom_presentation_editor_base",
               "shop_staff_review_valid", "shop_staff_stage", "shop_staff_last_task"}
WORKSPACE_KEYS = PRICING_KEYS | REVIEW_KEYS
REVIEW_COLUMNS = ("Flower", "Reviewed visible count", "Filler usage", "Florist quantity", "Florist notes")
WORKFLOW_LABELS = {"pending": "Pending",
                   "awaiting_confirmation": "Awaiting confirmation", "completed": "Completed", "cancelled": "Cancelled"}
STATUS_LABELS = {"enquiry_created_mock": "Pending", "awaiting_florist_review": "Pending",
                 "in_review_mock": "Pending", "quotation_approved_mock": "Awaiting confirmation",
                 "reviewed_mock": "Awaiting confirmation", "cancelled_mock": "Cancelled"}


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def event(record, action, actor, detail=""):
    record.setdefault("history", []).append({"at": now(), "action": action, "actor": actor, "detail": detail})


def fingerprint(public):
    fields = ("photo_sha256", "bouquet", "flowers", "price_hkd", "quotation", "preferences", "proposal_notes", "price_snapshot")
    payload = {key: public[key] for key in fields if key in public}
    return hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def expose_workflow(record):
    public = record["public"]
    public["workflow_status"] = record["workflow_status"]
    if record.get("proposal"):
        public["proposal_version"] = record["proposal"]["version"]
    if record.get("customer_response"):
        public["customer_response"] = deepcopy(record["customer_response"])


def ensure_workflow(record):
    """Upgrade the local queue from earlier demo screens without losing records."""
    if "workflow_status" not in record:
        status = record["public"].get("status")
        record["workflow_status"] = ("cancelled" if status == "cancelled_mock" else
                                     "awaiting_confirmation" if status in ("quotation_approved_mock", "reviewed_mock")
                                     else "pending")
        record.setdefault("history", []).append({"at": record["submitted_at"], "action": "Enquiry submitted",
                                                 "actor": "Customer", "detail": ""})
        if record["workflow_status"] == "awaiting_confirmation":
            record["proposal_counter"] = 1
            public = deepcopy(record["public"])
            record["proposal"] = {"version": "1-" + fingerprint(public), "fingerprint": fingerprint(public), "public": public}
    record.setdefault("proposal_counter", 0)
    if record["workflow_status"] == "in_progress":
        # A customer can only confirm a published proposal. Older unsubmitted
        # reviews stay Pending; no history, drafts or price snapshots are lost.
        record["workflow_status"] = "awaiting_confirmation" if record.get("proposal") else "pending"
        record["processing_started"] = True
    expose_workflow(record)
    return record["workflow_status"]


def queue(state):
    records = state.setdefault("shop_enquiry_queue", {})
    for record in records.values():
        ensure_workflow(record)
    return records


def workflow_counts(state):
    counts = dict.fromkeys(WORKFLOW_LABELS, 0)
    for record in queue(state).values():
        counts[record["workflow_status"]] += 1
    return counts


def filtered_enquiries(state, stage="all"):
    records = [record for record in reversed(list(queue(state).values())) if stage == "all" or record["workflow_status"] == stage]
    priority = list(WORKFLOW_LABELS)
    # Newest first within each state; unresolved work stays above completed work.
    records.sort(key=lambda record: record["submitted_at"], reverse=True)
    return sorted(records, key=lambda record: priority.index(record["workflow_status"]))


def update_alias(state, record):
    option = record["submitted"]["option"].lower()
    expose_workflow(record)
    if state.get(f"shop_{option}_enquiry_reference") == record["reference"]:
        state[f"shop_{option}_enquiry"] = deepcopy(record["public"])


def start_enquiry(state, reference):
    record = queue(state)[reference]
    if record["workflow_status"] != "pending" or record.get("processing_started"):
        return
    record["processing_started"] = True
    record["public"]["status"] = "in_review_mock"
    event(record, "Processing started", "Staff")
    update_alias(state, record)


def publish_proposal(record, public):
    if record["workflow_status"] in ("cancelled", "completed"):
        raise ValueError("This enquiry is closed.")
    if public.get("price_snapshot"):
        from product_search.material_store import persist_price_snapshot
        persist_price_snapshot(record["reference"], "proposal_" + str(record["proposal_counter"] + 1),
                               public["price_snapshot"])
    record["proposal_counter"] += 1
    digest = fingerprint(public)
    record["proposal"] = {"version": f"{record['proposal_counter']}-{digest}", "fingerprint": digest,
                          "public": deepcopy(public)}
    record["public"] = deepcopy(public)
    record["workflow_status"] = "awaiting_confirmation"
    record.pop("customer_response", None)
    event(record, "Proposal ready for confirmation", "Staff", "HK$" + str(public["price_hkd"]))
    record["history"][-1].update(proposal_version=record["proposal"]["version"],
                                  florist_message=public.get("proposal_notes", ""))


def approved_custom_projection(record):
    if record["workflow_status"] == "cancelled":
        return None
    workspace = record["workspace"]
    finalized = workspace.get("phase3b_finalized")
    photo_sha256 = (record.get("photo") or {}).get("sha256")
    if (workspace.get("shop_staff_review_valid") and finalized
            and finalized.get("status") == "finalized_mock"
            and finalized.get("florist_review", {}).get("approved") is True
            and finalized.get("provenance", {}).get("photo_sha256") == photo_sha256):
        public = mock_enquiry("B", photo_sha256=photo_sha256,
                              preferences=record["submitted"]["preferences"], amount=None, quotation=finalized,
                              flowers=[{"flower": row["flower"], "quantity": row["quantity"], "unit": row["pricing_unit"]}
                                       for row in finalized["flowers"]])
        public.update(reference=record["reference"], status="quotation_approved_mock")
        if finalized.get("price_snapshot"):
            public["price_snapshot"] = deepcopy(finalized["price_snapshot"])
        return public
    return None


def canonical_rows(rows):
    return [{key: row.get(key) for key in REVIEW_COLUMNS} for row in rows]


def edited_rows(base, changes):
    """Retain unsubmitted editor edits without restoring write-protected widget state."""
    rows = deepcopy(base)
    for index, values in changes.get("edited_rows", {}).items():
        if 0 <= int(index) < len(rows):
            rows[int(index)].update({key: value for key, value in values.items() if key in REVIEW_COLUMNS})
    removed = set(changes.get("deleted_rows", []))
    rows = [row for index, row in enumerate(rows) if index not in removed]
    rows.extend({key: row.get(key) for key in REVIEW_COLUMNS} for row in changes.get("added_rows", []))
    return rows


def add_enquiry(state, public, photo, *, design=None, bouquet=None):
    if public.get("price_snapshot"):
        from product_search.material_store import persist_price_snapshot
        persist_price_snapshot(public["reference"], "original", public["price_snapshot"])
    record = {"reference": public["reference"], "submitted_at": now(),
              "submitted": deepcopy(public), "public": deepcopy(public), "photo": deepcopy(photo),
              "design": deepcopy(design), "bouquet": deepcopy(bouquet), "workspace": {}}
    queue(state)[record["reference"]] = record
    point_customer_at(state, record["reference"])
    return record


def point_customer_at(state, reference):
    public = queue(state)[reference]["public"]
    option = public["option"].lower()
    state[f"shop_{option}_enquiry_reference"] = reference
    state[f"shop_{option}_enquiry"] = deepcopy(public)


def customer_enquiry(state, option):
    reference = state.get(f"shop_{option}_enquiry_reference")
    record = queue(state).get(reference)
    if record:
        sync_public(state, record)
        return deepcopy(record["public"])
    return None


def sync_public(state, record):
    """Publish only current, saved and approved custom quotations; never certify a view."""
    ensure_workflow(record)
    if record["workflow_status"] in ("cancelled", "completed") or record.get("reply_mode") == "inline":
        update_alias(state, record)
        return
    if record["submitted"]["option"] == "B":
        candidate = approved_custom_projection(record)
        proposal = record.get("proposal")
        if candidate and record.get("processing_started"):
            if not proposal or proposal["fingerprint"] != fingerprint(candidate):
                if proposal:
                    record.setdefault("proposal_history", []).append(deepcopy(proposal))
                publish_proposal(record, candidate)
            else:
                record["public"] = deepcopy(proposal["public"])
        else:
            if proposal:
                record.setdefault("proposal_history", []).append(deepcopy(proposal))
                record.pop("proposal", None)
                record.pop("customer_response", None)
                record["workflow_status"] = "pending"
                event(record, "Proposal withdrawn for review", "Staff")
            record["public"] = deepcopy(record["submitted"])
            if record["workflow_status"] != "pending":
                record["public"]["status"] = "in_review_mock"
    update_alias(state, record)


def current_proposal(state, reference, version):
    record = queue(state)[reference]
    if record["workflow_status"] == "cancelled":
        raise ValueError("This enquiry has been cancelled.")
    sync_public(state, record)
    proposal = record.get("proposal")
    if not proposal or proposal["version"] != version:
        raise ValueError("This proposal has changed. Please review the latest details before responding.")
    return record, proposal


def confirm_proposal(state, reference, version):
    record, proposal = current_proposal(state, reference, version)
    if record["workflow_status"] == "completed":
        return  # Repeated clicks must not duplicate completion or history.
    if record["workflow_status"] != "awaiting_confirmation":
        raise ValueError("This enquiry is not waiting for your confirmation.")
    record["workflow_status"] = "completed"
    record["customer_response"] = {"decision": "confirmed", "at": now(), "proposal_version": version}
    event(record, "Proposal confirmed · Enquiry completed", "Customer")
    update_alias(state, record)


def request_proposal_changes(state, reference, version, message):
    message = str(message).strip()
    if not message or len(message) > 1000:
        raise ValueError("Please describe the changes you would like (up to 1,000 characters).")
    record, proposal = current_proposal(state, reference, version)
    if record["workflow_status"] != "awaiting_confirmation":
        raise ValueError("This enquiry is not waiting for your confirmation.")
    record.setdefault("proposal_history", []).append(deepcopy(proposal))
    record.pop("proposal", None)
    if record.get("reply_draft"):
        record.setdefault("reply_draft_history", []).append(record.pop("reply_draft"))
    record["workflow_status"] = "pending"
    record["customer_response"] = {"decision": "changes_requested", "at": now(),
                                   "proposal_version": version, "message": message}
    record["public"] = deepcopy(record["submitted"])
    record["public"]["status"] = "in_review_mock"
    if record["submitted"]["option"] == "B":
        for target in (record["workspace"], state if state.get("staff_loaded_enquiry") == reference else {}):
            for key in ("phase3b_finalized", "phase3b_approval_context"):
                target.pop(key, None)
            target["phase3b_approved"] = False
            target["shop_staff_stage"] = "Flower review"
    event(record, "Changes requested", "Customer", message)
    update_alias(state, record)


def cancel_enquiry(state, reference, *, actor="Customer", reason=""):
    """Close an unconfirmed local enquiry while retaining its complete history."""
    if actor not in ("Customer", "Staff"):
        raise ValueError("Only a customer or Staff can cancel an enquiry.")
    record = queue(state)[reference]
    if record["workflow_status"] == "cancelled":
        return
    if record["workflow_status"] not in ("pending", "awaiting_confirmation"):
        raise ValueError("A confirmed enquiry cannot be cancelled here.")
    reason = str(reason).strip()
    if len(reason) > 1000:
        raise ValueError("The cancellation reason must be at most 1,000 characters.")
    proposal = record.pop("proposal", None)
    if proposal:
        record.setdefault("proposal_history", []).append(deepcopy(proposal))
    record["workflow_status"] = "cancelled"
    record["public"]["status"] = "cancelled_mock"
    record["public"].pop("proposal_version", None)
    record["customer_response"] = {"decision": "cancelled", "at": now(), "actor": actor}
    event(record, "Enquiry cancelled", actor, reason)
    if reason:
        record["customer_response"]["reason"] = reason
        # Only this explicit public reason may appear in the customer history;
        # arbitrary Staff audit details must remain private.
        record["history"][-1]["cancellation_reason"] = reason
    update_alias(state, record)


def save_workspace(state):
    record = queue(state).get(state.get("staff_loaded_enquiry"))
    if not record or record["submitted"]["option"] != "B" or record["workflow_status"] == "cancelled":
        return
    workspace = {key: deepcopy(state[key]) for key in WORKSPACE_KEYS if key in state}
    base = state.get("custom_presentation_editor_base", canonical_rows(record["design"]["plan"]))
    generation = state.get("custom_review_generation", 0)
    rows = (edited_rows(base, state.get(f"custom_editor_{generation}", {}))
            if state.get("shop_staff_stage", "Flower review") == "Flower review"
            else deepcopy(state.get("custom_review_input", base)))
    workspace["custom_presentation_editor_base"] = rows
    # A role change must not certify unsaved edits or keep a stale approval.
    if (state.get("shop_staff_stage", "Flower review") == "Flower review"
            and canonical_rows(rows) != canonical_rows(state.get("custom_review_input", []))):
        workspace["shop_staff_review_valid"] = False
        for key in PRICING_KEYS:
            workspace.pop(key, None)
    record["workspace"] = workspace
    sync_public(state, record)


def load_workspace(state, reference):
    if state.get("staff_loaded_enquiry") == reference:
        return
    save_workspace(state)
    generation = state.get("custom_review_generation", 0) + 1
    for key in list(state):
        if key in WORKSPACE_KEYS or key.startswith("custom_editor_"):
            state.pop(key, None)
    record = queue(state)[reference]
    for key, value in record["workspace"].items():
        if key in WORKSPACE_KEYS:
            state[key] = deepcopy(value)
    state["custom_review_generation"] = generation
    state["staff_loaded_enquiry"] = reference
    if record["submitted"]["option"] == "B":
        state.setdefault("custom_presentation_editor_base", canonical_rows(record["design"]["plan"]))
        state.setdefault("shop_staff_stage", "Flower review")
        state.setdefault("shop_staff_review_valid", False)


def release_workspace(state):
    """Make the next staff visit restore its saved editor and pricing inputs."""
    save_workspace(state)
    state.pop("staff_loaded_enquiry", None)


def mark_existing_reviewed(state, reference, *, bouquet=None, notes=""):
    record = queue(state)[reference]
    if record["submitted"]["option"] != "A":
        raise ValueError("Custom bouquets require a saved review and an approved quotation.")
    if record["workflow_status"] != "pending" or not record.get("processing_started"):
        raise ValueError("Start processing this enquiry before preparing a proposal.")
    product = bouquet or record.get("offered_bouquet") or record["bouquet"] or record["submitted"]["bouquet"]
    public = mock_enquiry("A", photo_sha256=record["photo"]["sha256"],
                          preferences=record["submitted"]["preferences"], amount=f"{float(product['price_hkd']):.2f}", bouquet=product)
    public.update(reference=reference, status="reviewed_mock")
    if product.get("price_snapshot"):
        public["price_snapshot"] = deepcopy(product["price_snapshot"])
    if str(notes).strip():
        public["proposal_notes"] = str(notes).strip()[:1000]
    record["offered_bouquet"] = deepcopy(product)
    publish_proposal(record, public)
    update_alias(state, record)
