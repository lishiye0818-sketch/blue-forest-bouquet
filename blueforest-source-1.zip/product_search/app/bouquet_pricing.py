"""Phase 3B UI after the existing saved florist/material review."""

import json
from copy import deepcopy
from contextlib import nullcontext
from decimal import Decimal

import streamlit as st

from product_search.bouquet_pricing import (
    MOCK_DATA_LABEL, calculate_pricing, finalize_quotation, generate_quotation, quotation_context, signature,
)


def invalidate_pricing():
    """Discard prices, draft edits and approval when the material review is stale."""
    for key in list(st.session_state):
        if key.startswith("phase3b_"):
            st.session_state.pop(key, None)


def clear_draft():
    for key in ("phase3b_draft", "phase3b_finalized", "phase3b_approval_context"):
        st.session_state.pop(key, None)
    st.session_state.phase3b_approved = False


def show_budget(label, comparison):
    if comparison["status"] == "not_provided":
        return
    difference = Decimal(comparison["difference_hkd"])
    if difference < 0:
        st.info(f"{label} is HK${abs(difference):.2f} over the customer budget (Mock Data).")
    else:
        st.info(f"{label} is within the customer budget, with HK${difference:.2f} remaining (Mock Data).")


def render_price_table(base):
    """Presentation-only formatting; amounts come from the existing calculation."""
    rows = [
        ("Materials", base["material_cost_hkd"]),
        ("Waste allowance", base["waste_allowance_hkd"]),
        ("Packaging", base["inputs"]["packaging_cost_hkd"]),
        ("Labour", base["inputs"]["labour_cost_hkd"]),
        ("Overhead", base["inputs"]["overhead_cost_hkd"]),
        ("Production subtotal", base["production_cost_hkd"]),
        ("Delivery", base["inputs"]["delivery_fee_hkd"]),
        ("Total estimated cost", base["total_estimated_cost_hkd"]),
        ("Markup", base["markup_amount_hkd"]),
        ("Suggested selling price", base["suggested_selling_price_hkd"]),
        ("Estimated profit", base["estimated_gross_profit_hkd"]),
    ]
    body = "".join(
        f'<tr class="{"price-total" if index in (7, 9) else ""}"><th scope="row">{label}</th>'
        f'<td>{amount}</td></tr>'
        for index, (label, amount) in enumerate(rows)
    )
    st.html('<table class="price-table"><caption>Cost calculation · Mock Data (HKD)</caption><tbody>' + body + '</tbody></table>')


def render_pricing_workflow(material_quote, *, presentation=False, show_quotation=True):
    st.subheader(("Final Mock Quotation" if show_quotation else "Pricing Breakdown") if presentation
                 else "Phase 3B · Pricing and customer quotation")
    st.caption(MOCK_DATA_LABEL + " · All costs and prices below are simulated HKD values.")
    context = signature(material_quote)
    if st.session_state.get("phase3b_material_context") != context:
        invalidate_pricing()
        st.session_state.phase3b_material_context = context
    if material_quote["issues"]:
        st.info("Complete and save all florist quantities and resolve Unknown materials before pricing a customer quotation.")
        return

    controls = st.expander("Review pricing details · Mock Data", expanded=False) if presentation and show_quotation else nullcontext()
    with controls:
        settings = st.expander("Adjust mock costs & customer budget", expanded=False) if presentation else nullcontext()
        with settings:
            st.write("Enter mock costs. Waste is a percentage of material cost. Markup applies to production cost; "
                     "delivery is added afterward as a pass-through cost and charge.")
            first, second, third = st.columns(3)
            with first:
                packaging = st.text_input("Packaging cost (HKD, Mock Data)", value="20.00", key="phase3b_packaging")
                overhead = st.text_input("Overhead cost (HKD, Mock Data)", value="15.00", key="phase3b_overhead")
            with second:
                labour = st.text_input("Labour cost (HKD, Mock Data)", value="50.00", key="phase3b_labour")
                markup = st.text_input("Markup (%)", value="50", key="phase3b_markup")
            with third:
                waste = st.text_input("Waste allowance (% of materials)", value="10", key="phase3b_waste")
                delivery_enabled = st.checkbox("Include delivery fee", key="phase3b_delivery_enabled")
                delivery = st.text_input("Delivery fee (HKD, Mock Data)", value="0.00", disabled=not delivery_enabled,
                                         key="phase3b_delivery")
            budget_enabled = st.checkbox("Compare customer budget", key="phase3b_budget_enabled")
            budget = st.text_input("Customer budget (HKD, Mock Data)", value="300.00", disabled=not budget_enabled,
                                   key="phase3b_budget")
        inputs = {"packaging_cost": packaging, "labour_cost": labour, "overhead_cost": overhead,
                  "waste_allowance_percent": waste, "markup_percent": markup,
                  "delivery_fee": delivery if delivery_enabled else None,
                  "customer_budget": budget if budget_enabled else None}
        try:
            base = calculate_pricing(material_quote, **inputs)
        except ValueError as exc:
            clear_draft()
            st.session_state.pop("phase3b_base_context", None)
            st.error(str(exc))
            return
        base_context = signature(base)
        if st.session_state.get("phase3b_base_context") != base_context:
            clear_draft()
            st.session_state.phase3b_base_context = base_context
            st.session_state.phase3b_final_price = base["suggested_selling_price_hkd"]

        breakdown, decision = st.columns([1.2, 1], gap="large") if presentation else (nullcontext(), nullcontext())
        with breakdown:
            breakdown_rows = [
                {"Calculation": "Material cost", "Mock Data (HKD)": base["material_cost_hkd"]},
                {"Calculation": "Waste allowance", "Mock Data (HKD)": base["waste_allowance_hkd"]},
                {"Calculation": "Production cost before delivery", "Mock Data (HKD)": base["production_cost_hkd"]},
                {"Calculation": "Total estimated cost including delivery", "Mock Data (HKD)": base["total_estimated_cost_hkd"]},
                {"Calculation": "Markup amount", "Mock Data (HKD)": base["markup_amount_hkd"]},
                {"Calculation": "Suggested selling price including delivery", "Mock Data (HKD)": base["suggested_selling_price_hkd"]},
                {"Calculation": "Estimated gross profit after listed costs", "Mock Data (HKD)": base["estimated_gross_profit_hkd"]},
            ]
            if presentation:
                render_price_table(base)
                with st.expander("Material quantities and unit costs"):
                    st.dataframe([{
                        "Flower": line["flower"], "Quantity": line["quantity"], "Unit": line["pricing_unit"],
                        "Unit cost (HKD)": line["mock_unit_cost_hkd"], "Line cost (HKD)": line["mock_line_cost_hkd"],
                    } for line in material_quote["lines"]], hide_index=True, width="stretch")
            else:
                st.dataframe(breakdown_rows, hide_index=True)
            margin = base["estimated_profit_margin_percent"]
            (st.caption if presentation else st.text)(f"Markup on production cost: {base['inputs']['markup_percent']}% · "
                    f"Suggested profit margin on selling price: {margin + '%' if margin is not None else 'undefined at zero price'}")
            with st.expander("Calculation notes") if presentation else nullcontext():
                st.caption("Markup = profit added ÷ production cost. Profit margin = estimated profit ÷ selling price. "
                           "For example, 25% markup on HK\\$100 gives a HK\\$125 price and a 20% margin without delivery. "
                           "HKD amounts round half up to cents. Supplier prices, availability and tax remain unverified.")
            show_budget("Suggested price", base["suggested_budget_comparison"])

        with decision:
            final_price = st.text_input("Final reviewed price (HKD, Mock Data)", key="phase3b_final_price",
                                        help="Starts at the suggested price. A florist can enter a different reviewed selling price.")
            delivery_notes = st.text_area("Delivery or collection notes", value="Delivery or collection arrangements to be confirmed.",
                                          key="phase3b_delivery_notes", max_chars=2000)
            try:
                pricing = calculate_pricing(material_quote, **inputs, reviewed_price=final_price)
            except ValueError as exc:
                clear_draft()
                st.error(str(exc))
                return
            reviewed_summary = (f"Reviewed price (Mock Data): HK${pricing['final_reviewed_price_hkd']} · "
                    f"Estimated profit after listed costs: HK${pricing['reviewed_gross_profit_hkd']} · "
                    f"Profit margin: {pricing['reviewed_profit_margin_percent'] + '%' if pricing['reviewed_profit_margin_percent'] is not None else 'undefined at zero price'}")
            if presentation:
                st.markdown(reviewed_summary.replace("$", r"\$"))
            else:
                st.text(reviewed_summary)
            if Decimal(pricing["reviewed_gross_profit_hkd"]) < 0:
                st.info("The reviewed price is below the total estimated cost (Mock Data). Confirm the intended price before approval.")
            show_budget("Reviewed price", pricing["reviewed_budget_comparison"])
            st.download_button("Download mock pricing JSON" if presentation else "Download Phase 3B mock pricing JSON", json.dumps(pricing, indent=2),
                               file_name="bouquet-mock-pricing.json", mime="application/json", key="phase3b_download_pricing")

    if not show_quotation:
        return

    render_quotation_approval(pricing, delivery_notes, presentation=presentation)


def render_quotation_approval(pricing, delivery_notes, *, presentation=False, actions=None):
    """Shared template editing and named approval gates for both pricing modes."""
    if presentation:
        st.write(f"Reviewed quotation price · HK${pricing['final_reviewed_price_hkd']} · Mock Data")
    current_context = quotation_context(pricing, delivery_notes)
    draft = st.session_state.get("phase3b_draft")
    if draft is not None and draft["context_signature"] != current_context:
        clear_draft()
        draft = None
        st.info("Price or delivery details changed. Generate a new draft and review it again.")
    target = actions if actions is not None else st
    if target.button("Generate customer quotation draft", key="phase3b_generate"):
        clear_draft()
        try:
            draft = generate_quotation(pricing, delivery_notes,
                                       allow_zero_price=pricing.get("pricing_method") == "unit_selling_prices")
            if pricing.get("pricing_method") == "unit_selling_prices":
                draft["price_snapshot"] = deepcopy(pricing)
            st.session_state.phase3b_draft = draft
            st.session_state.phase3b_draft_text = draft["text"]
        except ValueError as exc:
            st.error(str(exc))
    if draft is None:
        return
    edited = st.text_area("Customer quotation draft", key="phase3b_draft_text", height=300, max_chars=15000)
    st.caption("Edit the greeting and wording. Keep the Mock Data label and the flower, price and delivery summary "
               "consistent with the reviewed details. Drafts use a fixed template and make no LLM calls.")
    st.download_button("Download unapproved quotation draft", edited, file_name="bouquet-unapproved-mock-quotation.txt",
                       mime="text/plain", key="phase3b_download_draft")
    reviewer = st.text_input("Reviewing florist name", key="phase3b_reviewer", max_chars=80)
    approval_context = signature({"context": current_context, "text": edited, "reviewer": reviewer})
    if st.session_state.get("phase3b_approval_context") != approval_context:
        st.session_state.phase3b_approved = False
        st.session_state.pop("phase3b_finalized", None)
        st.session_state.phase3b_approval_context = approval_context
    approved = st.checkbox("I have reviewed the flower quantities, Mock Data price, delivery notes and complete quotation text.",
                            key="phase3b_approved")
    if target.button("Finalize mock customer quotation", key="phase3b_finalize", disabled=not approved or not reviewer.strip()):
        try:
            st.session_state.phase3b_finalized = finalize_quotation(
                draft, edited, reviewer_name=reviewer, review_confirmed=approved, current_context=current_context)
        except ValueError as exc:
            st.error(str(exc))
    finalized = st.session_state.get("phase3b_finalized")
    if finalized is not None:
        st.success("Mock customer quotation finalized after florist review. Nothing has been sent to a customer.")
        with st.expander("Finalized quotation text", expanded=False) if presentation else nullcontext():
            st.text(finalized["text"])
        st.download_button("Download finalized mock quotation", finalized["text"],
                           file_name="bouquet-finalized-mock-quotation.txt", mime="text/plain", key="phase3b_download_final")
        st.download_button("Download finalized mock quotation JSON", json.dumps(finalized, indent=2),
                           file_name="bouquet-finalized-mock-quotation.json", mime="application/json", key="phase3b_download_final_json")
