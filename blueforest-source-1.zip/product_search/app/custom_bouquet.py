"""Offline demo / live vision review UI with internal mock material-cost drafts."""

import hashlib
import json
import os

import pandas as pd
import streamlit as st
from PIL import Image

from product_search.app.bouquet_pricing import invalidate_pricing, render_pricing_workflow
from product_search.bouquet_demo import DEMO_MODE, DEMO_NOTICE, LIVE_MODE, load_demo_samples, match_demo_photo
from product_search.bouquet_quote import MOCK_QUOTE_NOTICE, build_mock_quote, quote_draft_text
from product_search.custom_bouquet import (
    DEFAULT_VISION_MODEL,
    USAGE_CATEGORIES,
    identify_flowers,
    image_data_url,
    load_material_catalog,
    prepare_photo,
    review_rows,
    validate_review,
)
from product_search.utils.images import local_image_path

UNIT_LABELS = {"flower_head": "visible heads", "flower_cluster": "visible clusters",
               "usage_category": "rough filler usage", "unresolved": "unresolved"}


def reference_thumbnail(material, size=(200, 200)):
    try:
        with Image.open(local_image_path(material["reference_image"])) as source:
            thumbnail = source.convert("RGB")
            thumbnail.thumbnail(size)
        return image_data_url(thumbnail)
    except (OSError, ValueError):
        return None


def reset_review():
    invalidate_pricing()
    for key in ("custom_analysis", "custom_analysis_model", "custom_provenance", "custom_review", "custom_review_input",
                "custom_presentation_editor_base"):
        st.session_state.pop(key, None)
    st.session_state.custom_review_generation = st.session_state.get("custom_review_generation", 0) + 1


def render_mock_costs(materials, provenance, current_records):
    with st.expander("Next phase · Mock costs and quotation draft"):
        st.caption(MOCK_QUOTE_NOTICE)
        st.write("Costs use only the florist quantities you enter in stems, bunches or portions. "
                 "Visible head counts and filler usage are never converted to material quantities.")
        if st.session_state.get("custom_review_input") != current_records:
            invalidate_pricing()
            st.info("Enter material quantities and save the florist review to preview mock costs and a draft.")
            return
        quote = build_mock_quote(st.session_state.custom_review, materials, provenance)
        st.dataframe([{
            "Flower": line["flower"], "Florist quantity": line["quantity"], "Unit": line["pricing_unit"],
            "Mock unit cost (HKD)": float(line["mock_unit_cost_hkd"]) if line["mock_unit_cost_hkd"] is not None else None,
            "Mock material cost (HKD)": float(line["mock_line_cost_hkd"]) if line["mock_line_cost_hkd"] is not None else None,
        } for line in quote["lines"]], hide_index=True, column_config={
            "Mock unit cost (HKD)": st.column_config.NumberColumn(format="%.2f"),
            "Mock material cost (HKD)": st.column_config.NumberColumn(format="%.2f"),
        })
        st.text(f"Known mock material subtotal: HK${quote['known_materials_subtotal_hkd']}")
        if quote["issues"]:
            st.info("Incomplete draft: " + " ".join(quote["issues"]))
        st.caption("Material costs only. Labour, wrapping, delivery, markup, tax and availability remain unverified.")
        draft = quote_draft_text(quote)
        st.text(draft)
        st.download_button("Download mock quotation draft", draft, file_name="bouquet-mock-draft.txt",
                           mime="text/plain", key="custom_download_quote")
        st.download_button("Download mock cost JSON", json.dumps(quote, indent=2), file_name="bouquet-mock-costs.json",
                           mime="application/json", key="custom_download_costs")
        render_pricing_workflow(quote)


def render_custom_bouquet():
    st.header("Custom Bouquet")
    st.write("Upload a complete bouquet photo to identify likely flowers and estimate what is visible. "
             "Review the suggestions before using them.")
    st.caption("Phase 3A · University prototype · Visible heads are not stems · Recognition accuracy has not been evaluated.")
    mode = st.radio("Analysis mode", [DEMO_MODE, LIVE_MODE], key="custom_mode")
    is_demo = mode == DEMO_MODE
    if is_demo:
        st.info(DEMO_NOTICE)
        st.caption("Use a licensed sample or upload its original file. Other photos use manual review. No API key is needed.")
    try:
        materials = load_material_catalog()
    except (OSError, ValueError) as exc:
        st.error(f"Flower-material catalog could not be loaded. {exc}")
        return
    lookup = {material["id"]: material for material in materials}
    references = {material["id"]: reference_thumbnail(material) for material in materials}
    with st.expander(f"Flower-material catalog · {len(materials)} types"):
        st.dataframe([{
            "Flower": material["name"], "Reference": references[material["id"]],
            "Category": material["category"], "Identification notes": material["visual_cues"],
            "Reference notes": material["reference_note"], "Pricing unit": material["pricing_unit"],
            "Mock unit cost (HKD)": material["mock_unit_cost_hkd"],
            "Photo credit / license": material.get("reference_credit", "See asset credits"),
            "Photo source": material.get("reference_source_url"),
        } for material in materials], hide_index=True, row_height=90, column_config={
            "Reference": st.column_config.ImageColumn("Reference photo", width="small"),
            "Mock unit cost (HKD)": st.column_config.NumberColumn(format="%.2f"),
            "Photo source": st.column_config.LinkColumn(),
        })
        st.caption("Illustrative references include garden photos and mixed arrangements; read the notes. "
                   "Reference photos are for human comparison and are not sent to the model. "
                   "Mock HKD costs support an internal material-cost draft from florist-entered quantities.")

    samples, selected_sample = [], None
    if is_demo:
        try:
            samples = load_demo_samples(materials)
        except (OSError, ValueError) as exc:
            st.error(f"Demo samples could not be loaded. Manual review is still available. {exc}")
        choices = {sample["sample_id"]: sample for sample in samples}
        sample_id = st.selectbox("Demo sample", ["", *choices], key="custom_demo_sample",
                                 format_func=lambda value: choices[value]["name"] if value else "Upload my own photo")
        selected_sample = choices.get(sample_id)
    uploaded = st.file_uploader("Custom bouquet photo", type=["jpg", "jpeg", "png"],
                                max_upload_size=15, key="custom_photo", disabled=selected_sample is not None)
    raw = local_image_path(selected_sample["photo"]).read_bytes() if selected_sample else uploaded.getvalue() if uploaded is not None else b""
    model = os.environ.get("BOUQUET_VISION_MODEL", "").strip() or DEFAULT_VISION_MODEL
    context = hashlib.sha256(raw + json.dumps(materials, sort_keys=True).encode()
                             + mode.encode() + (model.encode() if not is_demo else b"")
                             + json.dumps(samples, sort_keys=True).encode()).hexdigest()
    if st.session_state.get("custom_context") != context:
        st.session_state.custom_context = context
        reset_review()
    photo = None
    if raw:
        try:
            photo = prepare_photo(raw)
            st.image(photo, width="stretch", caption="Uploaded bouquet · Visible heads and clusters only")
        except ValueError as exc:
            st.error(str(exc))

    if is_demo:
        predefined = match_demo_photo(raw, samples) if photo is not None else None
        if photo is not None and predefined is None:
            st.info("This photo has no predefined demo result. Select flowers and enter quantities manually below. "
                    "No recognition result has been generated.")
        if st.button("Load demo results", type="primary", key="custom_demo_identify", disabled=predefined is None):
            reset_review()
            st.session_state.custom_analysis = predefined["analysis"]
            st.session_state.custom_analysis_model = None
            st.session_state.custom_provenance = {key: value for key, value in predefined.items() if key != "analysis"}
    else:
        has_key = bool(os.environ.get("OPENROUTER_API_KEY", "").strip())
        if not has_key:
            st.info("Set OPENROUTER_API_KEY in .env and restart the app to enable AI identification. "
                    "You can browse the catalog and review materials manually now.")
        st.caption("Identify flowers sends a resized copy of this photo to OpenRouter and its model provider. "
                   "Each click makes one request. Editing or saving the review does not call the model.")
        if st.button("Identify flowers", type="primary", key="custom_identify", disabled=photo is None or not has_key):
            reset_review()
            try:
                with st.spinner("Identifying visible flowers…"):
                    st.session_state.custom_analysis = identify_flowers(photo, materials)
                    st.session_state.custom_analysis_model = model
                    st.session_state.custom_provenance = {
                        "source": "live_ai", "label": "Live AI Mode — OpenRouter vision inference", "model": model,
                    }
            except ValueError as exc:
                st.error(str(exc))

    analysis = st.session_state.get("custom_analysis")
    provenance = st.session_state.get("custom_provenance") or {
        "source": "manual_review", "label": (DEMO_NOTICE + " · Manual review" if is_demo else "Manual review — No AI inference"),
    }
    if analysis is not None:
        st.subheader("Predefined observations" if is_demo else "AI observations")
        if is_demo:
            st.caption(DEMO_NOTICE + " · Labels and counts are illustrative fixtures, not verified annotations.")
        else:
            st.caption(f"Model: {st.session_state.custom_analysis_model} · Confidence is a self-assessment, not measured accuracy.")
        st.text(analysis["notes"])
        st.warning("Human review required. Overlap and hidden flowers can affect identity and counts. "
                   "Visible heads or clusters cannot establish actual stem quantities.")
        if analysis["flowers"]:
            st.dataframe([{
                "Flower": lookup[row["material_id"]]["name"] if row["material_id"] in lookup else "Unknown",
                "Reference": references.get(row["material_id"]),
                "Approx. visible count": row["visible_heads"],
                "Counting unit": UNIT_LABELS[row["counting_unit"]],
                "Filler usage": row["usage_category"], "Preset confidence" if is_demo else "Confidence": row["confidence"],
                "Uncertainty": row["uncertainty"], "Review required": row["review_required"],
                "Review flags": ", ".join(flag.replace("_", " ") for flag in row["review_flags"]),
                "Result source": provenance["label"],
            } for row in analysis["flowers"]], hide_index=True, row_height=100, column_config={
                "Reference": st.column_config.ImageColumn("Reference photo", width="small"),
                "Approx. visible count": st.column_config.NumberColumn(format="%d"),
            })
            st.caption("Unknown has no reliable catalog match. A blank count means no reliable estimate. "
                       "Hydrangeas use whole clusters; baby's breath uses light, moderate, heavy or uncertain usage.")
        else:
            st.info("No flower types were identified. Check the photo and enter materials manually if needed.")
        with st.expander("Structured analysis JSON"):
            st.json(analysis)
        st.download_button("Download analysis JSON", json.dumps({
            "provenance": provenance, "model": st.session_state.custom_analysis_model, "analysis": analysis,
        }, indent=2), file_name="bouquet-analysis.json", mime="application/json", key="custom_download_analysis")

    render_florist_review(materials, analysis, provenance, is_demo)


def render_florist_review(materials, analysis, provenance, is_demo=True, *, presentation=False, quantities=None,
                         whole_quantities=False, actions=None):
    st.subheader("Florist review")
    if not presentation:
        st.write("Correct the flower types and visible estimates below. Add a row for missed materials or delete "
                 "a row to exclude a suggestion. Use Unknown for flowers outside the catalog.")
    if not presentation:
        st.caption("Florist quantity is a separate, manually verified amount in the selected material's pricing unit. "
                   "It starts blank. Filler usage never implies a bunch quantity. Leave Unknown quantities blank.")
    initial_rows = review_rows(materials, analysis)
    if presentation:
        st.caption("Customer-requested quantities · Review or edit the plan, then save." if whole_quantities else
                   "Prepared demo quantities · Confirm or edit the plan, then save. Heads are separate from stems.")
        for row, observation in zip(initial_rows, (analysis or {}).get("flowers", [])):
            row["Florist quantity"] = (quantities or {}).get(observation["material_id"])
        if "custom_presentation_editor_base" not in st.session_state:
            stored = st.session_state.get("custom_review_input") or initial_rows
            st.session_state.custom_presentation_editor_base = [dict(row) for row in stored]
        initial_rows = st.session_state.custom_presentation_editor_base
    frame = pd.DataFrame(initial_rows).astype({
        "Reviewed visible count": "Int64", "Florist quantity": "Float64",
    })
    if is_demo:
        frame["Result source"] = provenance["label"]  # Keep built-in CSV exports explicitly labelled too.
    editor_key = f"custom_editor_{st.session_state.custom_review_generation}"
    edited = st.data_editor(frame, hide_index=True, width="stretch", num_rows="dynamic", key=editor_key,
                            disabled=["Result source"] if is_demo else [],
                            column_config={
                                "Flower": st.column_config.SelectboxColumn(
                                    options=[material["name"] for material in materials] + ["Unknown"], required=True),
                                "Reviewed visible count": st.column_config.NumberColumn(
                                    min_value=0, max_value=10000, step=1,
                                    help="Visible heads or whole hydrangea clusters. Leave blank for fillers and Unknown."),
                                "Filler usage": st.column_config.SelectboxColumn(
                                    options=list(USAGE_CATEGORIES), help="Fillers only; clear this for other flowers."),
                                "Florist quantity": st.column_config.NumberColumn(
                                    min_value=0, step=1 if whole_quantities else None,
                                    help="Manually verified stems, bunches or portions. See units below. Blank means unverified."),
                                **({"Result source": None, "Florist notes": st.column_config.TextColumn("Notes")}
                                   if presentation else {}),
                                **({"Reviewed visible count": None, "Filler usage": None} if whole_quantities else {}),
                            })
    records = json.loads(edited.to_json(orient="records"))  # Convert pandas NA to JSON null.
    if presentation and st.session_state.get("custom_review_input") != records:
        invalidate_pricing()
    units = {material["name"]: material for material in materials}
    if presentation:
        st.caption(("Pricing units · " if whole_quantities else "Costing units · ") + " · ".join(
            f"{name}: {units[name]['pricing_unit']}" for name in dict.fromkeys(row.get("Flower") for row in records)
            if name in units))
    if not presentation:
        st.dataframe([{
            "Selected flower": row.get("Flower"),
            "Visible-count unit": UNIT_LABELS[units[row["Flower"]]["counting_unit"]] if row.get("Flower") in units else "unresolved",
            "Florist quantity unit": units[row["Flower"]]["pricing_unit"] if row.get("Flower") in units else "unresolved",
        } for row in records], hide_index=True)
    target = actions if actions is not None else st
    if target.button("Save florist review", key="custom_save_review"):
        try:
            if whole_quantities:
                from product_search.selling_pricing import whole_quantity
                for row in records:
                    whole_quantity(row.get("Florist quantity"))
            reviewed = validate_review(records, materials)
            st.session_state.custom_review = reviewed
            st.session_state.custom_review_input = records
        except ValueError as exc:
            st.error(str(exc))
    if st.session_state.get("custom_review_input") == records:
        st.success("Florist review saved in this browser session.")
        st.download_button("Download florist review JSON", json.dumps({
            "provenance": provenance, "model": st.session_state.get("custom_analysis_model"), "analysis": analysis,
            "review": st.session_state.custom_review,
        }, indent=2), file_name="bouquet-review.json", mime="application/json", key="custom_download_review")
    if presentation:
        return st.session_state.get("custom_review_input") == records
    render_mock_costs(materials, provenance, records)
    st.caption("Edits stay in this browser session. A new photo, mode, catalog, live model or analysis resets "
               "the review. Saving does not certify accuracy or create a final quotation.")
