"""Staff catalog management and customer image cards using native Streamlit inputs."""

from html import escape
import sqlite3

import streamlit as st
from PIL import Image

from product_search.custom_bouquet import image_data_url
from product_search.material_store import CATEGORIES, PRICING_UNITS, save_material
from product_search.utils.images import local_image_path


@st.cache_data(show_spinner=False)
def card_thumbnail(image_path, modified_at, size=(720, 540)):
    # Keep card sizing independent of the review UI helper's imported signature.
    try:
        with Image.open(local_image_path(image_path)) as source:
            thumbnail = source.convert("RGB")
            thumbnail.thumbnail(size)
        return image_data_url(thumbnail)
    except (OSError, ValueError):
        return None


def material_card(material, *, staff=False, compact=False, selection=False):
    try:
        source = local_image_path(material["reference_image"])
        thumbnail = card_thumbnail(material["reference_image"], source.stat().st_mtime_ns,
                                   size=(80, 80) if selection else (208, 208) if compact else (720, 540))
    except (OSError, ValueError):
        thumbnail = None
    dimensions = ' width="40" height="40"' if selection else ''
    visual = (f'<img{dimensions} src="{thumbnail}" alt="{escape(material["name"], quote=True)}" loading="lazy">' if thumbnail else
              '<div class="material-placeholder" role="img" aria-label="Material photo coming soon">'
              + ('—</div>' if selection else '<span>blue forest</span><p>Photo coming soon</p></div>'))
    details = f'{escape(material["display_category"])} · per {escape(material["pricing_unit"])}'
    if staff or compact or selection:
        value = material.get("unit_selling_price_hkd")
        details += f' · Selling price HK${float(value):.2f}' if value is not None else ' · Selling price needed'
        if compact or selection:
            details = (f'HK${float(value):.2f} / {material["pricing_unit"]}' if value is not None
                       else 'Selling price needed')
    layout = ' data-layout="selection"' if selection else ' data-layout="compact"' if compact else ''
    chinese = '' if selection else '<p class="material-chinese">' + escape(material["name_zh"]) + '</p>'
    st.html('<article class="material-card"' + layout + '>' + visual + '<div class="material-copy"><h3>' +
            escape(material["name"]) + '</h3>' + chinese + '<p>' + details + '</p>' +
            ('<p class="material-status">' + escape(material["id"]) + ' · ' +
             ('Active' if material["is_active"] else 'Inactive') + '</p>' if staff else '') + '</div></article>')


def open_editor(material_id):
    st.session_state.staff_material_selected = material_id
    st.session_state.staff_material_mode = "Edit material"


def material_form(records, *, create=False):
    prefix = "material_add" if create else "material_edit"
    if create:
        record = {"material_id": "", "name_en": "", "name_zh": "", "color": "", "category": CATEGORIES[0],
                  "pricing_unit": "stem", "unit_cost_hkd": "0.00", "selling_price_hkd": None,
                  "unit_selling_price_hkd": "", "is_active": True}
    else:
        lookup = {row["material_id"]: row for row in records}
        if not lookup:
            st.info("Add your first flower material to get started.")
            return
        if st.session_state.get("staff_material_selected") not in lookup:
            st.session_state.staff_material_selected = next(iter(lookup))
        selected = st.selectbox("Material", list(lookup), key="staff_material_selected",
                                format_func=lambda value: value + " · " + lookup[value]["name_en"])
        record = dict(lookup[selected], category=lookup[selected]["display_category"])
        st.caption("Material IDs are permanent. Set a material to Inactive to remove it from customer selection.")
    # Fresh widget identity after a successful save or change of selected record.
    version = str(st.session_state.get("material_form_generation", 0))
    form_key = prefix + "_" + record["material_id"] + "_" + version
    if not create:
        st.session_state.setdefault(form_key + "_version", record["updated_at"])
        with st.container(horizontal=True, horizontal_alignment="right", key="page_actions_material_reload"):
            reload_material = st.button("Reload material", key="material_reload")
        if reload_material:
            st.session_state.material_form_generation = st.session_state.get("material_form_generation", 0) + 1
            st.rerun()
    with st.form(form_key):
        with st.container(horizontal=True, horizontal_alignment="right", key="page_actions_" + prefix):
            submitted = st.form_submit_button("Add material" if create else "Save material", type="primary")
        values = dict(record)
        if create:
            values["material_id"] = st.text_input("Material ID", key=form_key + "_id", max_chars=40,
                                                  help="Use a new permanent ID, for example FM21.")
        left, right = st.columns(2)
        with left:
            values["name_en"] = st.text_input("English name", record["name_en"], key=form_key + "_en", max_chars=120)
            values["category"] = st.selectbox("Category", CATEGORIES, index=CATEGORIES.index(record["category"]), key=form_key + "_category")
            values["unit_selling_price_hkd"] = st.text_input("Unit selling price (HKD)", str(record.get("unit_selling_price_hkd") or ""), key=form_key + "_selling")
            values["pricing_unit"] = st.selectbox("Pricing unit", PRICING_UNITS, index=PRICING_UNITS.index(record["pricing_unit"]), key=form_key + "_unit")
        with right:
            values["name_zh"] = st.text_input("Chinese name", record["name_zh"], key=form_key + "_zh", max_chars=120)
            values["color"] = st.text_input("Colour", record["color"], key=form_key + "_color", max_chars=120)
            values["is_active"] = st.checkbox("Active · available for customer selection", value=bool(record["is_active"]), key=form_key + "_active")
        upload = st.file_uploader("Material photo · upload or replace", type=["jpg", "jpeg", "png"], key=form_key + "_photo",
                                  help="JPEG or PNG, up to 15 MB and 20 megapixels. Original catalog photos are retained.")
    if submitted:
        try:
            save_material(values, create=create, image_bytes=upload.getvalue() if upload is not None else None,
                          expected_updated_at=None if create else st.session_state[form_key + "_version"])
        except (ValueError, OSError, sqlite3.Error) as exc:
            st.error(str(exc))
        else:
            st.session_state.material_form_generation = st.session_state.get("material_form_generation", 0) + 1
            st.session_state.material_flash = "Material added." if create else "Material saved."
            st.rerun()


def staff_materials(materials):
    st.title("Flower Materials")
    st.write("Care for your flower library, from everyday favourites to seasonal additions.")
    if message := st.session_state.pop("material_flash", None):
        st.success(message)
    mode = st.radio("Material management", ["Material overview", "Edit material", "Add material"],
                    key="staff_material_mode", horizontal=True, label_visibility="collapsed")
    if mode != "Material overview":
        material_form(materials, create=mode == "Add material")
        return
    search, category, availability = st.columns([2, 1, 1])
    query = search.text_input("Search by name", key="staff_material_search").strip().casefold()
    kind = category.selectbox("Category", ["All categories", *CATEGORIES], key="staff_material_category")
    status = availability.selectbox("Availability", ["All materials", "Active", "Inactive"], key="staff_material_status")
    visible = [row for row in materials if (not query or query in (row["name_en"] + " " + row["name_zh"]).casefold())
               and (kind == "All categories" or row["display_category"] == kind)
               and (status == "All materials" or row["is_active"] == (status == "Active"))]
    st.caption(f"{len(visible)} of {len(materials)} materials")
    if not visible:
        st.info("No materials match. Try another name or clear your filters.")
    for start in range(0, len(visible), 3):
        for column, material in zip(st.columns(3), visible[start:start + 3]):
            with column, st.container(key="material_tile_" + material["id"]):
                material_card(material, staff=True)
                st.button("Edit material", key="material_open_" + material["id"], on_click=open_editor,
                          args=(material["id"],), width="stretch")


def update_quantity(material_id, key, draft_key="shop_b_material_draft"):
    st.session_state[draft_key][material_id] = st.session_state[key]


def add_flower(material_id, draft_key="shop_b_material_draft", prefix="shop_b"):
    st.session_state[draft_key][material_id] = 1.0
    st.session_state.pop(prefix + "_quantity_" + material_id, None)


def remove_flower(material_id, draft_key="shop_b_material_draft", prefix="shop_b"):
    st.session_state[draft_key].pop(material_id, None)
    st.session_state.pop(prefix + "_quantity_" + material_id, None)


def replace_flower(material_id, key, same_unit, draft_key="shop_b_material_draft", prefix="shop_b"):
    replacement = st.session_state[key]
    quantity = st.session_state[draft_key].pop(material_id)
    st.session_state[draft_key][replacement] = quantity if same_unit else 1
    for chosen in (material_id, replacement):
        st.session_state.pop(prefix + "_quantity_" + chosen, None)


def selected_material_rows(active, *, draft_key="shop_b_material_draft", prefix="shop_b"):
    """The same compact native controls, isolated for each Customer/Staff draft."""
    draft = st.session_state[draft_key]
    selected = list(draft)
    with st.container(key="material_selected_grid"):
        for material_id in selected:
            material = active[material_id]
            with st.container(key="selected_material_" + material_id):
                material_card(material, selection=True)
                with st.container(key="material_controls_" + material_id):
                    key = prefix + "_quantity_" + material_id
                    st.number_input("Quantity · " + material["name"] + " (" + material["pricing_unit"] + ")",
                                    min_value=0, max_value=10000,
                                    value=int(draft[material_id]) if draft[material_id] is not None else None, step=1,
                                    key=key, on_change=update_quantity, args=(material_id, key, draft_key),
                                    label_visibility="collapsed")
                    with st.container(horizontal=True, gap="small", key="material_actions_" + material_id):
                        st.button("Remove", key=prefix + "_remove_" + material_id, on_click=remove_flower,
                                  args=(material_id, draft_key, prefix), width=74)
                        alternatives = [key for key in active if key not in draft and active[key]["is_active"]]
                        if alternatives:
                            with st.popover("Replace", width=78):
                                replacement_key = prefix + "_replacement_" + material_id
                                replacement = st.selectbox("Replace with", alternatives, key=replacement_key,
                                                           format_func=lambda value: active[value]["name"])
                                same_unit = active[replacement]["pricing_unit"] == material["pricing_unit"]
                                if not same_unit:
                                    st.caption("This material uses a different unit. Its quantity starts at one.")
                                st.button("Use this flower", key=prefix + "_replace_" + material_id, on_click=replace_flower,
                                          args=(material_id, replacement_key, same_unit, draft_key, prefix))


def customer_material_picker(materials, initial_records):
    active = {row["id"]: row for row in materials if row["is_active"]}
    if "shop_b_material_draft" not in st.session_state:
        names = {row["name"]: row["id"] for row in active.values()}
        st.session_state.shop_b_material_draft = {names[row["Flower"]]: row["Quantity"] for row in initial_records
                                                if row.get("Flower") in names}
    draft = st.session_state.shop_b_material_draft
    unavailable = [key for key in draft if key not in active]
    for key in unavailable:
        draft.pop(key)
        st.session_state.pop("shop_b_quantity_" + key, None)
    if unavailable:
        st.info("A material is no longer available and was removed from this draft. Please review your bouquet.")
    st.subheader("Your flower selection")
    st.caption("Choose quantities in the unit shown. A florist reviews your final composition and quotation.")
    if not draft:
        st.info("Choose a flower below to start your bouquet.")
    selected_material_rows(active)
    st.subheader("Add flowers & foliage")
    search, category = st.columns([2, 1])
    query = search.text_input("Find a flower", key="shop_b_material_search").strip().casefold()
    kind = category.selectbox("Flower category", ["All categories", *CATEGORIES], key="shop_b_material_category")
    available = [row for row in active.values() if row["id"] not in draft
                 and (not query or query in (row["name"] + " " + row["name_zh"]).casefold())
                 and (kind == "All categories" or row["display_category"] == kind)]
    if not available:
        st.caption("No more materials match this selection.")
    with st.container(key="material_available_grid"):
        for start in range(0, len(available), 2):
            for column, material in zip(st.columns(2, gap="small"), available[start:start + 2]):
                with column, st.container(key="available_material_" + material["id"]):
                    material_card(material, compact=True)
                    st.button("Add to bouquet", key="shop_b_add_" + material["id"], on_click=add_flower,
                              args=(material["id"],), width="stretch")
    return [{"Flower": active[material_id]["name"], "Quantity": quantity} for material_id, quantity in draft.items()]
