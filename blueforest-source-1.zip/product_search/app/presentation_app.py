"""Single-upload presentation view. Existing workspace is available in the sidebar."""

import hashlib
import json
from html import escape
from pathlib import Path

import streamlit as st
from PIL import ImageOps

from product_search.app.custom_bouquet import UNIT_LABELS, reference_thumbnail, render_florist_review, reset_review
from product_search.app.bouquet_pricing import render_pricing_workflow
from product_search.bouquet_demo import DEMO_NOTICE
from product_search.bouquet_quote import build_mock_quote
from product_search.config import ROOT
from product_search.custom_bouquet import prepare_photo
from product_search.presentation import (
    PRESENTATION_CATALOG, cached_clip_path, load_presentation, presentation_index, presentation_match, search_presentation,
)
from product_search.search.indexes import catalog_fingerprint
from product_search.utils.images import local_image_path, load_image

STEPS = ["Upload or select photo", "Top 3 bouquets", "Flower composition", "Review & calculate", "Customer quotation"]
# Keep the existing review/pricing navigation and widget state. They are two
# parts of the same visible step, with the original save boundary between them.
GUIDED_STEP = {1: 1, 2: 2, 3: 3, 4: 4, 5: 4, 6: 5}
PRICING_INPUT_KEYS = (
    "packaging", "overhead", "labour", "markup", "waste", "delivery_enabled", "delivery",
    "budget_enabled", "budget", "final_price", "delivery_notes", "draft_text", "reviewer", "approved",
)


@st.cache_resource
def local_model():
    from product_search.models.image_embedding import ImageEmbeddingGenerator
    return ImageEmbeddingGenerator(model_path=cached_clip_path())


@st.cache_data(max_entries=8)
def ranked_bouquets(raw, fingerprint):
    model = local_model()
    loader, db, report = presentation_index(model)
    result = search_presentation(raw, model, loader, db)
    result["index_report"] = report
    return result


def go(step):
    if step == 4:
        st.session_state.pop("custom_presentation_editor_base", None)
        st.session_state.custom_review_generation = st.session_state.get("custom_review_generation", 0) + 1
    st.session_state.phase4_step = step
    st.rerun()


def select_sample(sample_id):
    st.session_state.phase4_sample_id = sample_id
    # A new uploader instance clears any older upload when selecting a sample.
    st.session_state.phase4_upload_generation = st.session_state.get("phase4_upload_generation", 0) + 1


def select_upload():
    st.session_state.pop("phase4_sample_id", None)


def clear_photo():
    select_upload()
    st.session_state.phase4_upload_generation = st.session_state.get("phase4_upload_generation", 0) + 1


def render_steps(step):
    current = GUIDED_STEP[step]
    items = []
    for number, label in enumerate(STEPS, 1):
        state = "current" if number == current else "complete" if number < current else "upcoming"
        aria = ' aria-current="step"' if number == current else ""
        items.append(f'<li class="{state}"{aria}><span class="step-number">{number}</span>'
                     f'<span>{label}</span></li>')
    part = " · Cost calculation" if step == 5 else " · Florist review" if step == 4 else ""
    st.html('<nav aria-label="Bouquet workflow"><ol class="workflow-steps">' + "".join(items) + '</ol></nav>'
            f'<p class="workflow-caption">Step {current} of 5 · {STEPS[current - 1]}{part}</p>')


def render_photo_picker(samples, step):
    generation = st.session_state.get("phase4_upload_generation", 0)
    upload_key = f"phase4_upload_{generation}"
    selected = (st.session_state.get("phase4_sample_id") or st.session_state.get("phase4_context")
                or st.session_state.get(upload_key))
    with st.expander("Upload or select a bouquet photo" if not selected else "Change bouquet photo",
                     expanded=step == 1 and not selected):
        upload_column, *sample_columns = st.columns([1.2, 1, 1], gap="large")
        with upload_column:
            st.markdown("#### Your bouquet")
            uploaded = st.file_uploader("Upload Bouquet Photo", type=["jpg", "jpeg", "png"],
                                        max_upload_size=15, key=upload_key, on_change=select_upload)
            st.caption("One photo is shared by Solution A and Solution B. JPG or PNG, up to 15 MB.")
        for column, sample in zip(sample_columns, samples):
            with column:
                image = load_image(str(local_image_path(sample["photo"])), ROOT / "indexes/images")
                st.image(ImageOps.pad(image, (480, 300), color="#ECEFEA"), width="stretch")
                st.markdown(f"#### {escape(sample['name'])}")
                st.button("Try Demo Sample", key="phase4_sample_" + sample["sample_id"],
                          help=f"Load the original {sample['name']} photo for both solutions.",
                          on_click=select_sample, args=(sample["sample_id"],), width="stretch")
                st.caption("Original registered photo · Predefined composition")
        if selected:
            st.button("Clear selected photo", key="phase4_clear_photo", on_click=clear_photo)
    selected_sample = next((sample for sample in samples
                            if sample["sample_id"] == st.session_state.get("phase4_sample_id")), None)
    if selected_sample:
        return local_image_path(selected_sample["photo"]).read_bytes(), "Demo sample"
    return (uploaded.getvalue() if uploaded is not None else None), "Uploaded photo"


def render_composition(materials, analysis, quantities):
    lookup = {material["id"]: material for material in materials}
    cards = []
    for row in analysis["flowers"]:
        material = lookup[row["material_id"]]
        estimate = ((row["usage_category"] or "uncertain").capitalize() + " usage"
                    if row["counting_unit"] == "usage_category" else
                    f"{row['visible_heads']} {UNIT_LABELS[row['counting_unit']]}")
        thumbnail = reference_thumbnail(material)
        reference = f'<img src="{thumbnail}" alt="{escape(material["name"])} reference photo">' if thumbnail else ""
        cards.append(f'<article class="flower-card">{reference}<div><h4>{escape(material["name"])}</h4>'
                     f'<p>{escape(estimate)}</p><p>Plan: {quantities[row["material_id"]]:g} '
                     f'{escape(material["pricing_unit"])}</p><p class="flower-cost">'
                     f'HK${material["mock_unit_cost_hkd"]:.2f} / {escape(material["pricing_unit"])}</p></div></article>')
    st.html('<div class="flower-grid">' + "".join(cards) + '</div>')
    st.caption("Prepared examples · Mock unit costs · Counts are approximate; heads and clusters are separate from florist quantities.")
    with st.expander("Flower details and uncertainty notes"):
        for row in analysis["flowers"]:
            st.write(f"{lookup[row['material_id']]['name']}: {row['uncertainty']}")


def render_credits():
    with st.expander("Photo credits & licenses"):
        st.markdown((ROOT / "data/PRESENTATION_IMAGE_CREDITS.md").read_text())


def main():
    st.set_page_config(page_title="Blue Forest · Presentation Demo", layout="wide", initial_sidebar_state="collapsed")
    full_workspace = st.sidebar.toggle("Full workspace", key="phase4_full_workspace")
    if st.session_state.get("phase4_last_view") != full_workspace:
        reset_review()
        for key in ("phase4_context", "phase4_results", "phase4_sample_id"):
            st.session_state.pop(key, None)
        st.session_state.phase4_step = 1
        st.session_state.phase4_last_view = full_workspace
    if full_workspace:
        from product_search.app.streamlit_app import main as workspace
        workspace()
        return

    # Earlier steps and the Back action don't render pricing widgets. Interrupt
    # Streamlit's widget cleanup on every presentation rerun, until the existing
    # photo/review invalidation explicitly clears these inputs.
    for name in PRICING_INPUT_KEYS:
        key = "phase3b_" + name
        if key in st.session_state:
            st.session_state[key] = st.session_state[key]
    st.html(Path(__file__).with_name("presentation.css"))
    st.title("Blue Forest AI Bouquet Copilot")
    if st.session_state.get("phase4_step", 1) == 1:
        st.caption("From bouquet inspiration to a florist-reviewed quotation · University presentation · Mock Data")
    st.html('<div class="mode-note"><span><strong>Solution A</strong> · Real visual similarity search</span>'
            '<span><strong>Solution B</strong> · Predefined demo simulation, no AI inference</span></div>')
    try:
        materials, samples = load_presentation()
    except (OSError, ValueError) as exc:
        st.error(f"Presentation photos or materials could not be loaded. {exc}")
        return
    step = st.session_state.get("phase4_step", 1)
    workflow = st.container()
    raw, photo_source = render_photo_picker(samples, step)
    if raw is None:
        if st.session_state.get("phase4_context"):
            reset_review()
            st.session_state.pop("phase4_context", None)
            st.session_state.pop("phase4_results", None)
            st.session_state.phase4_step = 1
        with workflow:
            render_steps(1)
        st.caption("Choose Try Demo Sample to use an original registered photo, or upload your own bouquet.")
        render_credits()
        return
    try:
        photo = prepare_photo(raw)
    except ValueError as exc:
        reset_review()
        st.session_state.pop("phase4_context", None)
        st.session_state.pop("phase4_results", None)
        st.session_state.phase4_step = 1
        with workflow:
            render_steps(1)
        st.error(str(exc))
        render_credits()
        return
    context = hashlib.sha256(raw + json.dumps(materials, sort_keys=True).encode()
                             + json.dumps(samples, sort_keys=True).encode()
                             + catalog_fingerprint(PRESENTATION_CATALOG).encode()).hexdigest()
    if st.session_state.get("phase4_context") != context:
        reset_review()
        st.session_state.phase4_context = context
        st.session_state.phase4_step = step = 1
        st.session_state.pop("phase4_results", None)
    result, quantities = presentation_match(raw, samples)
    analysis = result["analysis"] if result else None
    provenance = {key: value for key, value in result.items() if key != "analysis"} if result else {
        "source": "manual_review", "label": DEMO_NOTICE + " · Manual review", "photo_sha256": hashlib.sha256(raw).hexdigest(),
    }
    st.session_state.phase4_provenance = provenance
    st.session_state.custom_analysis = analysis
    st.session_state.custom_provenance = provenance
    st.session_state.custom_analysis_model = None
    name = next((sample["name"] for sample in samples if result and sample["sample_id"] == result["sample_id"]), "Your bouquet")
    with workflow:
        render_steps(step)
    if step == 1:
        preview, description = st.columns([1, 2])
        with preview:
            st.image(ImageOps.pad(photo, (500, 360), color="#ECEFEA"), width="stretch", caption=f"{name} · {photo_source}")
        with description:
            st.subheader("Your bouquet is ready")
            st.write("Find three visually similar bouquets, explore the flower composition, then review the mock costs and quotation.")
            st.caption("This selected photo stays with you through both solutions.")
            if result is None:
                st.info("This photo has no predefined composition. Similarity search still works; flower selection will be manual.")
            if st.button("Find Similar Bouquets", type="primary", key="phase4_search"):
                try:
                    with st.spinner("Finding similar bouquets…"):
                        st.session_state.phase4_results = ranked_bouquets(raw, catalog_fingerprint(PRESENTATION_CATALOG))
                    go(2)
                except (OSError, ValueError, ImportError, RuntimeError) as exc:
                    st.error(f"Photo search is unavailable. {exc}")
        render_credits()
        return

    selected_photo, content = st.columns([1, 4.4], gap="large")
    with selected_photo:
        st.image(ImageOps.pad(photo, (400, 440), color="#ECEFEA"), width="stretch", caption=name)
        st.caption(f"{photo_source} · Shared by Solution A & B")
        if st.button("Back", key="phase4_back", width="stretch"):
            go(step - 1)
    with content:
        render_current_step(step, raw, materials, analysis, quantities, provenance)
    render_credits()


def render_current_step(step, raw, materials, analysis, quantities, provenance):
    if step == 2:
        st.subheader("Solution A · Top 3 similar bouquets")
        results = st.session_state.get("phase4_results")
        if not results or results["upload_sha256"] != hashlib.sha256(raw).hexdigest():
            st.info("Return to the upload step to run the photo search.")
            return
        st.caption("Ranked by genuine CLIP visual similarity · Bouquet names and prices are Mock Data")
        for rank, (column, product) in enumerate(zip(st.columns(3), results["products"]), 1):
            with column:
                image = load_image(product["image_url"], ROOT / "indexes/images")
                st.image(ImageOps.pad(image, (500, 330), color="#ECEFEA"), width="stretch")
                st.markdown(f"#### {rank}. {product['name']}")
                st.write(f"HK${product['price_hkd']:,.2f} · Mock Data")
                st.caption(product["style"])
                st.markdown(f"[Photo: {escape(product['image_creator'])}]({product['image_source_url']}) · "
                            f"[{product['image_license']}]({product['image_license_url']})")
        if st.button("View Flower Composition", type="primary", key="phase4_composition"):
            go(3)
    elif step == 3:
        st.subheader("Solution B · Flower composition")
        st.info(DEMO_NOTICE)
        if analysis is None:
            st.write("No predefined composition matches this file. Continue to select flowers and quantities manually.")
        else:
            render_composition(materials, analysis, quantities)
        if st.button("Review Florist Quantities", type="primary", key="phase4_review"):
            go(4)
    elif step == 4:
        saved = render_florist_review(materials, analysis, provenance, presentation=True, quantities=quantities)
        if st.button("Calculate Mock Costs", type="primary", disabled=not saved, key="phase4_pricing"):
            go(5)
    elif step in (5, 6):
        review = st.session_state.get("custom_review")
        if review is None:
            st.info("Return to Florist Review and save the quantities first.")
            return
        quote = build_mock_quote(review, materials, provenance)
        render_pricing_workflow(quote, presentation=True, show_quotation=step == 6)
        if step == 5 and not quote["issues"]:
            if st.button("Prepare Final Mock Quotation", type="primary", key="phase4_quote"):
                go(6)


if __name__ == "__main__":
    main()
