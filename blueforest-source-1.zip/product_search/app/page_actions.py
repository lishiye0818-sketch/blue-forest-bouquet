"""Shared page controls: navigation on the left, commands on the right."""

import streamlit as st


def page_navigation(key):
    return st.container(horizontal=True, gap="small", key="page_navigation_" + key)


def page_header(title, *, key, caption=None):
    with st.container(key="page_header_" + key):
        navigation = page_navigation(key)
        heading, commands = st.columns([1.2, 1], gap="medium")
        with heading:
            if title:
                st.title(title)
                if caption:
                    st.caption(caption)
        with commands:
            actions = st.container(horizontal=True, horizontal_alignment="right", gap="small",
                                   key="page_actions_" + key)
    return navigation, actions
