"""Offline, hash-bound demonstration fixtures. This module never calls an API."""

import copy
import hashlib
import json
import re
from pathlib import Path

from product_search.config import ROOT
from product_search.custom_bouquet import validate_observations
from product_search.utils.images import local_image_path

DEMO_FIXTURES = ROOT / "data/custom_bouquet_demo.json"
DEMO_NOTICE = "Demo Mode — Predefined Results, No AI Inference"
DEMO_MODE = "Demo Mode (Mock AI, no API calls)"
LIVE_MODE = "Live AI Mode"


def load_demo_samples(materials, path=DEMO_FIXTURES):
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    if (not isinstance(payload, dict) or payload.get("schema_version") != 1
            or payload.get("source") != "predefined_demo" or payload.get("label") != DEMO_NOTICE
            or not isinstance(payload.get("samples"), list) or not payload["samples"]):
        raise ValueError("Demo fixtures need a version, predefined-demo label and sample list.")
    ids, hashes = set(), set()
    for sample in payload["samples"]:
        if not isinstance(sample, dict) or any(
            not isinstance(sample.get(key), str) or not sample[key].strip()
            for key in ("sample_id", "name", "photo", "sha256")
        ):
            raise ValueError("Each demo sample needs an ID, name, photo and SHA-256 hash.")
        if (sample["sample_id"] in ids or sample["sha256"] in hashes
                or not re.fullmatch(r"[0-9a-f]{64}", sample["sha256"])):
            raise ValueError("Demo sample IDs and valid photo hashes must be unique.")
        raw = local_image_path(sample["photo"]).read_bytes()
        if hashlib.sha256(raw).hexdigest() != sample["sha256"]:
            raise ValueError(f"Demo photo changed: {sample['sample_id']}. Verify it before updating its fixture.")
        analysis = validate_observations(sample.get("analysis"), materials)
        if DEMO_NOTICE not in analysis["notes"]:
            raise ValueError("Every demo analysis must explicitly state that no AI inference occurred.")
        sample["analysis"] = analysis
        ids.add(sample["sample_id"])
        hashes.add(sample["sha256"])
    return payload["samples"]


def match_demo_photo(raw, samples):
    """Match original bytes only, never filenames, appearance or a nearest sample."""
    digest = hashlib.sha256(raw).hexdigest()
    sample = next((sample for sample in samples if sample["sha256"] == digest), None)
    if sample is None:
        return None
    return {
        "source": "predefined_demo", "label": DEMO_NOTICE,
        "sample_id": sample["sample_id"], "photo_sha256": digest,
        "analysis": copy.deepcopy(sample["analysis"]),
    }
