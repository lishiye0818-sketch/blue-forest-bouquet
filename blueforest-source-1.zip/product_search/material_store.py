"""Local demo material catalog. SQLite is authoritative after insert-only seeding."""

import csv
import json
import hashlib
from contextlib import contextmanager
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
import os
from pathlib import Path
import re
import sqlite3
from uuid import uuid4

from product_search.config import ROOT
from product_search.custom_bouquet import prepare_photo
from product_search.utils.images import local_image_path

SEED_CSV = ROOT / "data/flower_materials_seed.csv"
DEFAULT_DB = ROOT / "data/flower_materials.sqlite3"
CATEGORIES = ("Main Flower", "Filler", "Greenery")
PRICING_UNITS = ("stem", "portion", "bunch")
# Synthetic classroom costs only, used where the supplied CSV has no cost.
DEMO_COSTS = {"FM09": 18, "FM10": 20, "FM11": 15, "FM12": 28,
              "FM13": 22, "FM14": 38, "FM15": 20, "FM16": 18,
              "FM17": 12, "FM18": 8, "FM19": 24, "FM20": 16}
COLORS = dict(zip((f"FM{i:02}" for i in range(1, 21)), (
    "Yellow", "White", "Purple", "Blue", "White", "Peach pink", "Blue", "Gold",
    "Pink", "White", "Pink", "White", "Yellow", "Pink", "Orange", "Purple",
    "White", "Green", "Orange", "White")))
SCHEMA = {
    "name_en": "TEXT NOT NULL DEFAULT ''", "name_zh": "TEXT NOT NULL DEFAULT ''",
    "category": "TEXT NOT NULL DEFAULT 'Main Flower'", "color": "TEXT NOT NULL DEFAULT ''",
    "pricing_unit": "TEXT NOT NULL DEFAULT 'stem'", "unit_cost_hkd": "TEXT NOT NULL DEFAULT '0.00'",
    "selling_price_hkd": "TEXT", "image_path": "TEXT NOT NULL DEFAULT ''",
    "is_active": "INTEGER NOT NULL DEFAULT 1", "stock_quantity": "REAL",
    "low_stock_threshold": "REAL", "updated_at": "TEXT NOT NULL DEFAULT ''",
    "counting_unit": "TEXT NOT NULL DEFAULT 'flower_head'", "reference_note": "TEXT NOT NULL DEFAULT ''",
    "unit_selling_price_hkd": "TEXT",
}


def database_path():
    return Path(os.environ.get("BLUEFOREST_MATERIAL_DB") or DEFAULT_DB)


def now():
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


@contextmanager
def connect(path=None):
    path = Path(path) if path is not None else database_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(path, timeout=10)
    connection.row_factory = sqlite3.Row
    try:
        with connection:
            yield connection
    finally:
        connection.close()


def initialize_database(path=None, seed_csv=SEED_CSV):
    """Add columns without replacing rows; seed missing IDs without updating Staff edits."""
    with connect(path) as db:
        db.execute("BEGIN IMMEDIATE")
        definitions = ", ".join(f"{key} {definition}" for key, definition in SCHEMA.items())
        db.execute(f"CREATE TABLE IF NOT EXISTS flower_materials (material_id TEXT PRIMARY KEY, {definitions})")
        columns = {row["name"] for row in db.execute("PRAGMA table_info(flower_materials)")}
        if "material_id" not in columns:
            raise ValueError("Existing material database has no material_id; retain it for manual migration.")
        for key, definition in SCHEMA.items():
            if key not in columns:
                db.execute(f"ALTER TABLE flower_materials ADD COLUMN {key} {definition}")
        if "unit_selling_price_hkd" not in columns:
            # One-time migration uses the current Staff-edited values, never seed prices.
            for row in db.execute("SELECT material_id, selling_price_hkd, unit_cost_hkd FROM flower_materials").fetchall():
                value = row["selling_price_hkd"] if row["selling_price_hkd"] is not None else row["unit_cost_hkd"]
                db.execute("UPDATE flower_materials SET unit_selling_price_hkd = ? WHERE material_id = ?",
                           (amount(value, "Unit selling price", optional=True), row["material_id"]))
        db.execute("CREATE TABLE IF NOT EXISTS material_schema (version INTEGER PRIMARY KEY)")
        db.execute("INSERT OR IGNORE INTO material_schema VALUES (1)")
        db.execute("INSERT OR IGNORE INTO material_schema VALUES (2)")
        db.execute("""CREATE TABLE IF NOT EXISTS quotation_snapshots (
            snapshot_id TEXT PRIMARY KEY, enquiry_reference TEXT NOT NULL,
            kind TEXT NOT NULL, snapshot_json TEXT NOT NULL, created_at TEXT NOT NULL)""")
        with Path(seed_csv).open(encoding="utf-8-sig", newline="") as source:
            for row in csv.DictReader(source):
                material_id = row["material_id"]
                category = ("Greenery" if material_id == "FM18" else
                            "Filler" if row["category"] == "filler" else "Main Flower")
                record = validate_material(dict(
                    material_id=material_id, name_en=row["name_en"], name_zh=row["name_zh"],
                    category=category, color=COLORS.get(material_id, ""), pricing_unit=row["pricing_unit"],
                    unit_cost_hkd=row["mock_unit_cost_hkd"] or DEMO_COSTS[material_id],
                    image_path=(f"data/images/flower_materials/{material_id}.png" if row["image_path"] else ""),
                    counting_unit=row["counting_unit"], reference_note=(
                        row["identity_status"] + "; " + row["rights_status"] + "; " + row["asset_status"]),
                    is_active=True))
                fields = ["material_id", *SCHEMA]
                db.execute(f"INSERT INTO flower_materials ({', '.join(fields)}) "
                           f"VALUES ({', '.join('?' for _ in fields)}) ON CONFLICT(material_id) DO NOTHING",
                           [record.get(key) for key in fields])


def amount(value, label, *, optional=False):
    if optional and (value is None or value == ""):
        return None
    try:
        number = Decimal(str(value).strip())
        if not number.is_finite() or not 0 <= number <= 1_000_000_000:
            raise ValueError
        return str(number.quantize(Decimal(".01"), rounding="ROUND_HALF_UP"))
    except (ValueError, InvalidOperation):
        raise ValueError(f"{label} must be a number between 0 and 1,000,000,000.") from None


def validate_material(values):
    record = {key: values.get(key) for key in SCHEMA}
    material_id = str(values.get("material_id") or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,39}", material_id) or material_id.casefold() == "unknown":
        raise ValueError("Use a material ID of up to 40 letters, numbers, hyphens or underscores.")
    record["material_id"] = material_id
    for key in ("name_en", "name_zh", "color", "reference_note"):
        record[key] = str(values.get(key) or "").strip()
        if len(record[key]) > (1000 if key == "reference_note" else 120):
            raise ValueError("Material names and colour must be at most 120 characters.")
    if not record["name_en"] or record["name_en"].casefold() == "unknown":
        raise ValueError("Enter an English material name; Unknown is reserved for florist review.")
    if record["category"] not in CATEGORIES or record["pricing_unit"] not in PRICING_UNITS:
        raise ValueError("Choose a supported category and pricing unit.")
    record["unit_cost_hkd"] = amount(record["unit_cost_hkd"], "Mock unit cost")
    record["selling_price_hkd"] = amount(record["selling_price_hkd"], "Reference selling price", optional=True)
    selling = values.get("unit_selling_price_hkd") if "unit_selling_price_hkd" in values else (
        values.get("selling_price_hkd") if values.get("selling_price_hkd") is not None else values.get("unit_cost_hkd"))
    record["unit_selling_price_hkd"] = amount(selling, "Unit selling price", optional=True)
    image_path = str(values.get("image_path") or "")
    if image_path:
        local_image_path(image_path)  # Never allow remote URLs or paths outside image storage.
    record["image_path"] = image_path
    if type(values.get("is_active", True)) not in (bool, int) or values.get("is_active", True) not in (True, False):
        raise ValueError("Active must be true or false.")
    record["is_active"] = int(values.get("is_active", True))
    for key in ("stock_quantity", "low_stock_threshold"):
        value = values.get(key)
        parsed = amount(value, key, optional=True)
        record[key] = float(parsed) if parsed is not None else None
    record["counting_unit"] = ("usage_category" if record["category"] != "Main Flower" else
                               values.get("counting_unit") if values.get("counting_unit") in
                               ("flower_head", "flower_cluster") else "flower_head")
    record["updated_at"] = now()
    return record


def list_materials(path=None, *, active_only=False):
    with connect(path) as db:
        rows = db.execute("SELECT * FROM flower_materials" + (" WHERE is_active = 1" if active_only else "") +
                          " ORDER BY material_id").fetchall()
    return [dict(row, is_active=bool(row["is_active"])) for row in rows]


def save_material(values, path=None, *, create=False, image_bytes=None, expected_updated_at=None):
    """Keep IDs immutable, reject duplicate names and retain older image files for snapshots."""
    record = validate_material(values)
    photo = prepare_photo(image_bytes) if image_bytes is not None else None
    with connect(path) as db:
        db.execute("BEGIN IMMEDIATE")
        existing = db.execute("SELECT * FROM flower_materials WHERE material_id = ?", (record["material_id"],)).fetchone()
        if create and existing:
            raise ValueError("That material ID already exists. Edit its existing record instead.")
        if not create and not existing:
            raise ValueError("Material no longer exists. Reload the catalog.")
        if existing and expected_updated_at is not None and existing["updated_at"] != expected_updated_at:
            raise ValueError("Another Staff session updated this material. Reopen it before saving.")
        names = db.execute("SELECT material_id, name_en FROM flower_materials").fetchall()
        if create and any(row["material_id"].casefold() == record["material_id"].casefold() for row in names):
            raise ValueError("That material ID already exists. Edit its existing record instead.")
        if any(row["material_id"] != record["material_id"] and
               row["name_en"].casefold() == record["name_en"].casefold() for row in names):
            raise ValueError("That English name already exists. Use a distinct material name.")
        if photo is not None:
            record["image_path"] = f"data/images/material_uploads/{record['material_id']}-{uuid4().hex}.jpg"
            destination = local_image_path(record["image_path"])
            destination.parent.mkdir(parents=True, exist_ok=True)
            photo.save(destination, format="JPEG", quality=90)
        # Preserve inventory values: the Phase 5A UI has no inventory transaction controls.
        if existing:
            for key in ("stock_quantity", "low_stock_threshold"):
                record[key] = existing[key]
        fields = list(SCHEMA)
        if create:
            fields = ["material_id", *fields]
            db.execute(f"INSERT INTO flower_materials ({', '.join(fields)}) VALUES ({', '.join('?' for _ in fields)})",
                       [record[key] for key in fields])
        else:
            db.execute(f"UPDATE flower_materials SET {', '.join(key + ' = ?' for key in fields)} WHERE material_id = ?",
                       [record[key] for key in fields] + [record["material_id"]])
    return record


def pricing_materials(records):
    """Adapter to the established florist review and Decimal cost-plus calculation schema."""
    return [dict(row, id=row["material_id"], name=row["name_en"], reference_image=row["image_path"],
                 mock_unit_cost_hkd=row["unit_cost_hkd"],
                 category="flower" if row["category"] == "Main Flower" else "filler",
                 display_category=row["category"], visual_cues=row["name_en"] + "; " + row["color"])
            for row in records]


def persist_price_snapshot(enquiry_reference, kind, snapshot, path=None):
    """Append immutable public price details; never replace the original request."""
    payload = json.dumps(snapshot, sort_keys=True, ensure_ascii=False)
    snapshot_id = hashlib.sha256((enquiry_reference + kind + payload).encode()).hexdigest()
    with connect(path) as db:
        db.execute("INSERT OR IGNORE INTO quotation_snapshots VALUES (?, ?, ?, ?, ?)",
                   (snapshot_id, enquiry_reference, kind, payload, now()))
    return snapshot_id
