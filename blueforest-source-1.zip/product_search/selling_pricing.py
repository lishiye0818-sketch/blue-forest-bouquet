"""One Decimal selling-price calculation for shop BOMs, DIY and Staff revisions."""

from copy import deepcopy
from decimal import Decimal

from product_search.bouquet_pricing import hkd_input
from product_search.bouquet_quote import money

ZERO_CHARGES = {key: "0.00" for key in ("packaging", "labour", "waste", "markup", "delivery")}


def whole_quantity(value):
    if type(value) not in (int, float, Decimal) or not Decimal(str(value)).is_finite():
        raise ValueError("Quantities must be nonnegative whole numbers.")
    number = Decimal(str(value))
    if number < 0 or number > 10000 or number != number.to_integral_value():
        raise ValueError("Quantities must be whole numbers between 0 and 10,000.")
    return int(number)


def calculate_selling_price(bom, materials, provenance=None):
    """Never infer quantities from images or substitute a missing price with zero."""
    lookup = {row.get("material_id", row.get("id")): row for row in materials}
    lines, seen, total = [], set(), Decimal("0.00")
    for row in bom:
        material_id = row.get("material_id")
        if material_id not in lookup:
            raise ValueError("Choose a known catalog material for every flower.")
        if material_id in seen:
            raise ValueError("Combine duplicate material selections before calculating a price.")
        seen.add(material_id)
        material = lookup[material_id]
        quantity = whole_quantity(row.get("quantity", row.get("Florist quantity")))
        unit = material["pricing_unit"]
        if row.get("pricing_unit", unit) != unit:
            raise ValueError("Material quantities must use the catalog pricing unit.")
        value = material.get("unit_selling_price_hkd")
        name = material.get("name_en", material.get("name", material_id))
        if value is None or value == "":
            raise ValueError(f"The selling price for {name} needs florist confirmation.")
        price = hkd_input(value, "Unit selling price")
        subtotal = price * quantity
        if quantity:
            lines.append({"material_id": material_id, "flower": name, "quantity": quantity,
                          "pricing_unit": unit, "unit_selling_price_hkd": money(price),
                          "line_subtotal_hkd": money(subtotal)})
            total += subtotal
    return {"schema_version": 1, "pricing_method": "unit_selling_prices", "is_mock": True, "currency": "HKD",
            "lines": lines, "total_selling_price_hkd": money(total), "final_reviewed_price_hkd": money(total),
            "charges_hkd": deepcopy(ZERO_CHARGES),
            "provenance": deepcopy(provenance or {"label": "Mock Data — Catalog selling prices"})}
