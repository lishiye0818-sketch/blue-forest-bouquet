"""Persistent simulated shop BOMs; no fixed selling-price column or catalog duplication."""

import csv

from product_search.config import ROOT
from product_search.material_store import connect, list_materials, now
from product_search.selling_pricing import calculate_selling_price


def initialize_shop_bouquets(path=None):
    with connect(path) as db:
        db.execute("BEGIN IMMEDIATE")
        db.execute("""CREATE TABLE IF NOT EXISTS shop_bouquets (
            product_id TEXT PRIMARY KEY, name_en TEXT NOT NULL, name_zh TEXT NOT NULL,
            image_path TEXT NOT NULL, is_active INTEGER NOT NULL DEFAULT 1,
            status TEXT NOT NULL DEFAULT 'draft_staff_review_required', notes TEXT NOT NULL,
            updated_at TEXT NOT NULL)""")
        db.execute("""CREATE TABLE IF NOT EXISTS bouquet_bom (
            product_id TEXT NOT NULL, material_id TEXT NOT NULL, quantity INTEGER NOT NULL CHECK(quantity >= 0),
            pricing_unit TEXT NOT NULL, PRIMARY KEY(product_id, material_id),
            FOREIGN KEY(product_id) REFERENCES shop_bouquets(product_id),
            FOREIGN KEY(material_id) REFERENCES flower_materials(material_id))""")
        db.execute("CREATE TABLE IF NOT EXISTS bouquet_seed_imports (product_id TEXT PRIMARY KEY, imported_at TEXT NOT NULL)")
        with (ROOT / "data/bouquet_products_seed.csv").open(encoding="utf-8", newline="") as source:
            products = list(csv.DictReader(source))
        with (ROOT / "data/bouquet_bom_seed.csv").open(encoding="utf-8", newline="") as source:
            lines = list(csv.DictReader(source))
        for product in products:
            pid = product["product_id"]
            db.execute("INSERT INTO shop_bouquets VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(product_id) DO NOTHING",
                       (pid, product["name_en"], product["name_zh"], f"data/images/shop_bouquets/{pid}.jpg",
                        int(product["is_active"].lower() == "true"), product["status"], product["notes"], now()))
            if db.execute("SELECT 1 FROM bouquet_seed_imports WHERE product_id = ?", (pid,)).fetchone():
                continue
            # An earlier saved composition belongs to Staff, including deliberately removed seed lines.
            if not db.execute("SELECT 1 FROM bouquet_bom WHERE product_id = ?", (pid,)).fetchone():
                for line in lines:
                    if line["product_id"] == pid:
                        db.execute("INSERT INTO bouquet_bom VALUES (?, ?, ?, ?)",
                                   (pid, line["material_id"], int(line["quantity"]), line["pricing_unit"]))
            db.execute("INSERT INTO bouquet_seed_imports VALUES (?, ?)", (pid, now()))


def bouquet_bom(product_id, path=None):
    with connect(path) as db:
        return [dict(row) for row in db.execute(
            "SELECT material_id, quantity, pricing_unit FROM bouquet_bom WHERE product_id = ? ORDER BY rowid", (product_id,))]


def shop_products(path=None, *, active_only=True):
    with connect(path) as db:
        products = [dict(row) for row in db.execute("SELECT * FROM shop_bouquets" +
                    (" WHERE is_active = 1" if active_only else "") + " ORDER BY product_id")]
        materials = [dict(row) for row in db.execute("SELECT * FROM flower_materials")]
        all_lines = [dict(row) for row in db.execute("SELECT * FROM bouquet_bom ORDER BY rowid")]
    result = []
    for row in products:
        bom = [line for line in all_lines if line["product_id"] == row["product_id"]]
        # Unavailable materials never produce a purchasable new shop design.
        inactive = {material["material_id"] for material in materials if not material["is_active"]}
        try:
            if any(line["material_id"] in inactive for line in bom):
                raise ValueError("A material in this bouquet is currently unavailable.")
            snapshot = calculate_selling_price(bom, materials)
            if not snapshot["lines"]:
                raise ValueError("The florist needs to complete this bouquet composition.")
            error = None
        except ValueError as exc:
            snapshot, error = None, str(exc)
        result.append(dict(row, id=row["product_id"], name=row["name_en"], image_url=row["image_path"],
                           is_mock=True, style="Simulated draft composition · Florist review required", colour="To be confirmed",
                           price_hkd=float(snapshot["total_selling_price_hkd"]) if snapshot else None,
                           price_snapshot=snapshot, pricing_error=error))
    return result


def save_bouquet_bom(product_id, bom, path=None, *, expected_updated_at=None):
    with connect(path) as db:
        db.execute("BEGIN IMMEDIATE")
        product = db.execute("SELECT * FROM shop_bouquets WHERE product_id = ?", (product_id,)).fetchone()
        if not product:
            raise ValueError("Choose an existing shop bouquet.")
        if expected_updated_at is not None and product["updated_at"] != expected_updated_at:
            raise ValueError("Another Staff session changed this bouquet. Reload before saving.")
        materials = [dict(row) for row in db.execute("SELECT * FROM flower_materials")]
        quote = calculate_selling_price(bom, materials)
        if not quote["lines"]:
            raise ValueError("Choose at least one material with a positive quantity.")
        db.execute("DELETE FROM bouquet_bom WHERE product_id = ?", (product_id,))
        for line in quote["lines"]:
            db.execute("INSERT INTO bouquet_bom VALUES (?, ?, ?, ?)",
                       (product_id, line["material_id"], line["quantity"], line["pricing_unit"]))
        db.execute("UPDATE shop_bouquets SET updated_at = ? WHERE product_id = ?", (now(), product_id))
    return quote
