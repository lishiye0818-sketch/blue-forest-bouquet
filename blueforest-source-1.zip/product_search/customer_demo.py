"""Two registered customer samples; conservative offline content matching, not AI."""

from copy import deepcopy
from functools import lru_cache
import hashlib

import numpy as np
from PIL import Image

from product_search.bouquet_demo import DEMO_NOTICE, load_demo_samples, match_demo_photo
from product_search.config import ROOT
from product_search.custom_bouquet import prepare_photo
from product_search.material_store import list_materials, pricing_materials
from product_search.utils.images import local_image_path

CUSTOMER_FIXTURES = ROOT / "data/customer_bouquet_demo.json"


def load_customer_samples(materials=None):
    materials = pricing_materials(list_materials()) if materials is None else materials
    samples = load_demo_samples(materials, CUSTOMER_FIXTURES)
    if len(samples) != 2:
        raise ValueError("Customer Demo Mode requires the two registered reference photos.")
    for sample in samples:
        quantities = sample.get("demo_florist_quantities", {})
        if (set(quantities) != {row["material_id"] for row in sample["analysis"]["flowers"]}
                or any(type(value) is not int or not 0 < value <= 10000 for value in quantities.values())):
            raise ValueError("Each customer sample needs an explicit illustrative material composition.")
    return samples


def _descriptor(raw):
    image = prepare_photo(raw)
    pixels = hashlib.sha256(str(image.size).encode() + image.tobytes()).hexdigest()
    small = np.asarray(image.resize((96, 96), Image.Resampling.LANCZOS), dtype=np.float32) / 255
    return image.width / image.height, pixels, small


@lru_cache(maxsize=4)
def _reference_descriptor(photo, expected_sha256):
    raw = local_image_path(photo).read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected_sha256:
        raise ValueError("A registered customer reference photo changed.")
    return _descriptor(raw)


def _result(raw, sample, method):
    return {"source": "predefined_demo", "label": DEMO_NOTICE,
            "sample_id": sample["sample_id"], "sample_name": sample["name"],
            "photo_sha256": hashlib.sha256(raw).hexdigest(), "registered_photo_sha256": sample["sha256"],
            "match_method": method, "analysis": deepcopy(sample["analysis"]),
            "demo_florist_quantities": dict(sample["demo_florist_quantities"])}


def match_customer_photo(raw, samples):
    exact = match_demo_photo(raw, samples)
    if exact:
        sample = next(sample for sample in samples if sample["sample_id"] == exact["sample_id"])
        return _result(raw, sample, "original_sha256")
    aspect, pixels, small = _descriptor(raw)
    candidates = []
    for sample in samples:
        ref_aspect, ref_pixels, ref_small = _reference_descriptor(sample["photo"], sample["sha256"])
        if pixels == ref_pixels:
            return _result(raw, sample, "decoded_pixels")
        if abs(aspect / ref_aspect - 1) > .01:
            continue
        difference = small - ref_small
        # Tight full-frame pixel checks accept ordinary resizing/JPEG encoding,
        # not another bouquet with a similar palette, a crop, or a different view.
        if float(np.abs(difference).mean()) <= .012 and float(np.sqrt(np.mean(difference ** 2))) <= .025:
            candidates.append(sample)
    if len(candidates) == 1:
        return _result(raw, candidates[0], "conservative_resized")
    return None
