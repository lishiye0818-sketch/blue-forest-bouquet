"""Real CLIP/FAISS retrieval over the active SQLite shop catalog, without seed prices."""

import hashlib
import json
import os
from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np
from PIL import Image, ImageOps

from product_search.config import INDEXES_DIR
from product_search.custom_bouquet import prepare_photo
from product_search.models.vector_db import VectorDatabase
from product_search.shop_bouquets import shop_products
from product_search.utils.images import local_image_path, load_image

MODEL_ID = "openai/clip-vit-base-patch32"
TOP_MATCHES = 2
SHOP_EMBEDDING_METHOD = "clip-full-and-center-075-v1"


def shop_image_embedding(image, model, *, full_embedding=None):
    """Give the bouquet centre and the whole photo equal weight for every image.

    Both catalog and query use this same CLIP representation. No reference IDs,
    demo classifications or flower groups participate in similarity ranking.
    """
    image = ImageOps.exif_transpose(image).convert("RGB")
    if full_embedding is None:
        full_embedding = model.generate_embedding_from_pil_image(image)
    side = min(image.size) * .75
    x, y = image.width / 2, image.height / 2
    centre = image.crop((round(x - side / 2), round(y - side / 2),
                         round(x + side / 2), round(y + side / 2)))
    focused = model.generate_embedding_from_pil_image(centre)
    combined = np.asarray(full_embedding, dtype=np.float32) + np.asarray(focused, dtype=np.float32)
    norm = np.linalg.norm(combined)
    if not np.isfinite(combined).all() or not np.isfinite(norm) or norm == 0:
        raise ValueError("The shop image embedding is invalid.")
    return combined / norm


def searchable_shop_products(path=None):
    """Use the same purchasable products and current BOM prices as the shop UI."""
    products = []
    for product in shop_products(path):
        if product["price_hkd"] is None:
            continue
        try:
            with Image.open(local_image_path(product["image_url"])) as image:
                image.verify()
        except (OSError, ValueError):
            continue
        products.append(product)
    return products


def shop_catalog_fingerprint(products):
    # Prices and names remain live database values, not embedding metadata.
    photos = [{"id": product["id"], "image": product["image_url"],
               "sha256": hashlib.sha256(local_image_path(product["image_url"]).read_bytes()).hexdigest()}
              for product in products]
    return hashlib.sha256(json.dumps(photos, sort_keys=True).encode()).hexdigest()


def shop_index(products, model, indexes_dir=INDEXES_DIR):
    fingerprint = shop_catalog_fingerprint(products)
    key = hashlib.sha256((fingerprint + MODEL_ID + SHOP_EMBEDDING_METHOD).encode()).hexdigest()
    root = Path(indexes_dir) / "shop-bouquets"
    destination = root / key
    db = VectorDatabase()
    if destination.exists():
        db.load_indices(destination)
        report = json.loads((destination / "build.json").read_text())
        if report["product_ids"] != [products[position]["id"] for position in db.image_ids]:
            raise ValueError("The shop index does not match its product catalog.")
        return db, report
    report = {"kind": "image", "model": MODEL_ID, "embedding_method": SHOP_EMBEDDING_METHOD,
              "catalog_source": "shop_bouquets",
              "catalog_sha256": fingerprint, "total": len(products), "indexed": 0,
              "product_ids": [], "failed_image_ids": []}
    if not products:
        return db, report
    vectors, ids, failed = model.generate_batch_image_embeddings(
        [product["image_url"] for product in products], root / "images")
    combined, indexed_ids = [], []
    for vector, position in zip(vectors, ids):
        try:
            image = load_image(products[position]["image_url"], root / "images")
            combined.append(shop_image_embedding(image, model, full_embedding=vector))
            indexed_ids.append(position)
        except (OSError, ValueError):
            failed.append(position)
    vectors, ids = np.asarray(combined, dtype=np.float32), indexed_ids
    report.update(indexed=len(ids), product_ids=[products[position]["id"] for position in ids],
                  failed_image_ids=[products[position]["id"] for position in failed])
    if not ids:
        return db, report
    db.add_image_embeddings(vectors, ids)
    root.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix="build-", dir=root) as staging:
        db.save_indices(staging)
        (Path(staging) / "build.json").write_text(json.dumps(report, indent=2))
        try:
            os.rename(staging, destination)
        except OSError:
            if not destination.exists():
                raise
    return db, report


def search_shop_bouquets(raw, model, products, indexes_dir=INDEXES_DIR):
    db, report = shop_index(products, model, indexes_dir)
    matches, distances = [], []
    if report["indexed"]:
        embedding = shop_image_embedding(prepare_photo(raw), model)
        scores, positions = db.search_by_image(embedding, k=TOP_MATCHES)
        matches = [products[position] for position in positions[0]]
        distances = scores[0].tolist()
    return {"upload_sha256": hashlib.sha256(raw).hexdigest(),
            "embedding_method": SHOP_EMBEDDING_METHOD,
            "catalog_source": "shop_bouquets", "catalog_fingerprint": report["catalog_sha256"],
            "ids": [product["id"] for product in matches], "distances": distances,
            "products": matches, "index_report": report}
