"""Presentation assets and real offline CLIP retrieval; no vision or pricing APIs."""

import hashlib
import os
from pathlib import Path

from product_search.bouquet_demo import load_demo_samples, match_demo_photo
from product_search.config import INDEXES_DIR, ROOT
from product_search.custom_bouquet import load_material_catalog, prepare_photo, review_rows, validate_review
from product_search.search.indexes import catalog_fingerprint, load_or_build
from product_search.utils.data_loader import ProductDataLoader

PRESENTATION_CATALOG = ROOT / "data/presentation_bouquets.csv"
PRESENTATION_MATERIALS = ROOT / "data/presentation_materials.json"
PRESENTATION_FIXTURES = ROOT / "data/presentation_demo.json"


def load_presentation():
    materials = load_material_catalog(PRESENTATION_MATERIALS)
    samples = load_demo_samples(materials, PRESENTATION_FIXTURES)
    if len(samples) != 2:
        raise ValueError("The presentation needs exactly two verified sample files.")
    for sample in samples:
        rows = sample["analysis"]["flowers"]
        quantities = sample.get("demo_florist_quantities", {})
        ids = {row["material_id"] for row in rows}
        if not 5 <= len(ids) <= 6 or "unknown" in ids or set(quantities) != ids:
            raise ValueError("Presentation samples need 5–6 catalog materials and independent demo quantities.")
        prepared = review_rows(materials, sample["analysis"])
        for row, observation in zip(prepared, rows):
            row["Florist quantity"] = quantities[observation["material_id"]]
        reviewed = validate_review(prepared, materials)
        if any(row["Florist quantity"] is None or row["Florist quantity"] <= 0 for row in reviewed):
            raise ValueError("Demo florist quantities must be positive and use each material's pricing unit.")
    return materials, samples


def presentation_match(raw, samples):
    result = match_demo_photo(raw, samples)
    if result is None:
        return None, {}
    sample = next(item for item in samples if item["sample_id"] == result["sample_id"])
    return result, dict(sample["demo_florist_quantities"])


def cached_clip_path():
    """Bundle existing cached files locally. Missing files fail instead of downloading."""
    required = ("config.json", "preprocessor_config.json", "tokenizer_config.json", "tokenizer.json",
                "special_tokens_map.json", "vocab.json", "merges.txt", "model.safetensors")
    configured = os.environ.get("BLUEFOREST_CLIP_MODEL_DIR")
    if configured:
        directory = Path(configured).expanduser().resolve()
        if not all((directory / name).is_file() for name in required):
            raise ValueError("The configured CLIP folder is incomplete. Restore its model files before starting.")
        return directory
    locations = [ROOT / "output/huggingface/hub", Path.home() / ".cache/huggingface/hub"]
    for cache in locations:
        snapshots = cache / "models--openai--clip-vit-base-patch32/snapshots"
        found = {}
        for directory in sorted(snapshots.glob("*")):
            for name in required:
                candidate = directory / name
                if candidate.is_file():
                    found[name] = candidate.resolve()
        if len(found) == len(required):
            destination = INDEXES_DIR / "presentation-clip-local"
            destination.mkdir(parents=True, exist_ok=True)
            for name, source in found.items():
                link = destination / name
                if not link.exists():
                    link.symlink_to(source)
            return destination
    raise ValueError("The existing CLIP cache is incomplete. Restore the project's cached model; no download was attempted.")


def presentation_index(model):
    loader = ProductDataLoader(PRESENTATION_CATALOG)
    frame = loader.preprocess_data()
    db, report = load_or_build(PRESENTATION_CATALOG, frame, INDEXES_DIR, "image",
                               "openai/clip-vit-base-patch32", lambda: model)
    if report["indexed"] < 3 or report["failed_image_ids"]:
        raise ValueError("At least three complete reference photos are needed for the presentation.")
    return loader, db, report


def search_presentation(raw, model, loader, db):
    photo = prepare_photo(raw)
    embedding = model.generate_embedding_from_pil_image(photo)
    distances, ids = db.search_by_image(embedding, k=3)
    return {"upload_sha256": hashlib.sha256(raw).hexdigest(),
            "catalog_fingerprint": catalog_fingerprint(PRESENTATION_CATALOG),
            "ids": ids[0].tolist(), "distances": distances[0].tolist(),
            "products": loader.get_product_details(ids[0].tolist())}
