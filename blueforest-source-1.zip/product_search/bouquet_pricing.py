"""Phase 3B mock cost-plus pricing and deterministic, florist-approved quotations."""

import hashlib
import json
from decimal import Decimal, InvalidOperation

from product_search.bouquet_quote import CENT, money

MOCK_DATA_LABEL = "Mock Data — Blue Forest AI Bouquet Copilot"
DRAFT_STATUS = "DRAFT — Florist review required"
MAX_AMOUNT = Decimal("1000000000")
HUNDRED = Decimal("100")


def decimal_input(value, label, maximum=MAX_AMOUNT):
    if type(value) not in (str, int, float, Decimal):
        raise ValueError(f"{label} must be a nonnegative number.")
    try:
        amount = Decimal(str(value).strip())
    except (InvalidOperation, ValueError) as exc:
        raise ValueError(f"{label} must be a valid number.") from exc
    if not amount.is_finite() or amount < 0 or amount > maximum:
        raise ValueError(f"{label} must be finite and between 0 and {maximum}.")
    return amount


def hkd_input(value, label):
    return decimal_input(value, label).quantize(CENT, rounding="ROUND_HALF_UP")


def signature(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def budget_comparison(price, budget):
    if budget is None:
        return {"status": "not_provided", "difference_hkd": None}
    difference = budget - price
    return {"status": "within_budget" if difference >= 0 else "over_budget", "difference_hkd": money(difference)}


def profit_margin(profit, selling_price):
    return money(profit / selling_price * HUNDRED) if selling_price else None


def calculate_pricing(material_quote, *, packaging_cost="0", labour_cost="0", waste_allowance_percent="0",
                      overhead_cost="0", markup_percent="0", delivery_fee=None, customer_budget=None,
                      reviewed_price=None):
    """Delivery is a pass-through cost/charge, added after production-cost markup.

    All HKD inputs and line components round half up to cents. Unknown/missing
    material quantities block pricing; visible counts never enter the calculation.
    """
    if (material_quote.get("is_mock") is not True or material_quote.get("currency") != "HKD"
            or material_quote.get("status") != "draft" or material_quote.get("issues")
            or material_quote.get("complete_materials_total_hkd") is None):
        raise ValueError("Complete and save all florist quantities and resolve Unknown materials before pricing.")
    material = hkd_input(material_quote["complete_materials_total_hkd"], "Material cost")
    packaging = hkd_input(packaging_cost, "Packaging cost")
    labour = hkd_input(labour_cost, "Labour cost")
    overhead = hkd_input(overhead_cost, "Overhead cost")
    waste_percent = decimal_input(waste_allowance_percent, "Waste allowance (%)", HUNDRED)
    markup = decimal_input(markup_percent, "Markup (%)", Decimal("1000"))
    delivery = hkd_input(delivery_fee, "Delivery fee") if delivery_fee is not None else Decimal("0.00")
    budget = hkd_input(customer_budget, "Customer budget") if customer_budget is not None else None
    waste = (material * waste_percent / HUNDRED).quantize(CENT, rounding="ROUND_HALF_UP")
    production = material + waste + packaging + labour + overhead
    total_cost = production + delivery
    markup_amount = (production * markup / HUNDRED).quantize(CENT, rounding="ROUND_HALF_UP")
    suggested = production + markup_amount + delivery
    final_price = suggested if reviewed_price is None else hkd_input(reviewed_price, "Final reviewed price")
    suggested_profit, reviewed_profit = suggested - total_cost, final_price - total_cost
    return {
        "label": MOCK_DATA_LABEL, "currency": "HKD", "is_mock": True, "status": "awaiting_florist_review",
        "material_quote_signature": signature(material_quote),
        "provenance": material_quote["provenance"], "lines": material_quote["lines"],
        "inputs": {"packaging_cost_hkd": money(packaging), "labour_cost_hkd": money(labour),
                   "waste_allowance_percent": str(waste_percent), "overhead_cost_hkd": money(overhead),
                   "markup_percent": str(markup), "delivery_fee_hkd": money(delivery),
                   "delivery_included": delivery_fee is not None,
                   "customer_budget_hkd": money(budget) if budget is not None else None},
        "material_cost_hkd": money(material), "waste_allowance_hkd": money(waste),
        "production_cost_hkd": money(production), "total_estimated_cost_hkd": money(total_cost),
        "markup_amount_hkd": money(markup_amount), "suggested_selling_price_hkd": money(suggested),
        "estimated_gross_profit_hkd": money(suggested_profit),
        "estimated_profit_margin_percent": profit_margin(suggested_profit, suggested),
        "final_reviewed_price_hkd": money(final_price),
        "reviewed_gross_profit_hkd": money(reviewed_profit),
        "reviewed_profit_margin_percent": profit_margin(reviewed_profit, final_price),
        "suggested_budget_comparison": budget_comparison(suggested, budget),
        "reviewed_budget_comparison": budget_comparison(final_price, budget),
        "assumptions": ["Waste applies only to material cost.", "Markup applies to production cost.",
                        "Delivery is a pass-through cost and charge, without markup.",
                        "Estimated gross profit means selling price minus all listed mock costs.",
                        "Tax, supplier availability and actual supplier prices are not verified."],
    }


def quotation_context(pricing, delivery_notes):
    return signature({"pricing": pricing, "delivery_notes": delivery_notes})


def generate_quotation(pricing, delivery_notes, *, allow_zero_price=False):
    """Generate a repeatable customer draft; no model, network or timestamps."""
    if not isinstance(delivery_notes, str) or not delivery_notes.strip() or len(delivery_notes) > 2000:
        raise ValueError("Enter delivery or collection notes (up to 2000 characters).")
    if decimal_input(pricing["final_reviewed_price_hkd"], "Final reviewed price") == 0 and not allow_zero_price:
        raise ValueError("Final reviewed price must be greater than zero before generating a quotation.")
    selected = [{key: line[key] for key in ("material_id", "flower", "quantity", "pricing_unit")}
                for line in pricing["lines"] if line["quantity"] is not None and line["quantity"] > 0]
    if not selected:
        raise ValueError("Select at least one flower with a positive florist-reviewed quantity.")
    summary = ["Flowers and reviewed quantities:"]
    for line in selected:
        quantity = format(Decimal(str(line["quantity"])).normalize(), "f")
        summary.append(f"- {line['flower']}: {quantity} {line['pricing_unit']}")
    summary.extend(["", f"Final reviewed price (HKD, Mock Data): HK${pricing['final_reviewed_price_hkd']}",
                    "Delivery notes: " + delivery_notes.strip()])
    required_summary = "\n".join(summary)
    text = (MOCK_DATA_LABEL + "\n" + DRAFT_STATUS + "\n" + pricing["provenance"]["label"]
            + "\n\nThank you for choosing Blue Forest. Please review your bouquet quotation below.\n\n"
            + required_summary + "\n\nThis university-project quotation uses simulated prices. "
            "Availability and delivery arrangements must be confirmed by the florist.\n")
    return {
        "label": MOCK_DATA_LABEL, "is_mock": True, "currency": "HKD", "status": "draft",
        "human_review_required": True, "provenance": pricing["provenance"], "flowers": selected,
        "final_reviewed_price_hkd": pricing["final_reviewed_price_hkd"], "delivery_notes": delivery_notes.strip(),
        "context_signature": quotation_context(pricing, delivery_notes),
        "required_summary": required_summary, "text": text,
    }


def finalize_quotation(draft, edited_text, *, reviewer_name, review_confirmed, current_context):
    if draft.get("context_signature") != current_context:
        raise ValueError("Pricing or delivery details changed. Generate a new quotation and review it again.")
    if review_confirmed is not True:
        raise ValueError("A florist must explicitly review and approve this quotation before finalizing it.")
    if (not isinstance(reviewer_name, str) or not reviewer_name.strip() or len(reviewer_name) > 80
            or "\n" in reviewer_name or "\r" in reviewer_name):
        raise ValueError("Enter the reviewing florist's name (up to 80 characters).")
    if (not isinstance(edited_text, str) or len(edited_text) > 15000 or MOCK_DATA_LABEL not in edited_text
            or draft["required_summary"] not in edited_text):
        raise ValueError("Keep the Mock Data label and the current flower, price and delivery summary in the draft.")
    customer_text = edited_text.replace(DRAFT_STATUS, "", 1).strip()
    customer_text = "FINALIZED — Florist reviewed (Mock Data)\n" + customer_text + "\n"
    return {**draft, "status": "finalized_mock", "human_review_required": False, "text": customer_text,
            "florist_review": {"approved": True, "reviewer_name": reviewer_name.strip()}}
