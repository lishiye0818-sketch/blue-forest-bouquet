from urllib.parse import urlparse
from pathlib import Path

import numpy as np
import pandas as pd

from product_search.utils.images import local_image_path


BOUQUET_COLUMNS = {"product_name", "image", "description", "price_hkd", "colour", "occasion", "product_url"}


def is_web_url(value):
    parsed = urlparse(str(value))
    return parsed.scheme in {"http", "https"} and bool(parsed.netloc)


class ProductDataLoader:
    def __init__(self, data_path):
        self.data_path = data_path
        self.df = None
        self.is_bouquet = False

    def preprocess_data(self):
        df = pd.read_csv(self.data_path, dtype=str, keep_default_na=False)
        self.is_bouquet = BOUQUET_COLUMNS.issubset(df.columns)
        if self.is_bouquet:
            df["link"] = df["product_url"].str.strip()
            df["product_images"] = df["image"].str.strip()
            df["details"] = df["description"].str.strip()
            price = pd.to_numeric(df["price_hkd"], errors="coerce")
            if not (np.isfinite(price) & (price >= 0)).all():
                raise ValueError("Bouquet price_hkd must contain a finite, nonnegative HKD price for every product.")
            df["price_hkd"] = price
            if "style" not in df:
                df["style"] = "Unspecified"
            for field in ("colour", "style", "occasion"):
                df[field] = df[field].str.strip()
                if not df[field].all():
                    raise ValueError(f"Bouquet {field} must be nonempty for every product.")
            if not df["link"].map(is_web_url).all():
                raise ValueError("Bouquet product_url must contain an HTTP or HTTPS URL for every product.")
            def resolve_image(value):
                if not value or is_web_url(value):
                    return value
                try:
                    return str(local_image_path(value, Path(self.data_path).resolve().parent))
                except ValueError as exc:
                    raise ValueError("Bouquet image must use HTTP(S) or a path inside data/images.") from exc
            df["product_images"] = df["product_images"].map(resolve_image)
        mock = df.get("is_mock", pd.Series("false", index=df.index)).str.strip().str.lower()
        if not mock.isin(["true", "false"]).all():
            raise ValueError("is_mock must be true or false.")
        df["is_mock"] = mock.eq("true")
        required = {"product_name", "link", "product_images", "details"}
        if not required.issubset(df.columns) or df.empty:
            raise ValueError("Catalog must use the original product_name/link/product_images/details schema or the bouquet product_name/image/description/price_hkd/colour/occasion/product_url schema.")
        if not df["product_name"].str.strip().all() or not df["link"].is_unique:
            raise ValueError("Products need nonempty names and unique links.")
        df["image_url"] = df["product_images"].str.strip()
        df["details"] = df["details"].str.replace("View more", "", regex=False).str.strip()
        df["text_for_embedding"] = df["product_name"] + ". " + df["details"]
        if self.is_bouquet:
            df["text_for_embedding"] += ". Colour: " + df["colour"] + ". Style: " + df["style"] + ". Occasion: " + df["occasion"]
        self.df = df.reset_index(drop=True)
        return self.df

    def get_product_details(self, product_indices):
        if self.df is None:
            self.preprocess_data()
        products = []
        for idx in product_indices:
            if not 0 <= idx < len(self.df):
                raise ValueError(f"Unknown product ID: {idx}")
            row = self.df.iloc[idx]
            product = {"id": int(idx), "name": row["product_name"], "details": row["details"],
                       "image_url": row["image_url"], "link": row["link"], "is_mock": bool(row["is_mock"])}
            if self.is_bouquet:
                product.update(price_hkd=float(row["price_hkd"]), colour=row["colour"], style=row["style"], occasion=row["occasion"])
                for field in ("image_creator", "image_license", "image_license_url", "image_source_url"):
                    product[field] = row.get(field, "")
            products.append(product)
        return products
