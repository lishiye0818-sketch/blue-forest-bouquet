import hashlib
from io import BytesIO
from pathlib import Path
from urllib.parse import urlparse

import requests
from PIL import Image, ImageOps

from product_search.config import ROOT


LOCAL_IMAGE_ROOT = ROOT / "data" / "images"


def local_image_path(source, base_dir=ROOT):
    """Resolve catalog paths, confining local reads to the project's image assets."""
    if not source or urlparse(str(source)).scheme:
        raise ValueError("Local image must be a path under data/images, without a URI scheme.")
    path = (Path(base_dir) / source).resolve()
    if not path.is_relative_to(LOCAL_IMAGE_ROOT.resolve()):
        raise ValueError("Local product images must stay inside data/images.")
    return path


def image_source_available(source):
    parsed = urlparse(str(source))
    if parsed.scheme in {"http", "https"}:
        return bool(parsed.netloc)
    try:
        return local_image_path(source).is_file()
    except ValueError:
        return False


def load_image(url, cache_dir):
    url = str(url)
    if not urlparse(url).scheme:
        path = local_image_path(url)
        if path.stat().st_size > 15 * 1024 * 1024:
            raise ValueError("Image exceeds 15 MB.")
        with Image.open(path) as image:
            return ImageOps.exif_transpose(image).convert("RGB")
    if urlparse(url).scheme not in {"http", "https"}:
        raise ValueError("Product image must use HTTP, HTTPS, or a local data/images path.")
    path = Path(cache_dir) / (hashlib.sha256(url.encode()).hexdigest() + ".jpg")
    if path.exists():
        with Image.open(path) as image:
            return image.convert("RGB")
    with requests.get(url, timeout=(5, 15), stream=True) as response:
        response.raise_for_status()
        chunks = bytearray()
        for chunk in response.iter_content(65536):
            chunks.extend(chunk)
            if len(chunks) > 15 * 1024 * 1024:
                raise ValueError("Image exceeds 15 MB.")
    with Image.open(BytesIO(chunks)) as source:
        image = ImageOps.exif_transpose(source).convert("RGB")
    path.parent.mkdir(parents=True, exist_ok=True)
    image.save(path, format="JPEG", quality=95)
    return image
