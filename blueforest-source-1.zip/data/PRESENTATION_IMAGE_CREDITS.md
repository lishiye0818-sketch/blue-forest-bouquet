# Presentation photo credits

All bouquet names, compositions, counts, material plans and HKD prices in this demo are illustrative Mock Data. Photos are licensed reference images, not Blue Forest inventory. No image-generation API was used.

## Prepared uploads and derived reference details

- **Vimukthi — Dahlia roses and calas..jpg** · [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0) · [Original source](https://commons.wikimedia.org/wiki/File:Dahlia_roses_and_calas..jpg).
  Files: `data/images/presentation/uploads/01-peach-harmony.jpg`, `data/images/presentation/materials/calla_lily.jpg`, `data/images/presentation/materials/dahlia.jpg`, `data/images/presentation/materials/craspedia.jpg`, `data/images/presentation/materials/tulip.jpg`. Resized JPEGs retain the complete upload composition; material references are cropped. Derivatives retain the source license.

- **Aw58 — Bukiet kwiatów - 2024.03.16.jpg** · [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) · [Original source](https://commons.wikimedia.org/wiki/File:Bukiet_kwiat%C3%B3w_-_2024.03.16.jpg).
  Files: `data/images/presentation/uploads/02-sunshine-garden.jpg`, `data/images/presentation/materials/greenery.jpg`, `data/images/presentation/materials/gerbera.jpg`, `data/images/presentation/materials/sunflower.jpg`, `data/images/presentation/materials/carnation.jpg`. Resized JPEGs retain the complete upload composition; material references are cropped. Derivatives retain the source license.

- **Photo by and (c)2007 Jina Lee — Rose hydrangea calla wedding bouquet.jpg** · [CC BY-SA 3.0](http://creativecommons.org/licenses/by-sa/3.0/) · [Original source](https://commons.wikimedia.org/wiki/File:Rose_hydrangea_calla_wedding_bouquet.jpg).
  Files: `data/images/presentation/references/peach-calla-hydrangea.jpg`. Resized JPEGs retain the complete upload composition; material references are cropped. Derivatives retain the source license.

- **Senarathane — Gerbera roses and tulips.jpg** · [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0) · [Original source](https://commons.wikimedia.org/wiki/File:Gerbera_roses_and_tulips.jpg).
  Files: `data/images/presentation/references/sunset-mixed-bouquet.jpg`. Resized JPEGs retain the complete upload composition; material references are cropped. Derivatives retain the source license.

## Existing reference-catalog photos

These photos retain their existing attribution and licenses in [IMAGE_CREDITS.md](IMAGE_CREDITS.md):

- Vimukthi · [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0) · [Hydrangea Blush](https://commons.wikimedia.org/wiki/File:Chrysanthemum_hydrangea.jpg).
- BEST Bud's for Life · [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) · [Spring Festival](https://commons.wikimedia.org/wiki/File:COLORFUL_SPRING_BOUQUET.jpg).
- Carlos Gracia · [CC BY 2.0](https://creativecommons.org/licenses/by/2.0) · [Toffee & Ivory](https://commons.wikimedia.org/wiki/File:Bouquet_(11286338495).jpg).
- Aw58 · [CC BY 4.0](https://creativecommons.org/licenses/by/4.0) · [Peach Rose Table](https://commons.wikimedia.org/wiki/File:Bukiet_r%C3%B3%C5%BC_%C5%82ososiowych_w_wazonie_-_28.04.2026.jpg).
- Tejeshmavinamar · [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) · [Coral Rose Glow](https://commons.wikimedia.org/wiki/File:Colourfull_roses.jpg).
- Vimukthi · [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0) · [Sculptural Spring](https://commons.wikimedia.org/wiki/File:Celosia_Anthurium_Tulips.jpg).

## Additional mixed-bouquet reference photos

- **Missvain — Birthday flower bouquet - 2021-08-26 - Sarah Stierch.jpg** · [CC BY 4.0](https://creativecommons.org/licenses/by/4.0) · [Original source](https://commons.wikimedia.org/wiki/File:Birthday_flower_bouquet_-_2021-08-26_-_Sarah_Stierch.jpg). File: `data/images/presentation/references/golden-garden.jpg`. Licensed thumbnail re-encoded; no generated content.
- **Yugulolly0542 — Flower Bouquet (40780).jpg** · [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en) · [Original source](https://commons.wikimedia.org/wiki/File:Flower_Bouquet_(40780).jpg). File: `data/images/presentation/references/rose-daisy.jpg`. Licensed thumbnail re-encoded; no generated content.

## Phase 4B catalog refresh

- **PattayaPatrol — Bright bouquet of pink roses and a cheerful sunflower** · [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) · [Original source](https://commons.wikimedia.org/wiki/File:DFC_0794_Bright_bouquet_of_pink_roses_and_a_cheerful_sunflower_arranged_with_greenery_on_a_golden_surface.jpg). File: `data/images/presentation/references/rose-sunflower.jpg`. Re-encoded as JPEG with the complete composition retained and metadata removed; derivative remains CC BY-SA 4.0. Replaces the vase/table reference in the eight-photo presentation catalog. The original reference remains available in the full workspace.
