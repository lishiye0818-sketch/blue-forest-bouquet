# Bouquet photo credits and reuse records

These are licensed illustrative photos for fictional mock products. They do not depict verified Blue Forest merchandise and the photographers do not endorse this project. All product names, HKD prices and occasion tags are examples.

Photos were downloaded on 2026-10-25 from Wikimedia Commons only after checking each file’s image license metadata. The downloaded files are Wikimedia thumbnails; the originals are linked in `image-sources.json`. No creative edits were made. Streamlit resizes and pads photos for display. CC BY-SA photos and any adapted versions remain available under their respective CC BY-SA licenses; the repository’s code license does not replace these image licenses.

`image-sources.json` records the creator, file page, original/download URL, image license, changes and SHA-256 for every local asset.

| Local asset | Title / creator | License | Source |
| --- | --- | --- | --- |
| `data/images/bouquet-01.jpg` | Cala lilies and tulips.jpg — Vimukthi | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0) | [File page](https://commons.wikimedia.org/wiki/File:Cala_lilies_and_tulips.jpg) |
| `data/images/bouquet-02.jpg` | Carnations and alstromeria.jpg — Hellacious2 | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [File page](https://commons.wikimedia.org/wiki/File:Carnations_and_alstromeria.jpg) |
| `data/images/bouquet-03.jpg` | Celosia Anthurium Tulips.jpg — Vimukthi | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0) | [File page](https://commons.wikimedia.org/wiki/File:Celosia_Anthurium_Tulips.jpg) |
| `data/images/bouquet-04.jpg` | Chrysanthemum hydrangea.jpg — Vimukthi | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0) | [File page](https://commons.wikimedia.org/wiki/File:Chrysanthemum_hydrangea.jpg) |
| `data/images/bouquet-05.jpg` | COLORFUL SPRING BOUQUET.jpg — BEST Bud's for Life | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [File page](https://commons.wikimedia.org/wiki/File:COLORFUL_SPRING_BOUQUET.jpg) |
| `data/images/bouquet-06.jpg` | Calendula Flowers- May 2024.jpg — MDNAciccone | [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en) | [File page](https://commons.wikimedia.org/wiki/File:Calendula_Flowers-_May_2024.jpg) |
| `data/images/bouquet-07.jpg` | Bouquet of red and yellow roses.jpg — Karthika Manikandan | [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en) | [File page](https://commons.wikimedia.org/wiki/File:Bouquet_of_red_and_yellow_roses.jpg) |
| `data/images/bouquet-08.jpg` | Bouquet (11286338495).jpg — Carlos Gracia | [CC BY 2.0](https://creativecommons.org/licenses/by/2.0) | [File page](https://commons.wikimedia.org/wiki/File:Bouquet_(11286338495).jpg) |
| `data/images/bouquet-09.jpg` | Białe róże - 20.33.2026.jpg — Aw58 | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0) | [File page](https://commons.wikimedia.org/wiki/File:Bia%C5%82e_r%C3%B3%C5%BCe_-_20.33.2026.jpg) |
| `data/images/bouquet-10.jpg` | Bukiet róż łososiowych w wazonie - 28.04.2026.jpg — Aw58 | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0) | [File page](https://commons.wikimedia.org/wiki/File:Bukiet_r%C3%B3%C5%BC_%C5%82ososiowych_w_wazonie_-_28.04.2026.jpg) |
| `data/images/bouquet-11.jpg` | Colourfull roses.jpg — Tejeshmavinamar | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [File page](https://commons.wikimedia.org/wiki/File:Colourfull_roses.jpg) |
| `data/images/bouquet-12.jpg` | Lavande lavender bouquet.jpg — Wisi eu | [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en) | [File page](https://commons.wikimedia.org/wiki/File:Lavande_lavender_bouquet.jpg) |
| `data/images/references/independent-rose-bouquet.jpg` | Fresh flower bouquet.jpg — Cendy00 | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0) | [File page](https://commons.wikimedia.org/wiki/File:Fresh_flower_bouquet.jpg) |

The reference-only photo is independently photographed by Cendy00 and is excluded from the catalog and index. It is not a crop, edit or recompression of a catalog photo.

Blue Forest’s official site was inspected at https://blueforestflora.com/ on 2026-10-25. Product information was available, but no permission to reuse its photos was established. No Blue Forest product photos were downloaded or bundled. Obtain authorization and verify complete product records before substituting real merchandise.
