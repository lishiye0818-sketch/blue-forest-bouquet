# Phase 3A material reference photo credits

These illustrative reference photos are for human comparison, not verified supplier materials or model training. The flower catalog also reuses four existing licensed bouquet photos; their credits remain in [IMAGE_CREDITS.md](IMAGE_CREDITS.md) and `image-sources.json`.

New reference thumbnails downloaded from Wikimedia Commons on 25 October 2026. No additional edits were made; Streamlit resizes them for display. CC BY-SA images retain their respective licenses; the code license does not replace image licenses.

| Local asset | Creator | License | Source |
| --- | --- | --- | --- |
| `data/images/materials/lily.jpg` | Ruff tuff cream puff | [CC0](http://creativecommons.org/publicdomain/zero/1.0/deed.en) | [Lilium pearl jessica.jpg](https://commons.wikimedia.org/wiki/File:Lilium_pearl_jessica.jpg) |
| `data/images/materials/lisianthus.jpg` | Yercaud-elango | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | [Eustoma grandiflorum-hrs-yercaud-salem-India.JPG](https://commons.wikimedia.org/wiki/File:Eustoma_grandiflorum-hrs-yercaud-salem-India.JPG) |
| `data/images/materials/babys_breath.jpg` | Avenue | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0) | [Close-up of baby's breath (Gypsophila paniculata) flowers.jpg](https://commons.wikimedia.org/wiki/File:Close-up_of_baby%27s_breath_(Gypsophila_paniculata)_flowers.jpg) |

`material-image-sources.json` records source/download URLs, licenses, changes and SHA-256 hashes. Garden photos show a particular cultivar and lighting, not the full range of commercial cut-flower appearances. Reference photos are not additional model inputs.
