# Phase 4D — Homepage hero and entry navigation

Git checkpoint before changes: **`c6ad39d`**, preserving the complete Phase 4C
implementation and all 121 tests.

Start the same customer application:

```bash
.venv/bin/python -m streamlit run product_search/app/customer_app.py --server.port 8504
```

## Presentation and navigation

| Before | After |
| --- | --- |
| Homepage opens with two ordering cards and the full navigation | A simple centred Blue Forest wordmark opens the page; additional navigation sits below the choices in More navigation |
| Short introductory headline above sample images | Full-width supplied floral photograph with "Every Bouquet Begins With an Idea" and "Upload your inspiration and discover the perfect bouquet for your occasion." |
| No central homepage action | One prominent Shop Flowers link moves to the next section at `#shop-flowers` |
| Ordering choices occupy the first screen | Equal cards in a dedicated next section: Find Similar Bouquets and Create Your Own Bouquet, with the requested descriptions |
| Homepage uses the application's bounded content width | The photograph fills the viewport width; the choice section and footer retain a readable maximum width |
| General application typography and navigation above the content | Existing Georgia serif enlarged for the hero, ivory text, a botanical overlay, and a single ivory CTA; Streamlit toolbar omitted from the landing view |
| Existing responsive card layout | Hero heading scales with the viewport, the floral crop adapts on narrow screens, and the equal ordering cards continue to stack on mobile |

Shop Flowers uses a standard same-page anchor, with a focusable destination and
normal browser history. It needs no JavaScript bridge, external page or second
application. The choices retain their original Streamlit callbacks and independent
journey state. Home, Find Similar, Custom Bouquet and Staff Review navigation is
unchanged on the ordering screens.

The hero keeps visible content static on load. Buttons retain the established
press feedback, keyboard focus and reduced-motion support. There are no icons,
menus, technical controls or simulated recognition claims competing with the hero.
Mock prices, predefined recognition notices and local-enquiry notices remain in
the appropriate ordering sections and screens.

## Supplied image

The original user attachment is copied without alteration to
`product_search/app/assets/blue-forest-floral-hero.png` and served from the local
application. SHA-256 of both the attachment and copied asset:

`437345985d141abe3900dddcc2f58263606463ad5b43eaffd43c28f1782c92e4`

The CSS crop and overlay change only the on-screen presentation. The image is
decorative behind real HTML text, with an empty alt attribute. It is not added
to the similarity catalogue or recognition fixtures. No generated image,
external image request, font download, model installation or paid API is used.

## Verification

**All existing 121 tests passed in 47.130 seconds. No existing tests were edited
or removed.** This includes both samples through both independent ordering paths,
real local retrieval, customer-price privacy, florist review, pricing approval,
quotation and local enquiries. The customer-only subset also passed all 12 tests.

```bash
.venv/bin/python -m unittest discover -s tests -v
```

Actual browser checks at `http://localhost:8504/` confirmed:

- The supplied hero image loads locally at its original resolution; the hero
  spans all 1280 px of the desktop viewport.
- The complete required branding, headline, subtitle and Shop Flowers action
  are visible together at 1280 × 720 and at the tested 411 px mobile width.
- Shop Flowers changes the fragment to `#shop-flowers` and brings the next
  section into view, with its heading about 32 px below the viewport top.
- On desktop, both option buttons are visible together at equal widths of
  486 px. Their callbacks reach the existing Find Similar and Custom Bouquet
  screens independently.
- A sample selected in Find Similar remains selected when entering Custom
  Bouquet through Home → Shop Flowers → Create Your Own Bouquet.
- No horizontal page overflow is present on the desktop or mobile homepage.

Browser screenshots are under `output/phase4d-ux/`; regression output is in
`output/phase4d-all-tests.log`.

Only the customer frontend, its local image asset and documentation changed.
CLIP/FAISS ranking, sample JPEGs, recognition fixtures, Demo/Live AI modes,
material review, costing, approval and quotation modules remain unchanged.
The Phase 4C local-only business-system limits continue to apply; this phase
adds no external orders, payments or submissions.
