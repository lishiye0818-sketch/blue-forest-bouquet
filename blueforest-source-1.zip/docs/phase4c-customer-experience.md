# Phase 4C — Blue Forest customer experience

The customer application now offers two parallel ordering options. Neither
requires entering the other. The existing search, demo fixtures, florist review,
pricing calculations, approval rules and original tests remain unchanged.

Git checkpoint before this work: `436b72e` on
`codex/phase4-presentation-demo` (Phase 4B presentation UX).

## Start and navigate

```bash
.venv/bin/python -m streamlit run product_search/app/customer_app.py --server.port 8504
```

Home presents equally sized **Find a Similar Bouquet** and **Create Your Own
Bouquet** cards. The main navigation always offers **Home**, **Find Similar**,
**Custom Bouquet** and **Staff Review**. Each ordering option has its own progress
indicator, saved selection and enquiry. One selected reference photo is shared
across both options within the session. Replacing it clears stale designs,
selections and approvals.

| Before | Phase 4C |
| --- | --- |
| One presentation sequence combining Solution A and B | Two independent customer journeys from equal homepage choices |
| Recognition, costing and quotation controls on a long page | Short customer stages and a separate staff workspace |
| Internal costs mixed with demonstration steps | Customers see only selling prices; staff retain the full cost calculation |
| Technical outputs at the end of the demo | Local enquiry form, confirmation and safe customer summary download |

The ivory and botanical palette, consistent photo frames, compact flower cards
and grouped pricing tables use the existing Python/Streamlit application. The
two homepage photos are decorative crops; the original JPEGs are unchanged and
full reference previews remain available in the ordering flows.

## Find a Similar Bouquet — Solution A

1. Start from Home or **Find Similar**.
2. Upload a JPEG/PNG, or use either **Try Demo Sample** button. Both buttons load
   the original registered sample bytes.
3. Select **Find similar bouquets** to run the existing offline CLIP + FAISS
   ranking. The Top 3 product cards show consistent images, mock prices and a
   **Select Bouquet** button. No products or ranking positions are hardcoded.
4. Select a bouquet, review its price and continue to preferences.
5. Enter a demo name/contact, collection or delivery preferences, and create a
   **mock order enquiry**. Delivery requires an address or delivery area.
6. The confirmation displays a local reference, price and preferences. Its JSON
   summary contains customer information and product selection only.

This path does not run composition analysis, request florist approval, or enter
the custom ordering path.

## Create Your Own Bouquet — Solution B

1. Start from Home or **Custom Bouquet** and choose or reuse a reference photo.
2. Select **Explore flower composition**. Registered samples use the original
   fixtures under **Demo Mode — Predefined Results, No AI Inference**. An
   unregistered photo has no prepared recognition result and uses manual flower
   selection instead.
3. **Flower inspiration** shows approximate observations. **Edit my bouquet**
   lets the customer change flower types and requested quantities. Visible flower
   heads remain separate from stems, bunches and portions used for pricing.
4. Continue to a preliminary selling estimate, labelled **Mock Data**, then
   request florist confirmation. Incomplete designs wait for florist review.
5. In this local demo, open **Staff Review** to simulate the florist. Save the
   identification/quantity review, review pricing, generate a quotation, enter a
   reviewer and explicitly approve before finalizing it.
6. Return to customer confirmation to see final flowers and the reviewed selling
   price, then complete the custom mock enquiry form.

The original predefined plans still produce HK$881.55 for Peach Harmony and
HK$533.40 for Sunshine Garden under the established presentation defaults.
Edits to the plan or staff pricing withdraw previous approval and invalidate a
stale custom enquiry. This path does not call similarity search or require an
existing product selection.

## Customer and staff separation

Customer screens and enquiry downloads are built from an explicit public field
projection. They show flower names, quantities, units, catalogue/preliminary/
reviewed selling prices and delivery notes. They do not include material costs,
labour, overhead, markup, profit, internal reviews or arbitrary editable staff
quotation text.

Staff Review reuses the existing Phase 3B review, cost, pricing and quotation
modules. Staff retain material quantity adjustments, internal cost tables,
pricing overrides, draft editing and approval-gated quotation downloads. A
customer cannot advance to a custom enquiry before a current staff-approved
mock quotation exists.

Under **Original technical tools & Live AI**, staff can open:

- `?workspace=technical`: the original search application, Demo Mode and Live AI
  mode with its existing explicit request controls.
- `?workspace=presentation`: the original Phase 4B presentation.

These open separate sessions. They preserve the original technical functionality;
their working state is not synchronized into the new customer journey. The
customer demo itself makes no Live AI calls. No new model, package, paid API or
business integration was installed or invoked for this redesign. Existing photo
licences and credits are preserved in `data/PRESENTATION_IMAGE_CREDITS.md` and
the application's Photography credits panel.

## Verification

Run the full suite:

```bash
.venv/bin/python -m unittest discover -s tests -v
```

Final regression result: **121 tests passed in 49.185 seconds**. The suite
contains all 109 existing tests plus 12 customer experience tests.
The new integration tests block network requests and use the existing local
search assets. Coverage includes:

- Both original sample photos through Solution A independently, including real
  sorted Top 3, selection, price, preferences and enquiry.
- Both original sample photos through Solution B independently, including flower
  suggestions, estimate, staff review, pricing, quotation approval and enquiry.
- Equal homepage choices, shared-photo reuse and photo replacement invalidation.
- Customer quantity editing, staff quantity changes and preservation across
  navigation; approval withdrawal when a plan or price changes.
- Required form fields, delivery address validation, and preferences retained
  while navigating away and back.
- Blocked progression before staff review/quotation approval; safe customer
  rendering and downloads with no internal cost fields.
- Availability of the original technical workspace, Live AI selector and
  original presentation without making any live requests.

Actual browser checks also completed both independent journeys from a fresh
homepage. Solution A used Peach Harmony, displayed the real Top 3 and created a
mock enquiry for the selected Hydrangea Blush at HK$680.00. Solution B used
Sunshine Garden, blocked enquiry before approval, completed Staff Review and
created a custom mock enquiry at HK$533.40. Browser checks confirmed internal
costs are visible in Staff Review and absent from customer confirmation/enquiry
screens, with no horizontal page overflow at the tested desktop viewport.
At 1280 × 720, both homepage action cards and buttons are visible together.
The live customer entrypoint at port 8504 was also checked at 333 px width:
navigation wraps into two rows and the product cards stack without horizontal
overflow.

Screenshots and regression logs are stored under `output/phase4c-ux/` and
`output/phase4c-all-tests.log` respectively. These are local verification
artifacts, not application data.

## Limits requiring business systems

The enquiry confirmation is a local simulation: no email, CRM submission,
payment, reservation or real order is created. Enquiries and staff approval
exist only in the active Streamlit session; there is no shared staff queue,
durable customer record or notification service. Staff Review is a labelled
demonstration view with no account authentication or role-based access control.
The customer/staff separation is an interface boundary, not a security boundary.

A production service needs authenticated staff/customer accounts, persistent
enquiry and quotation records, an approved product/inventory and pricing source,
real florist assignment/approval, delivery availability, and authorized customer
communications. These cannot be reliably implemented or verified against real
business operations without access to those systems and agreed business rules.
