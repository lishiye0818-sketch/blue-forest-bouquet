# Customer navigation and florist replies

Checkpoint before editing: `b2a696c`.

| Before | After |
| --- | --- |
| Back to Home and Choose another bouquet beneath the history, close to the decision buttons | Compact secondary navigation at the top left, before the enquiry heading. Custom enquiries use the same placement for Create another design. Original keys and callbacks are retained. |
| Florist message beside the bouquet | Public replies are shown under the relevant proposal entry in Enquiry history, beside that entry's timestamp and selling price. Replies are also removed from the Staff summary panel and included in Staff history. |
| Only the latest public reply shown in the overview | Every newly published proposal records its own reply and proposal version. Older session events recover replies from their saved proposal snapshots, including same-price revisions. Display recovery does not rewrite old history or copy the latest reply onto every entry. |
| Reply hidden inside an initially collapsed history | Awaiting proposals with a public reply open history automatically; it remains collapsible. Other history disclosures retain their usual behaviour. |
| Navigation wraps with a large gap on narrow screens | A 12px gap between navigation controls, with graceful wrapping at smaller widths. At 411px both controls fit on one line. |

Only the public reply and proposal-version fields were added to the existing
proposal history event. Price calculations, matching, approval requirements,
version-bound customer decisions and enquiry state transitions are unchanged.
The customer projection still rejects internal events/details, and all reply text
is escaped before HTML display. No reply is sent externally.

## Verification

- **145 tests passed in 80.423 seconds**: all 143 existing checks and two additional
  checks for per-proposal reply snapshots and older-session reply recovery.
- The existing full customer-flow test now verifies that the reply appears in
  history, is absent from the bouquet overview, and opens history for a reply.
  Existing privacy checks also reject private reply-like fields on audit events.
- Browser: an agent-created demonstration enquiry went through Request changes
  → Staff reply → proposal ready. The same selling price was preserved; the
  customer saw the reply below the proposal event and its own earlier change
  request beneath it. The request was left Awaiting confirmation.
- Back to Home and Choose another bouquet both work. Reopening the saved enquiry
  from Home → Your enquiries restores the same reference, reply and status; the
  selected reference photo remains available when choosing another bouquet.
- At desktop width 1280px, the toolbar precedes the heading. At 411px, navigation
  buttons share a row with a 12px gap and no horizontal overflow. Narrower layout
  wraps the controls. Final CSS spacing was verified visually after regression
  testing; the temporary viewport override was reset.
- No new models, external messages, paid API calls or server restart.

Test log: `output/customer-navigation-replies-regression.log`.

Screenshots in `output/customer-navigation-replies-ux/`:

- `customer-navigation.jpg`
- `reply-in-history.jpg`
- `mobile-navigation.jpg`
