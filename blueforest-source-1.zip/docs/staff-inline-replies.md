# Staff enquiries: direct replies

Checkpoint before this change: `fcae1ec`.

The Staff interface retains Customer enquiries and Flower Materials only. The
Shop Bouquets UI module and entry point are removed; existing bouquet catalog,
BOMs, product prices and genuine CLIP/FAISS retrieval are retained. An old session
on Shop Bouquets/Pricing & Quotations returns to its enquiry details/list.

The enquiry detail keeps the reference image and customer brief, removes the
duplicate Flower/Quantity/Unit table, and presents a reply field. Edit flowers &
quantities expands the existing compact 40px image controls with Add, Remove,
Replace and quantity editing. Final quoted price is editable. Submit reply stays
at the heading's top right; Back to enquiries stays at the top left. No separate
Flower review/Pricing/Quotation steps are required in this interface. The original
technical/presentation applications retain their independent review/pricing tools.

| Status | Meaning |
| --- | --- |
| Pending | Waiting for Staff's reply, including a customer's requested changes |
| Awaiting confirmation | Staff submitted a proposal; waiting for the customer |
| Completed | Customer confirmed that exact proposal version |
| Cancelled | Customer or Staff explicitly confirmed cancellation |

Staff can cancel Pending or Awaiting confirmation enquiries using Cancel enquiry
at the heading's top right, followed by Confirm cancellation. Keep enquiry leaves
the status and private reply draft intact. Completed/cancelled enquiries have no
cancellation action. Both roles see Cancelled; the history identifies Staff as the
actor (Florist in the customer view). Cancellation retains quotation versions and
does not change the catalog, prices or inventory.
An optional Cancellation reason text area (up to 1,000 characters) uses the existing
form style. Its draft is isolated per enquiry and retained when Staff keeps the
enquiry or switches roles. Confirmation captures the trimmed reason in the
cancellation response and audit event, displayed in both roles' Enquiry history.
Customer history reads only the explicit public reason, never arbitrary Staff
audit details. Previous cancellations without reasons remain unchanged.

There is no All or In progress filter. Older In progress enquiries with no
published proposal become Pending; ones with a published proposal become Awaiting
confirmation. This prevents presenting an unpublished draft as confirmable. Photos,
original requests, old quotation snapshots, histories and legacy workspaces are
preserved. New drafts remain private and are isolated per enquiry and reply round.

The shared selling-price formula remains SUM(unit selling price × whole quantity).
Captured names/units/prices are retained for the requested flowers; new choices
come from the existing catalog. Staff's optional override is stored in that
proposal's `final_reviewed_price_hkd`, alongside `total_selling_price_hkd` and a
`price_override` flag. When they differ, Quotation versions labels both calculated
material price and final quoted price. All additional charges remain HK$0. Catalog
prices, BOMs and original quotations are never changed by a reply.

Publication appends immutable quotation JSON to the existing `quotation_snapshots`
table. No schema change or catalog import is required. Staff's unsubmitted draft
does not alter the public proposal or append snapshots. Repeated callbacks are
idempotent; stale drafts and stale customer confirmations are rejected. Failed
database writes leave the previous proposal intact. Customer change requests
archive the old proposal, preserve any superseded private draft, and start a clean
reply round based on the last published flowers and amount. Closed enquiries
cannot be republished or reopened by old draft/approval data.

Validation: the full 213-test suite passed, including updated Customer/Staff flows,
four-state filters, amount overrides, role/enquiry draft isolation, immutable
snapshots, repeated submission, stale confirmation, cancellation, material
management, DIY pricing and genuine offline CLIP/FAISS ranking. The browser preview
uses a copied database under `output/simplified-staff-replies/`; production records
are not populated with test enquiries. Screenshots, test log, original database
backup and data/image preservation checks are in that folder.

As before, the mock enquiry queue/drafts live in the browser's Streamlit session;
persisted quotation snapshots and the material database survive restarts. No real
order, payment, stock deduction or external message is created by Submit reply.
