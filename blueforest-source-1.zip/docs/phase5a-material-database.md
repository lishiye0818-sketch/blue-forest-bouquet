# Phase 5A — Flower Material Database Management

**Current behavior:** Phase 5C supersedes this phase's customer cost-plus pricing
and reference-selling-price controls. See [Phase 5C](phase5c-selling-prices.md)
for canonical unit selling prices, live DIY totals, shop BOMs and quote versions.

Implemented in the existing Python/Streamlit customer application. The Git
checkpoint before implementation is **24927c0**. It includes the preceding
uncommitted enquiry changes and the supplied staging files.

## Run and use

```bash
.venv/bin/python -m streamlit run product_search/app/customer_app.py
```

Choose **Staff** in the existing profile menu, then **Flower Materials** on the
enquiry list. Back to enquiries returns to the existing Staff workflow.

- **Material overview:** image cards for all materials, name search in English
  or Chinese, category filter and Active/Inactive filter.
- **Edit material:** select an ID, edit both names, category, colour, pricing
  unit, mock cost and optional reference selling price. Upload a JPEG/PNG to
  replace the image and click **Save material**.
- **Add material:** enter a new permanent ID (for example FM21), names, category,
  pricing unit and mock cost, then click **Add material**. A photo is optional.
- **Remove:** clear **Active · available for customer selection** and save.
  The row and its ID remain available to existing enquiry snapshots. Re-enable
  Active to restore it. There is no permanent-delete action.
- **FM09–FM20 photos:** open each material in Edit material, upload its individual
  reference photo and save. The placeholder is replaced automatically. No CSV
  editing, indexing, model training or app restart is required.

Names must be distinct (case insensitive); IDs are permanent and duplicates are
rejected, including case variants. Costs must be finite, nonnegative HKD amounts.
Staff forms report invalid inputs without replacing existing data. A stale form
cannot overwrite another Staff session's save; **Reload material** reloads the
latest record. This remains the existing local demo role selector, not secure
authentication.

## Storage and schema

The repository previously used JSON catalogs and session-only enquiry state;
there was no persistent database. The new local SQLite file is:

**`data/flower_materials.sqlite3`**

It is created automatically. `BLUEFOREST_MATERIAL_DB` can select a different
SQLite file, primarily for isolated tests. Back up this file and
`data/images/material_uploads/` together. These runtime files are ignored by Git;
the seed catalog and eight original images are versioned.

Table: **flower_materials**

| Column | SQLite type / purpose |
| --- | --- |
| material_id | TEXT PRIMARY KEY; original FM01–FM20 preserved |
| name_en, name_zh | TEXT; material names |
| category | TEXT; Main Flower / Filler / Greenery |
| color | TEXT; editable colour description |
| pricing_unit | TEXT; stem / portion / bunch |
| unit_cost_hkd | TEXT; decimal HKD cents, internal simulated cost |
| selling_price_hkd | nullable TEXT; optional reference selling price |
| image_path | TEXT; project-relative local image path or empty |
| is_active | INTEGER; 1 active, 0 inactive |
| stock_quantity, low_stock_threshold | nullable REAL; reserved, no inventory workflow |
| updated_at | TEXT; UTC ISO timestamp, also used for stale-edit protection |
| counting_unit | TEXT; existing review compatibility, separate from pricing unit |
| reference_note | TEXT; supplied identity/rights/asset status |

`material_schema` records schema version 1. Initialization uses additive column
migrations inside a SQLite transaction. It never drops/replaces the table or
updates an existing seeded ID. Every save is transactional. Connections are
closed after each operation. Older image files are retained for enquiry snapshots.

## Initial import and assets

`import_staging/BlueForest_Material_Catalog_20_Expanded.csv` is the initial source.
The supplied file has literal newline markers alongside its physical line
breaks; these were normalized in the versioned runtime seed
`data/flower_materials_seed.csv`. Names, original IDs, units, initial supplied
costs and original provenance columns are preserved in that seed.

On initialization, the importer inserts missing IDs with
`ON CONFLICT(material_id) DO NOTHING`. Repeated starts import no duplicates and
preserve Staff changes, inactive status and replacement images.

- CSV `flower` becomes Main Flower and `filler` becomes Filler. FM18 Eucalyptus
  is Greenery; its supplied stem pricing unit is retained.
- Initial colour descriptions follow the supplied material names. They are
  editable labels, not inferred photo observations.
- FM01–FM08 retain the supplied mock costs: 16, 18, 25, 45, 22, 12, 24, 13 HKD.
- FM09–FM20 have blank CSV costs. Explicit synthetic demo defaults, by ID, are:
  **18, 20, 15, 28, 22, 38, 20, 18, 12, 8, 24, 16 HKD**. Staff can change them.
  They are not supplier prices or estimates derived from photographs.
- All initial materials are Active. Selling prices and inventory fields start
  empty. No availability is inferred from stock quantities.

The staging asset pack was delivered as
`import_staging/BlueForest_Final_Codex_Assets.zip`. Only its eight individual
material images were copied to **`data/images/flower_materials/FM01.png`** through
**`FM08.png`**. Each original file's SHA-256 matches the CSV. No image was
generated, downloaded or substituted. FM09–FM20 start with empty image paths.
The original staging archive is preserved; bouquet references and search assets
were not replaced. As stated in the supplied metadata, the material images'
photographer and public-use rights are unverified; this provenance is retained
in the seed, database notes and About & credits.

Uploads reuse the existing validated image reader: JPEG/PNG, at most 15 MB and
20 megapixels; orientation is corrected, metadata removed, and a clean JPEG is
saved under `data/images/material_uploads/`. A unique filename prevents stale
images and preserves earlier snapshots. Paths are restricted to `data/images`.

## Customer and pricing integration

Create Your Own Bouquet now uses active database material image cards, with
Add to bouquet, quantity inputs and Remove actions. Customers can add any active
catalog material, including flowers outside the starter composition. Search and
category filters help browse the catalog. Missing/unreadable photos use a sage
placeholder; staff costs, reference selling prices and inventory fields are
excluded from customer card markup. The estimate page also uses image cards.
Changing roles or visiting another customer page preserves the editable selection.
If Staff disables a material in an open composition draft, the next render removes
it with a review notice. No new inactive selection can be saved.

`pricing_materials()` adapts database names, IDs, pricing/counting units and costs
to the existing review schema (`id`, `name`, `mock_unit_cost_hkd`, etc.). Costs
remain decimal strings for the established Decimal arithmetic. There is no second
pricing calculator. Optional material selling price is reference metadata only;
it is not added to or substituted for the bouquet cost-plus calculation.

The existing `build_mock_quote`, `calculate_pricing`, quotation template and
named Staff approval gates remain authoritative and unchanged. Fractional
portions/bunches are supported; stems still require whole quantities. Zero
quantities are excluded from the customer quotation. Visible head counts never
become requested quantities.

The older prepared demo photos use a different legacy catalog. The original
photos, demo recognition fixtures and technical/presentation workspaces remain
unchanged. In the customer application only, they now introduce explicit
**predefined catalog starter palettes**, not claimed identifications of the photo:

| Starter palette | Independent demo request quantities | Initial estimate |
| --- | --- | ---: |
| Peach Harmony | FM02 × 5, FM04 × 1, FM10 × 3, FM11 × 5, FM17 × 1 portion, FM18 × 2 | HK$619.20 |
| Sunshine Garden | FM01 × 3, FM06 × 4, FM08 × 3, FM13 × 2, FM18 × 2 | HK$449.25 |

All other quantities above are in stems. These are synthetic starting plans,
separate from visible flower counts. The customer application's starter
observations leave every visible count blank. Unmatched uploads start with an
empty manual selection. These changed catalog plans explain the changed customer
demo totals; the pricing formula has not changed. The technical/presentation
demo still reproduces its original totals.

Saving an estimate captures the catalog definitions used for that design.
Submitted enquiries retain that snapshot with their existing plan, photo,
provenance and approval workspace. Later name, unit, cost, image or Active edits
do not silently rewrite a request/quotation already under review. Changes apply
when a new estimate is saved. Legacy session enquiries without a snapshot still
use their original JSON catalog. Enquiry persistence itself remains session-only.

Solution A's CLIP model, FAISS indexes, product catalog, similarity functions,
ranking and cached model setup are unchanged.

## Files

New:

- `product_search/material_store.py`: SQLite storage, insert-only import,
  validation, migration, uploads and review/pricing adapter.
- `product_search/app/flower_materials.py`: Staff forms, overview and customer cards.
- `data/flower_materials_seed.csv` and `data/images/flower_materials/FM01.png`–`FM08.png`.
- `tests/test_material_store.py`: focused storage and UI integration checks.
- `docs/phase5a-material-database.md`: this guide.

Modified:

- `product_search/app/customer_app.py`: Staff entry, database loading, customer
  integration, independent starter palettes, snapshots and attribution.
- `product_search/app/customer.css`: cards and placeholders using existing
  ivory, botanical green, sage, typography and spacing.
- `product_search/app/custom_bouquet.py`: optional thumbnail size; existing callers
  retain their original 200 × 200 behaviour.
- `tests/test_customer_experience.py`: native quantity controls, isolated database
  and expected totals for the new catalog palettes. Approval and workflow checks
  are retained.
- `.gitignore`, `README.md`, `PRODUCT.md`: runtime storage exclusions and feature notes.

## Verification — 26 October 2026

Baseline before implementation: **149 tests passed**.

After implementation: **161 tests passed**, including 12 focused material
database/interface tests. The actual offline CLIP/FAISS presentation check
passed for both prepared uploads and retained the original rankings and legacy
prices (HK$881.55 and HK$533.40). The original pricing smoke check also passed:
HK$246.60 suggested, HK$240.00 reviewed, and zero HTTP requests.

Commands:

```bash
.venv/bin/python -m unittest discover -s tests
.venv/bin/python -m evaluation.presentation_demo
.venv/bin/python -m evaluation.custom_bouquet_pricing
```

The focused tests cover all 20 IDs, no duplicate imports, all eight original
image hashes and readable images, twelve placeholders, Staff search/edit/add,
image upload/replacement, validation, stale edits, additive migration, fresh
Python-process persistence, inactive filtering, customer add/remove/quantity
controls, a material disabled in an open draft, unchanged pricing calculations
and a submitted enquiry surviving later name/unit/cost/status edits.
An unavailable material database is also checked to leave the independent
existing-bouquet journey usable.

The existing customer tests exercise both complete enquiry-to-approved-quotation
flows, role changes, independent enquiries, saved drafts, stale approval
invalidation, confirmation, change requests and cancellation. Tests block network
calls. The offline presentation check runs actual locally cached CLIP/FAISS
retrieval, and the pricing smoke check exercises the original quotation math.

## Scope and limits

This is a local university demo, not a deployed multi-user inventory system.
The existing role selector is not authentication. Enquiries still live in their
browser session; only material records and uploaded images are persistent.
Catalog reads are refreshed on Streamlit reruns, not pushed live to other
browsers. Earlier uploaded images are retained and have no cleanup interface.
The legacy technical and presentation demo catalogs stay isolated for regression
compatibility; Flower Materials manages the customer-facing FM catalog.

There is no inventory deduction/reservation, purchasing, restocking, real order,
payment, image generation, model training, or new paid API integration.
