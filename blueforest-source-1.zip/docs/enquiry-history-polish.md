# Enquiry overview and history polish

Checkpoint before editing: `5311e68`.

| Before | After |
| --- | --- |
| Download enquiry summary action | Removed from both customer enquiry paths. Original approved quotation downloads remain available in the staff quotation workflow. |
| Tools / Presentation links and a divider in the role menu | Only the Customer / Staff selector remains. Original applications are retained at their explicit Staff URLs, documented in README. |
| Activity with large gaps between action, timestamp and amount | Enquiry history uses shared semantic list rows, a 4px action-to-time gap, 12px row padding, thin dividers and newest-first ordering. A published selling price appears beside its related action. |
| One customer heading for every status | Received, in progress, ready-for-confirmation and completed headings follow the existing workflow status. |
| Customer details scattered down the page | Photo beside bouquet name, price and status; small reference number; fulfilment and a readable date together. Preferences, florist messages and collection/delivery notes have explicit labels. |
| Repeated confirmation text and prominent mock-price labels | The completed heading/status communicates confirmation; custom prices distinguish preliminary estimate from confirmed price. Existing footer explanation and underlying provenance remain. |
| Expanded customer flower table and no customer event list | Flower composition and Enquiry history are initially collapsed. Public history uses the same visual layout and only shows public progress, published selling prices and customer change messages. |
| Large mobile column gap and an image aligned to the left | At 411px the image is centred, the summary stacks with a 16px gap, and text/history remain within the viewport. |

The only new data transformation is a customer-facing history projection. It
explicitly filters event types, discards unknown internal audit events, suppresses
staff free-text details and validates a published price before showing it. History
actions, actors, dates and customer text are escaped before HTML rendering. It
does not change stored history, enquiry states or pricing/approval logic.

## Verification

- **143 regression tests passed in 75.551 seconds**: all 141 existing tests plus
  two checks for history privacy and permitted public detail. Customer workflow
  expectations now cover state-specific headings, history availability and the
  removed summary/menu controls. No test was removed.
- Targeted customer suite: 18 tests passed in 40.683 seconds. Tests prohibit
  network and paid service calls while exercising both sample photos and paths.
- Browser: existing bouquet Awaiting confirmation and custom In progress/Completed
  screens render with the correct headings and prices. An existing completed
  request can be reopened through Home → Your enquiries → View status.
- Staff history shows all four existing events as distinct compact rows. Customer
  history shows the corresponding public events and customer message. Stored
  completed/pending/in-progress states and submitted photos were preserved.
- Profile menu has only the two role choices. Switching views still works. No
  enquiry-summary download appears on customer screens.
- Mobile at 411px: no horizontal overflow; computed history metadata margin is
  4px, and the overview column gap is 16px. The final mobile-only spacing rule was
  checked visually after the full regression run. Temporary viewport overrides
  were reset.
- No search/recognition/pricing/quotation engine edits, model installations,
  external submissions, paid calls or server restarts.

Logs: `output/enquiry-history-regression.log` and
`output/enquiry-history-customer-tests.log`.

Screenshots in `output/enquiry-history-ux/`:

- `staff-history.jpg`
- `role-menu.jpg`
- `customer-existing-overview.jpg`
- `customer-custom-history.jpg`
- `customer-completed-overview.jpg`
- `customer-completed-history.jpg`
- `customer-mobile-history.jpg`
