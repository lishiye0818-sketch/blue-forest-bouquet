# Header and workflow copy simplification

Checkpoint before this change: `3dbd0b6`.

| Before | After |
| --- | --- |
| Repeated “Demo · Simulated results” and “Demo enquiry · Not sent” captions | Removed from the ordering and enquiry screens. Presentation, simulation, session-only behaviour and role-switch limitations are explained inside the footer About & credits popup. |
| Staff header tabs for Dashboard, Customer Enquiries and Pricing & Quotations | Brand and profile menu only. Staff open an enquiry, continue to its pricing/quotation and return with Back to enquiries. |
| Small sage “florist” subtitle | Both brand lines share the same green, font size and weight on desktop and mobile. |

Customer Home / Find Similar / Custom Bouquet navigation and Staff status filters
remain available. Original technical tools stay in the Staff profile menu.
Recognition provenance, mock exports, image attribution and approval safeguards
are unchanged. Search, recognition, pricing and quotation engines were not edited.

## Verification

- All **141 regression tests passed in 78.358 seconds**. The existing customer
  tests now use the visible enquiry/back controls rather than the removed header
  tabs and verify that repeated captions are absent while provenance remains.
- Browser: Staff enquiry list → completed enquiry → Review quotation → Back to
  enquiries works without changing the enquiry's status.
- Customer role retains all three navigation choices. Its enquiry page no longer
  contains either removed caption.
- Desktop computed brand styles: both lines `rgb(32, 62, 50)`, `39.68px`, weight
  `600` at 1280px. Mobile at 411px: both `24px`, the same green and weight. No
  horizontal overflow was observed.
- Footer About & credits opens with presentation explanation, original source
  links, licenses and the complete photography credits download.
- Existing local session queues were preserved; no server restart, external
  submissions, model installations or paid API calls were needed.

Test log: `output/header-simplification-regression.log`.

Screenshots:

- `output/header-simplification-ux/staff-before.jpg`
- `output/header-simplification-ux/staff-after.jpg`
- `output/header-simplification-ux/customer-mobile-after.jpg`
