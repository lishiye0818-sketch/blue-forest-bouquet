# Phase 5E — Registered customer samples and direct DIY editing

Checkpoint before changes: **56832cb**. The database, twenty material photos,
four shop photos/BOMs/prices and existing quotation snapshots are unchanged.

## Why the prepared uploads did not match

The actual A00/B00 files were still inside
`import_staging/BlueForest_Final_Codex_Assets.zip`. Customer Demo Mode instead
loaded the older Peach Harmony/Sunshine Garden fixtures from
`data/presentation_demo.json`. Matching only compared original file SHA-256
values, so neither new reference upload could match; resizing/re-encoding an
otherwise registered photo also changed its byte hash.

The two customer originals were copied byte-for-byte from the archive's
`BlueForest_Final_Codex_Assets/01_reference_bouquets/` directory to:

| Reference | Registered runtime file | Original upload name |
| --- | --- | --- |
| A00 · Blue & White Elegance | `data/images/customer_references/A00_reference_blue_white.jpg` | `IMG_2481.JPG` |
| B00 · Bright Garden Mix | `data/images/customer_references/B00_reference_bright_garden.jpg` | `IMG_2483.JPG` |

`data/customer_bouquet_demo.json` registers the original hashes and illustrative
compositions. The existing Demo Mode fixture loader validates hashes, permanent
material IDs and explicit no-inference provenance. The older technical fixtures
remain available only in their separate original workspace.

## Matching and starting selections

`product_search/customer_demo.py` first uses the existing exact SHA-256 matcher.
It then checks oriented/decoded RGB pixels. A conservative fallback compares
96×96 full-frame RGB images: aspect ratios must differ by at most 1%, mean
absolute pixel difference by at most 0.012 and RMS difference by at most 0.025
(normalized 0–1). Exactly one registered photo must satisfy the fallback.
Filename is never an input. Matching uses Pillow/NumPy, with no API, training,
CLIP call or other vision model.

- A00: **FM02 × 5, FM04 × 1**.
- B00: **FM01 × 4, FM15 × 3, FM06 × 1, FM03 × 2, FM07 × 2**.

Visible counts remain null. These are user-specified illustrative starting
quantities, not florist-verified identities, counts or recipes. Unit prices come
from the existing SQLite catalog and the shared selling-price function. With
the preserved demo prices, the initial totals currently compute to HK$135 and
HK$234; these amounts are not stored as product prices or hardcoded in the UI.

The fallback supports ordinary resizing/re-encoding of the same photograph.
Crops, new angles, edited backgrounds, heavily degraded pictures and different
bouquets with similar colours intentionally fall back to manual selection.

## Customer workflow

**Reference Photo → Flower Composition → Estimated Price → Preferences → Enquiry Status**

Flower Composition opens directly into the compact material editor. The separate
Flower Inspiration/Edit my bouquet tabs and the misleading “no prepared recognition
result” panel have been removed. Recognized samples show the requested short
personalisation message and a subtle predefined-demo disclosure. Other photos
start with an empty selection and “Create your bouquet by choosing your favourite
flowers below.” All active material cards, add/remove/replace, quantities, current
unit prices and live totals remain available. Navigation actions stay at the top
right as requested in the preceding refinement.

**Start without a photo** opens the same empty editor. Such new enquiries retain
`photo=None`; customer/Staff previews use an explicit text placeholder, and Staff
approval retains the normal saved-review and explicit-approval gates. Existing
photo-based enquiry records are not rewritten.

Suggestions are initialized once per reference context. Ordinary reruns, role/page
navigation and revisiting the same reference preserve edits. Choosing a different
photo clears the earlier selection and shows a reset notice before editing its
new suggestion. Submitted enquiry snapshots remain independent.

## Verification

**197 regression tests passed**, including ten new tests covering the exact
originals, lossless PNG conversion, resized/recompressed copies, negative matches
against all four shop photos/all twenty material photos/legacy references, edited
selection persistence, changed-photo reset, current Staff-edited unit prices,
actual upload callbacks and full photo/no-photo enquiry approval workflows.
AppTest has no native upload driver; these tests exercise the application's real
upload callback using supplied file bytes. Streamlit runtime smoke screenshots
and a data-preservation report are in `output/phase5e/`.

The active Solution A index remains the same four-product CLIP/FAISS index.
Reference photos remain outside the shop table and searchable index. No inventory,
paid API, image generation, price formula or database schema changes were added.
