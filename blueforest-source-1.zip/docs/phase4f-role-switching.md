# Phase 4F — Customer and Staff demo views

Checkpoint before changes: **`6f58768`**, preserving the approved Phase 4E interface.
The existing Streamlit entrypoint and port are unchanged:

```bash
.venv/bin/python -m streamlit run product_search/app/customer_app.py --server.port 8504
```

## What changed

| Before | After |
| --- | --- |
| Staff Review appeared in customer navigation | Default Customer navigation contains Home, Find Similar and Custom Bouquet only. A compact top-right profile menu switches to Staff, with Dashboard, Customer Enquiries and Pricing & Quotations. |
| The right header area displayed a brand phrase | The existing Blue Forest mark and wordmark remain at left; a person icon, current role and dropdown arrow occupy the right. The menu explains each role and explicitly identifies the demo security limitation. |
| Narrow header columns could push the profile control onto another row | At narrower widths, brand and profile share the first row and navigation fills the second. Minimum column widths are overridden locally; labels can wrap. Role-menu captions remain visible. |
| A custom enquiry required a finalized quotation first | Customers submit a pending request with requested quantities, preferences and an indicative price (or an unresolved price). Staff review follows submission. Only a saved review and approved final quotation can supply the reviewed selling price. |
| No connection between submitted enquiries and the separate staff demonstration | A minimal session queue presents submitted requests in the Staff Dashboard and enquiry selector. Existing-bouquet requests retain their selected catalogue product/price and a separate review acknowledgement. |
| Closed profile controls could restore an old role after a button-driven return | Active role is stored independently from the selection widget. The stable popover and refreshed picker prevent stale client values from switching the next customer page back to Staff. |
| One transient set of staff review/pricing widgets | Each enquiry owns a copy of its submitted photo, original request, customer design and allowlisted review/pricing workspace. Switching roles or enquiries saves and restores editor drafts, reviewed quantities, pricing inputs, draft text and approval state. |
| Changing a customer photo or design cleared unrelated staff state | Changing the active customer reference resets that draft's selections. Previously submitted requests, photos and independent quotation records remain available. Viewing an older staff request never replaces the customer's current photo. |
| Customer completion assumed an approved custom quote | The same request reference now displays Awaiting florist review, Florist review in progress, Quotation approved, or the existing-bouquet reviewed status. Home provides a Your enquiries status list. |
| Internal quotation data could only be used by entering Staff Review first | The queue synchronizes an explicit public projection after approval. Customer pages and summary downloads contain selling prices and reviewed flower quantities, excluding internal costs, raw quotation text and staff notes. Editing an approved price withdraws the old public quotation while retaining the submitted request and its preliminary estimate. |
| Original technical links were mixed with the former Staff Review route | Original technical tools & Live AI remain in the Staff workspace, with explicit Staff demo links. They open separate sessions and do not modify the request queue. Customer navigation and customer-only workspace URLs do not render them. |
| UI tests asserted the superseded shared navigation and approval-before-request flow | Customer interaction tests now exercise the Phase 4F contract. Added session-boundary tests cover real editor deltas, immutable snapshots, public projections, credentials/button exclusion and original pricing-input compatibility. README and product guidance document the new sequence. |

The supplied floral hero and Shop Flowers section remain intact. Both ordering
options retain equal prominence and work independently. Existing text-only
workflow progress, photo layout, botanical palette, buttons, image credits,
keyboard focus and reduced-motion styles remain in use. No numbered circles were
introduced. Custom progress now reflects the request-before-review workflow:
Reference Photo / Flower Composition / Estimated Price / Preferences / Enquiry
Status.

## Workflow and safeguards

**Existing bouquet:** Customer → Find Similar → original sample or upload → real
CLIP/FAISS Top 3 → Select Bouquet → preferences → local mock enquiry. Staff can
view the original reference, selected product, catalogue price and preferences,
then mark it reviewed. The custom flower-costing path is not invoked.

**Custom bouquet:** Customer → Custom Bouquet → original sample or upload →
composition and editable requested quantities → preliminary price → preferences
→ pending local enquiry. Staff opens the queued request, saves the existing
florist review, checks original Phase 3B pricing, generates a deterministic draft,
provides a reviewer name and explicitly approves before finalizing. Switching
back to Customer shows the same reference and the reviewed public price.

The new `pending_custom_enquiry` represents a request for review, not an approved
quotation. The existing final `mock_enquiry` projection still rejects an
unapproved custom quotation. `render_florist_review`, `render_pricing_workflow`,
material validation, Decimal pricing and quotation generation/invalidation remain
the original implementations. Unsaved material edits are retained as editor
drafts and cannot carry a previous approval forward.

Only an allowlist of widget inputs and review/pricing state enters each saved
workspace. Credentials, download/button states and the customer's current photo
are excluded. Public records are separate copies and explicitly whitelist
customer fields. Recognition provenance and Mock Data labels remain in Staff and
quotation exports. The role picker explicitly says it is not authentication or a
secure login; hiding internal screens is a demo UX separation, not a security
boundary.

## Verification

**130 tests passed in 62.138 seconds.** The 109 tests outside the customer UI
suite remain unchanged. The customer suite was updated from 12 to 13 tests to
reflect the explicitly changed navigation and request-before-approval contract;
8 additional session-boundary tests were added. No test files were removed.

```bash
.venv/bin/python -m unittest discover -s tests -v
```

Regression output: `output/phase4f-regression.log`. Focused outputs:
`output/phase4f-customer-tests.log` and `output/phase4f-session-tests.log`.

The tests cover both original samples independently through both options, real
ordered Top 3 retrieval, edited quantities, public field projection, form
validation, both role navigations, empty queues, approval gates, saved staff
quantities/draft inputs across role switches, multiple requests with separate
photos/prices, withdrawal of stale quotations, and preservation of original
Demo/Live technical tools. Customer integration tests block outbound requests
even with an API key configured. No paid API call or new model installation was
made.

Default preliminary sample prices remain **Peach Harmony HK$881.55** and
**Sunshine Garden HK$533.40**. Tests also verify a customer-requested quantity
change produces HK$911.25 and an employee-reviewed Rose quantity of 7 produces
HK$940.95 through the original engine.

Actual browser verification at `http://localhost:8504/`:

- Default Customer header, all three customer pages, profile dropdown and its
  role descriptions; Staff has its separate three-page navigation.
- Shop Flowers still reaches the two parallel choices; no numbered stage circles.
- Peach Harmony custom request **BF-B-7D38A245** submitted before review at
  HK$881.55, then visible in Staff Dashboard with its photo and preferences.
- Actual editable table interaction changed Rose quantity from 5 to 7. Switching
  Customer → Staff before saving retained the unsaved value of 7, with approval
  still unavailable. Saving the review produced HK$940.95.
- Original draft, named reviewer and explicit approval produced a finalized mock
  quotation. Switching through the profile menu back to Customer retained the
  request reference and showed Quotation approved, HK$940.95 and Rose 7 stems.
- The employee return button was also verified with the profile popover closed.
  Subsequent Custom Bouquet and Home navigation remained in Customer View, with
  the same approved request available.
- Both the rendered customer page and the actual downloaded enquiry JSON were
  checked for internal cost fields: none were present. The JSON status was
  `quotation_approved_mock`; raw internal quotation text was excluded.
- The same reference photo was reused directly in Find Similar. Real retrieval
  returned Peach & Calla Harmony, Hydrangea Blush and Sunset Mixed Bouquet.
  Selecting the second result created **BF-A-D83E00C7** for HK$680.00, independent
  of custom review. Staff displayed the selected product, marked it reviewed
  without custom costing, and retained the approved custom request alongside it.
- At desktop 1280 × 720 and 411 px width, the page had no horizontal overflow.
  The mobile profile control stays at upper right, its dropdown fits the viewport
  and Staff navigation wraps legibly. Empty Staff states remain usable.

## Screenshots

Screenshots are local in `output/phase4f-ux/`:

| File | View |
| --- | --- |
| `role-menu.png` | Desktop floral homepage and expanded role selector |
| `customer-reference.png` | Approved reference-photo layout and customer-only navigation |
| `customer-pending.png` | Submitted custom enquiry awaiting review |
| `staff-dashboard.png` | Existing and custom enquiries together, with independent statuses |
| `staff-pricing.png` | Original internal pricing after the saved quantity edit |
| `staff-quotation.png` | Original quotation approval workspace |
| `customer-approved.png` | Same custom enquiry with approved public price |
| `customer-similar-results.png` | Real ranked catalogue results |
| `customer-existing-enquiry.png` | Independent existing-bouquet receipt |
| `customer-home-mobile.png` | Responsive brand/profile header and hero |
| `role-menu-mobile.png` | Mobile role dropdown |
| `staff-mobile.png` | Mobile Staff navigation and empty state |

The downloaded public example is
`output/phase4f-ux/customer-approved-enquiry.json`, using fabricated contact data.

## Prototype limits and unchanged scope

- Role switching is not login, authorization or production RBAC. All roles in one
  browser session can inspect that session's demo queue. There is no user identity
  or production privacy isolation.
- Enquiries, review history and quotations exist only in the current Streamlit
  session. A fresh session/server restart does not restore them. Different
  browser sessions do not share a queue. Durable storage, authenticated staff
  access and cross-user enquiry sharing require a production business system.
- Existing technical/Live AI pages open in a separate Staff demo session; their
  analyses do not feed the customer queue. Live inference remains available but
  was not called during verification.
- Catalogue prices, estimates, approvals and quotations are mock. There is no
  stock/availability verification, payment, real order creation, reservation,
  external submission or customer notification.
- CLIP/FAISS ranking, recognition fixtures, materials, search catalogue, pricing
  algorithms, review validation and final-approval safeguards were not rewritten.
  No dependency or AI model was installed.
