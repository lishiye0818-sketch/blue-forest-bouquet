# Phase 2: Blue Forest bouquet catalog

The Streamlit app now defaults to **Blue Forest bouquets — mock**. Use the
**Product catalog** selector to return to **Original ZARA jackets**. The original
CSV, default configuration used by evaluation scripts, retrieval algorithms and
embedding models are preserved. No LLM or sales-generation features were added.

## Catalog schemas

The original loader accepts `product_name,link,product_images,details`.
It now also accepts the bouquet schema below and maps it to the same internal
product fields for the existing search pipeline.

| Bouquet column | Format and use |
| --- | --- |
| `product_name` | Nonempty product name |
| `image` | HTTP(S) image URL, or CSV-relative path under `data/images` (e.g. `images/bouquet-01.jpg`); empty is allowed |
| `description` | Product description; used in keyword and semantic search |
| `price_hkd` | Finite nonnegative number, e.g. `580.00`; no currency symbol |
| `colour` | Nonempty colour text; separate multiple values with semicolons |
| `style` | Nonempty style text (older CSVs without the column show `Unspecified`) |
| `occasion` | Nonempty occasion text; separate multiple values with semicolons |
| `product_url` | Unique HTTP(S) product URL; used as product identity |
| `is_mock` | `true` for examples, `false` for verified rows; optional, defaults to `false` |
| `image_creator` | Photographer credit |
| `image_license` | Image license name |
| `image_license_url` | License URL |
| `image_source_url` | Original image description/source page |

Colours, styles and occasions are included in bouquet search text. Price is displayed
as HKD; numerical price filtering is not implemented. The image and text indexes
remain separate, and the catalog contents and model determine each index's key.
Changing catalogs clears old results so product IDs cannot cross catalogs.

## Mock data and current limits

[`data/bouquets_mock.csv`](../data/bouquets_mock.csv) has 12 fabricated bouquets and floral arrangements.
Every row has a `Mock —` name prefix, an explicit mock description, `is_mock=true`,
and a reserved `example.invalid` URL. Prices, colours and occasions are examples.
They are not verified Blue Forest merchandise, quotations or availability.
The app labels mock rows and hides their listing links.

Each row points to its corresponding local photograph, curated from Wikimedia
Commons under CC0, CC BY or CC BY-SA. These photos are illustrative, not Blue
Forest product photos. Names, HKD prices and occasions are fictional. Colours,
styles and descriptions describe the inspected photo for this mock catalog.
See [image credits](../data/IMAGE_CREDITS.md) and the per-file source/license/hash
manifest in `data/image-sources.json`. Retain the credits and applicable image
licenses when redistributing. All catalog photos together occupy about 2.5 MB.

**Use a photo** accepts JPG/PNG uploads and returns at most three bouquets with
their images, HKD prices, colour, style and occasion. The original ZARA mode
still returns five results. The **Try a sample bouquet photo** button runs the
same search with `data/images/references/independent-rose-bouquet.jpg`, a separately
photographed reference excluded from the catalog. Its license is also recorded.

Keyword search works immediately without credentials; try `graduation`,
`pink hydrangea`, `dried`, or `anniversary`. Semantic search still uses the
existing OpenRouter embedding API and needs `OPENROUTER_API_KEY`. There is no
new text generation or LLM integration.

Local image reads are confined to `data/images` (including references); paths
outside it, `file://` URIs and symlinks escaping it are rejected. HTTP(S) loading
and caching remain supported. CSV-relative local paths are resolved from the
CSV directory. Missing photos are skipped by image indexing and do not remove
products from keyword search. The photo controls are disabled only if no usable
image sources remain. CSV contents and local photo bytes determine the catalog
fingerprint: replacing a photo rebuilds the index even when the CSV is unchanged.

## Verification

Run automated regressions with `.venv/bin/python -m unittest discover -s tests -v`.
Run the live model and Streamlit check with:

```bash
HF_HOME="$PWD/output/huggingface" .venv/bin/python -m evaluation.bouquet_smoke
```

The live check validates all asset hashes and attribution records, excludes the
reference by both file hash and decoded pixels, indexes 12/12 photos with their
original product IDs, reloads the saved FAISS index, runs three searches, and
checks the real Streamlit sample flow renders the reference plus three matches
and their prices. It also checks keyword retrieval. The report is saved in
`evaluation/bouquet-image-smoke.json`. This one independent reference is a
functional test, not a statistically measured relevance benchmark. CLIP may
match flower shape, packaging, composition or background as well as colour.

## Replace examples with real Blue Forest products

1. Obtain an authorized product export or verify rows against official Blue Forest
   listings. Confirm names, descriptions, HKD prices, product links and photo use.
   Use only supported colour and occasion claims; do not infer them from photos.
2. Copy the mock CSV to a new file, such as `data/bouquets_real.csv`, preserving
   the column names. Replace each example row completely. Remove the `Mock —`
   prefix and mock disclaimer, use the actual unique product URL, and set
   `is_mock=false` only after that row is verified. Keep unfinished rows marked
   `true` or omit them. Do not simply relabel the sample catalog as real.
3. Obtain permission or an appropriate license before reusing product photos.
   Store permitted files in `data/images` and use CSV-relative paths in `image`,
   or supply direct HTTPS photo URLs. Record creator, source, license and any
   changes. Confirm remote URLs return an actual image without a login or an
   expired token. Missing photos can stay empty; those
   products remain available for text search and are excluded from image indexing.
4. Save as UTF-8 CSV. Quote values containing commas. Keep a separate record of
   source links and verification dates; this CSV does not track live stock or
   refresh prices automatically.
5. Start the app with the new catalog (from the repository root):

   ```bash
   CATALOG_PATH=data/bouquets_real.csv HF_HOME="$PWD/output/huggingface" .venv/bin/streamlit run product_search/app/streamlit_app.py
   ```

   Alternatively, set `CATALOG_PATH=data/bouquets_real.csv` in `.env` and restart.
   It appears as **Configured catalog** and is selected first. Both built-in
   catalogs remain available in the selector. No source edits are required.
6. Check the displayed catalog and HKD prices, run several keyword searches,
   then upload an independent photo. First use builds a separate CLIP index;
   the app reports how many photos are searchable. Existing ZARA indexes remain
   independent. Updating CSV content creates a new index automatically.

The original ZARA relevance labels and smoke-test reference belong to ZARA;
create bouquet-specific examples before evaluating real bouquet relevance.
