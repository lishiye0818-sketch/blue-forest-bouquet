# Enquiry statuses and customer confirmation

Checkpoint before implementation: **`4379c89`**, preserving the completed
blue forest florist branding and copy cleanup.

## Workflow

| Staff/customer label | Meaning | Next action |
| --- | --- | --- |
| Pending · 待处理 | New customer enquiry; viewing it does not start work | Staff: Start processing |
| In progress · 询价中 | Staff is reviewing the request, quantities or pricing | Existing bouquet: Ready for customer confirmation; custom: original review and quotation approval |
| Awaiting confirmation · 待客户确认 | The reviewed proposal is ready for the customer | Customer: Confirm proposal or Request changes |
| Completed · 处理完成 | Customer confirmed this exact proposal | Read the confirmed details or return to the enquiry list |

Customer confirmation completes the **enquiry**, not a real order, payment,
reservation or delivery. A change request returns the same enquiry reference to
In progress. Custom quotations require fresh approval before the next customer
confirmation. Existing bouquets stay on catalogue pricing and never enter custom
material-cost calculations.

## Before and after

| Before | After |
| --- | --- |
| View as customer and Return to customer enquiry buttons inside Staff pages | Removed. Roles change only through the top-right profile menu. Staff pages offer Back to enquiries. |
| Small state captions and a large green reviewed message | Four prominent colour-and-text status labels, visible in lists and at the top of details; the large reviewed message is removed. |
| Reading a custom request could mark it in review | New requests stay Pending until the explicit Start processing action. Reopening and viewing remain read-only with respect to workflow status. |
| Stacked photo cards and long Staff pages | Compact enquiry rows with name, bouquet, collection/delivery date, price and status. Reference and selected/proposed catalogue images sit side by side in restrained frames; start/review actions are above the detail images. |
| No status filtering or prioritisation | All / Pending / In progress / Awaiting confirmation / Completed filters with counts. Pending work comes first, newest first within each state; the filter selection survives page/role changes. |
| Custom approval was the last visible customer state | Original staff approval publishes a proposal for customer confirmation. Customer sees the reviewed public price, quantities and delivery notes, with Confirm proposal / Request changes as the principal actions. |
| No customer change-response loop | Customers submit a required change description. Staff sees it above the request. The old custom approval is cleared; reapproval and a new customer confirmation are required. Original submitted preferences/photo remain intact. |
| Existing-bouquet changes had no proposal revision control | Staff can select another item from the existing validated catalogue and add a specifically customer-facing proposal message. The catalogue price is reused. Original product selection remains in the submitted snapshot. |
| Customer actions were not tied to an offered version | Proposal versions bind the public product, price, flowers, delivery terms and preferences. Old/stale confirmation actions are rejected. Identical reissued proposals also get a new version after changes are requested. |
| Review/price edits only withdrew final quote data | They also withdraw the public proposal, reopen the workflow and invalidate a previous customer confirmation. No stale reviewed price can remain confirmable. |
| No concise action history | Staff Activity folds away submission, explicit start, proposal approval, customer changes, withdrawal and confirmation events, with Hong Kong dates/times. Previous proposal snapshots stay in the session. |
| Older running-session enquiries used the Phase 4F status fields | Session records are upgraded in place, preserving original photos, review/pricing workspace and approved public proposal. Existing technical raw status fields remain compatible; workflow_status records the four-stage lifecycle. |
| Customer confirmation controls were below the flower table | Principal response actions are above the table. Completed requests retain their confirmed details and a concise confirmation message. Existing customers can choose another bouquet without entering the custom path. |
| Narrow layouts compressed native text blocks | Owned, escaped summary markup and non-shrinking content keep row text and controls readable. Filters wrap, mobile rows stack, images remain contained, and profile navigation retains its approved layout. |
| Previous tests assumed staff review was completion | The existing UI/session tests follow the new explicit start and customer response contract. Added tests cover stale versions, changes/reapproval, unchanged-price reissues, both independent paths, filters/counts, migration and privacy. Product/README guidance is updated. |

The existing hero, branding, shared reference-photo state, recognition fixtures,
real CLIP/FAISS search, technical/Live AI destinations, material editor, Decimal
pricing, approval engine and quotation export formats remain available. The new
workflow resides in the in-session adapter and frontend. No core search,
recognition, pricing or quotation engine file was changed.

## Safeguards

- Opening, browsing and filtering requests do not advance their workflow.
- The original saved florist review, complete quantities, named reviewer and
  explicit approval remain prerequisites for a custom final proposal.
- Customer responses use the version bound to the rendered button/form, not a
  newly read price on the subsequent rerun. A changed or withdrawn proposal
  cannot be accepted through an old page/action.
- Duplicate confirmation does not duplicate completion/history.
- Customer change requests require a nonblank description, up to 1,000
  characters. Staff must approve again even if the price is unchanged.
- Public summaries whitelist customer fields. Raw quotation text, internal
  review notes, unit costs, labour, overhead, markup and profit remain internal.
  The optional existing-bouquet proposal message is explicitly labelled as a
  message for the customer, separate from internal notes.
- Existing session migration preserves records; changing the active customer
  photo or reviewing a different request does not overwrite submitted photos.
- Status badges use explicit text as well as colour. Text contrast ratios are
  5.89:1 Pending, 6.62:1 In progress, 6.08:1 Awaiting confirmation and 7.69:1
  Completed. Native keyboard controls and reduced-motion rules remain.

## Verification

**141 regression tests passed in 73.913 seconds.** The suite includes 109 original
non-customer/non-session tests, 16 customer/projection tests and 16 session/workflow
tests. Added 8 workflow-boundary tests and 3 customer UI scenarios. Existing UI
assertions were updated for the explicitly changed status and navigation contract;
no test files were removed. A subsequent focused customer run also passed before
the final full regression run.

```bash
.venv/bin/python -m unittest discover -s tests -v
```

Logs: `output/enquiry-status-regression.log`,
`output/enquiry-status-customer-tests.log`,
`output/enquiry-status-session-tests.log`.

Automated coverage includes both original photos through both independent paths,
real ordered CLIP/FAISS results, catalogue price preservation, saved material
review and quotation approval gates, public price projections, customer
confirmation and changes, product replacement on the catalogue path, role/state
preservation, multiple-request isolation, unstarted request viewing, filters,
photo/quote mismatch rejection, stale actions and repeated confirmation. Customer
integration tests block outbound requests even when an API key is configured.

Actual browser verification at `http://localhost:8504/`:

- Running-session custom request **BF-B-7D38A245** retained its photo, Rose quantity
  7 and reviewed price HK$940.95, upgraded to Awaiting confirmation.
- Customer submitted a request for collection after 3 pm and soft colours. The
  same reference returned to In progress; Staff saw the feedback and the prior
  approval was cleared.
- Staff saved the existing material review, revised collection notes, regenerated
  the original quotation draft and explicitly approved it. Customer saw the new
  collection notes and confirmed the reissued proposal. The request became
  Completed and retained its selling price and reviewed quantities.
- Two further independent demo requests for Mia Wong and Alex Chan started
  Pending. Only the explicit Start processing action advanced Alex's request.
- The Staff list displayed one request in each of the four states, including
  existing-bouquet request **BF-A-D83E00C7** at its unchanged HK$680 catalogue
  price. The Pending filter showed only Mia's request. All restored the four
  rows with the expected counts and order.
- Existing-bouquet details displayed reference and catalogue photos side by side,
  the state at the top and no customer-switch button or large green message.
- At 411 px width, Sunshine Garden independently produced HK$533.40, submitted a
  new enquiry and appeared in the mobile Staff list as Pending. Opening it kept
  it Pending, with Start processing visible near the top of the detail page.
- Desktop and mobile pages had no horizontal overflow. Header/profile navigation,
  wrapped filters, status labels, readable row spacing and natural-aspect images
  were checked visually.

## Screenshots

Saved under `output/enquiry-status-ux/`:

- `staff-all-states.png` — four visible statuses, counts and compact rows.
- `staff-pending-filter.png` — filtered pending request.
- `staff-existing-detail.png` — compact catalogue enquiry with parallel photos.
- `customer-awaiting.png` — customer response controls and reviewed proposal.
- `customer-completed.png` — confirmed enquiry status.
- `staff-mobile-list.png` and `staff-mobile-detail.png` — 411 px layout.

## Prototype limits

The role picker is a demo view switch, not authentication or authorization.
Requests, proposals, decisions and history remain in the same Streamlit session;
separate browser sessions do not share a queue, and server/session loss is not
persistent storage. Customer responses are local demo actions. No email, message,
real order, inventory availability check, payment or delivery integration was
added. No model installation or paid API call was made.
