# Phase 3B — Mock Data pricing and florist-reviewed quotations

Phase 3B extends the saved florist review and existing material-only cost draft.
Solution A, recognition, Demo/Live mode selection, demo fixtures, catalog costs,
photo assets and dependency files are preserved. The pre-extension checkpoint is
`74bd5c5`. No API key is needed for the complete Demo-to-quotation workflow.

## Run and test

```bash
.venv/bin/python -m streamlit run product_search/app/streamlit_app.py
```

The complete offline checks are:

```bash
.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python -m evaluation.custom_bouquet_demo
.venv/bin/python -m evaluation.custom_bouquet_pricing
```

The pricing evaluator blocks HTTP and tests deterministic calculations, template
editing and the approval requirement. Its florist quantities and approval are
explicit software-test inputs, not real florist approval or AI inference. Reports
are written to `output/phase3b-pricing-smoke.json` and an example text quotation to
`output/phase3b-pricing-smoke.txt`. Outputs are ignored by Git. No live AI request
is needed or made by these checks.

## Complete workflow in the app

1. Open **Custom Bouquet** and keep **Demo Mode (Mock AI, no API calls)**.
2. Choose **Red and yellow roses** in **Demo sample** and click **Load demo
   results**. The preset visible-head count is illustrative, not a stem quantity.
3. In **Florist review**, enter **Florist quantity = 3** for Rose. Check its
   identity and unit, then click **Save florist review**. Missing quantities or
   Unknown materials must be resolved before full pricing is available.
4. Expand **Next phase · Mock costs and quotation draft**. The previous material
   subtotal and internal draft remain available. Continue to **Phase 3B · Pricing
   and customer quotation** underneath.
5. Enter packaging, labour, waste, overhead and markup. Optionally enable the
   delivery fee and customer budget. The inputs use mock HKD values; all monetary
   calculations use Python Decimal arithmetic and round half up to cents.
6. Inspect the cost breakdown, suggested price, estimated gross profit and profit
   margin. Budget comparison never automatically discounts a price. Enter the
   **Final reviewed price** if the florist chooses a different amount; the reviewed
   profit/margin and budget comparison update separately.
7. Enter **Delivery or collection notes** and click **Generate customer quotation
   draft**. No model is called: a fixed template inserts the selected flower
   types, positive reviewed quantities, final reviewed price and delivery notes.
8. Edit the greeting, explanatory wording or closing in **Customer quotation
   draft**. Keep the Mock Data label and the generated flower/price/delivery
   summary intact. To change those details, edit the corresponding structured
   fields and generate a new draft. Unapproved downloads are labelled DRAFT.
9. Enter **Reviewing florist name**, read the entire quotation, then check the
   explicit review confirmation. Only then is **Finalize mock customer quotation**
   enabled. A backend check also enforces approval, reviewer name and current
   reviewed details.
10. Download the finalized mock quotation as text or JSON. It remains labelled
    **Mock Data** and records florist approval. No email, customer submission,
    real supplier quotation, order or other external action occurs.

All work stays in the current browser session until downloaded. Changing a saved
material review resets pricing, draft edits and approval. Unsaved florist changes
hide the pricing workflow and invalidate its approval. Changing costs, delivery
fee, budget, reviewed price or delivery notes requires a new draft and fresh
approval. Editing draft wording or reviewer name clears approval and finalized
exports. Regenerating a draft also requires approval again.

## Calculation rules

Let `M` be the sum of catalog mock unit costs × florist-reviewed quantities. Each
material line is rounded to HKD cents by the existing material calculator.

| Calculation | Rule |
| --- | --- |
| Waste allowance | `M × waste percentage / 100`, rounded to cents |
| Production cost | `M + waste + packaging + labour + overhead` |
| Total estimated cost | `production cost + enabled delivery fee` |
| Markup amount | `production cost × markup percentage / 100`, rounded to cents |
| Suggested selling price | `production cost + markup amount + enabled delivery fee` |
| Estimated gross profit | `suggested selling price − total estimated cost` |
| Suggested profit margin | `estimated gross profit / suggested selling price × 100` |
| Reviewed profit | `final reviewed price − total estimated cost` |
| Reviewed profit margin | `reviewed profit / final reviewed price × 100` |

For this prototype, “estimated gross profit” means the difference after **all
listed mock costs**, including labour and overhead. It is a clearly stated mock
estimate, not an accounting statement. Tax and supplier availability remain
unverified.

**Markup and margin have different denominators.** With production cost HK$100
and no delivery fee, 25% markup gives a HK$125 price and a 20% profit margin.
Delivery is passed through as both a cost and a charge after markup; it does not
add estimated profit, and it affects the margin denominator.

Waste applies only to material cost, not labour/packaging/overhead/delivery. Visible
heads, hydrangea clusters and filler usage never become stem/bunch quantities.
Zero quantity excludes a known flower from the customer quotation. Unknown or
blank quantities block full pricing. Negative, non-numeric, Boolean and non-finite
values are rejected. Waste must be 0–100%; markup 0–1000%; each HKD input is capped
at HK$1 billion. Zero is a valid entered budget. A quotation requires a positive
reviewed price; a zero selling-price margin is undefined, not a division error.
A reviewed price below cost is shown as a loss for the florist to assess.

## Reproducible example

Use 3 Rose stems at the catalog mock unit cost of HK$18.00, packaging HK$20.00,
labour HK$50.00, overhead HK$15.00, waste 10%, markup 50%, delivery HK$30.00 and a
customer budget of HK$250.00:

| Result — Mock Data | HKD |
| --- | ---: |
| Material cost | 54.00 |
| Waste allowance | 5.40 |
| Production cost | 144.40 |
| Total estimated cost including delivery | 174.40 |
| Markup amount | 72.20 |
| Suggested selling price | 246.60 |
| Estimated gross profit | 72.20 |
| Budget remaining at suggested price | 3.40 |

The suggested profit margin is **29.28%**, distinct from the **50% markup**. If the
florist enters a final reviewed price of **HK$240.00**, the estimated reviewed
profit becomes **HK$65.60**, margin **27.33%**, and budget remaining **HK$10.00**.
The customer template uses HK$240.00 and the reviewed quantities, not the suggested
price or visible-head count. Internal unit costs, markup and profit calculations
are not inserted into the customer text.

## Verification — 25 October 2026

**73 tests pass:** the existing 57 plus 16 Phase 3B tests. New checks cover all cost
components, delivery pass-through, markup versus margin, decimal rounding,
fractional bunches, price overrides, budget boundaries (including zero), losses,
missing/Unknown quantities, invalid inputs, deterministic quotation generation,
editable wording, protected required details, named florist approval, stale
pricing/delivery contexts and invalidation after changes. Phase 3B integration
tests block HTTP requests; AppTest's missing data-editor driver is handled only
at the manually entered quantity boundary. Actual pricing, draft editing and
approval widgets execute normally.

A real browser check also entered 3 Rose stems, enabled delivery and budget,
verified the HK$246.60 suggested price and HK$240.00 reviewed price, edited the
quotation wording and exercised the named test-reviewer approval gate. Final
text/JSON download controls appeared only after approval, and the displayed
quotation retained Mock Data and Demo/no-inference labels. No customer was sent
anything.

The offline pricing smoke test reproduces the example above with zero HTTP
requests and verifies that unapproved finalization is rejected. The six-sample
Demo regression also continues to pass. No paid API calls, package installation,
large model download or API-credit purchase is part of this implementation.
