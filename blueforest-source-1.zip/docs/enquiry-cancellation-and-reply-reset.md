# Reply reset and customer enquiry cancellation

Checkpoint before editing: `380c25d`.

| Before | After |
| --- | --- |
| Previous sent reply remains in Message for customer | A successful publish callback clears only that reply field. The chosen bouquet stays selected. The next reply round starts blank, and earlier messages remain in history. |
| Batched form inputs make unsent draft retention difficult | The same bordered input group uses normal Streamlit inputs with a publish button. Draft changes are retained across view switches; failed publication does not clear the draft. Legacy sessions clear a carried-over reply that matches a saved published message. |
| Only Confirm proposal and Request changes | Cancel enquiry is available while Pending, In progress or Awaiting confirmation. An inline Keep enquiry / Confirm cancellation step prevents accidental closure. |
| No closed cancellation state | Both views show Cancelled; staff have a Cancelled filter with counts. Detail/history/photo/price snapshots remain available, while processing, proposal publication and pricing approval controls are absent. |
| Potential stale decision or saved quote following closure | Cancellation archives the active proposal and invalidates the current version. Confirmation/change requests reject cancelled enquiries, and saved custom workspaces cannot republish or reopen them. Repeat cancellation is idempotent. |
| Cancellation indistinguishable from closing the change form | The change form's exit is labelled Back to proposal. Cancel enquiry always refers to closing the enquiry. |
| Old estimate could imply more work was pending | Cancelled custom enquiries label prices as Previous estimate/quotation; Staff selling prices are also labelled as previous values. |

Cancellation is a local, pre-confirmation enquiry action, not a real order,
payment or refund action. Completed enquiries deliberately do not use this
entry point. No production cancellation policy is inferred. This adds a terminal
state to the existing session workflow; it does not modify the matching,
recognition, price calculation or quotation engines.

## Verification

- **149 tests passed in 80.161 seconds**: all previous 145 checks plus two workflow
  tests and two customer UI tests. No test was removed.
- Workflow tests cover both paths and all three unconfirmed starting states,
  repeated cancellation, stale confirm/change requests, workspace saves after
  cancellation, record/snapshot retention and rejection of completed cancellation.
- The customer suite verifies the confirmation step, Keep enquiry leaving status
  unchanged, closed customer controls, Staff filtering/read-only details, and
  reopening the same cancelled record from Home → Your enquiries.
- Reply tests verify unsent draft retention across role changes, clear-after-
  success, unchanged bouquet selection, the next round starting blank and both
  published replies remaining in history.
- Browser: an agent-created demo enquiry was revised and replied to, then a new
  customer change request showed an empty Staff reply field. Actual textarea
  value was empty and its counter showed 0/1000. Both earlier public replies
  remained visible in history.
- Browser: Cancel enquiry → Keep enquiry preserved the active proposal and still
  allowed Request changes. A later confirmed cancellation produced Enquiry
  cancelled, removed decision actions, added the cancellation event and appeared
  under Staff Cancelled (1). Staff detail showed no processing/reply controls.
- At 411px the cancellation confirmation had no horizontal overflow. The
  temporary viewport override was reset. Desktop controls were also inspected.
- No server restart, external submission, model installation or paid API call.

Logs:

- `output/enquiry-cancellation-regression.log`
- `output/enquiry-cancellation-core-tests.log` (11 tests)
- `output/enquiry-cancellation-customer-tests.log` (21 tests)

Screenshots in `output/enquiry-cancellation-ux/`:

- `staff-reply-blank.jpg`
- `customer-cancel-action.jpg`
- `cancel-confirmation.jpg`
- `mobile-cancel-confirmation.jpg`
- `customer-cancelled-mobile.jpg`
- `staff-cancelled-filter.jpg`
