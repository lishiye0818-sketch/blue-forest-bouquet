# Initial Phase 3A verification — 25 October 2026

This historical record covers commit `eacfa42`, before the zero-cost Demo extension.
See [demo-mode.md](demo-mode.md) for current mode behavior and verification.

Pre-change Git checkpoint: `40fd1aa`. Original working visual-search checkpoint:
`10c1025`.

## Verified

- **44 unit/integration tests pass**, including 25 original search/catalog/embedding
  tests and 19 Custom Bouquet tests. API outputs in these tests are mocked, not
  evidence of recognition quality. Tests cover the seven materials and real
  reference assets, expansion to 40 catalog entries, corrupt/oversized/transparent
  images, orientation/EXIF handling, multimodal request construction, strict
  response validation, Unknown/empty results, filler usage vs. heads, cluster units,
  mandatory review flags, invalid/truncated/service responses, credential errors,
  editable identities/counts and recomputed units, session persistence/reset,
  failed reanalysis and continued search when the material catalog fails.
- **Real CLIP + FAISS search regression passed** with the existing cached model:
  12/12 photos indexed, stable Top 3 IDs `[8, 9, 7]` across three runs, saved-index
  reuse and the Streamlit sample-photo flow. Model weights were not mocked.
  Hugging Face metadata access was required by the existing model loader.
- The original app/search/embedding/image utility modules, two product catalogs,
  original photo credit/source records and committed search evaluation report
  are unchanged from `40fd1aa`. All 13 original image hashes still match their
  attribution manifest. Bouquet catalog/image fingerprint remains
  `6b8636878bf84cbba535ac803f847f38c4bc877445d406fb24cb6dfb61eb7ca4`.
- **Six real licensed photos pass preparation**: a rose bouquet, mixed
  tulip/calla-lily bouquet, mixed carnation/alstroemeria bouquet, mixed
  hydrangea/chrysanthemum bouquet, out-of-catalog lavender bouquet and a baby's
  breath detail. Contents suggested by source titles are not ground-truth labels.
- A browser check verified the separate tab, seven-type catalog control, real
  mixed-photo upload/preview, manual editor and missing-key disabled state.
  The uploaded-photo preview adapts to the available width.
- New reference photos have creator/license/source/hash records and were visually
  inspected. No new packages, custom training or detection models were installed.
  Mock costs remain catalog data; no quotation or automatic price calculation
  exists.

Local reports and logs are ignored by Git:

- `output/phase3a-tests.log`
- `output/phase3a-search-regression.json`
- `output/phase3a-photo-smoke.json`

## Still unverified

No working `OPENROUTER_API_KEY` was configured at the time of these checks. The
live evaluator explicitly records `skipped_missing_api_key` and exit code 2,
with **zero live responses**. The application uses a real API integration; it
has no simulated recognition fallback. Actual provider access, vision request
success, latency, flower identification and count quality remain unverified.

After configuring the ignored `.env`, run:

```bash
.venv/bin/python -m evaluation.custom_bouquet_smoke --live
```

This sends six images to the configured provider. Inspect the resulting JSON
against the photos and record failures. Have a florist label a larger independent
set before claiming any accuracy. Include different cultivars, mixed/occluded
bouquets, filler-heavy arrangements, unsupported types and real no-flower
negatives. Evaluate visible counts separately from actual stem quantities.

No recognition accuracy is claimed. The schema validates structure, units and
review requirements, not botanical correctness. Hidden flowers, branching stems,
lookalike blossoms, reference limitations and model variability remain uncertain.
