# Phase 4B — Presentation UX verification

Verified 25 October 2026. Presentation changes only; existing business logic is preserved.

| Before | After |
|---|---|
| Six separate screens with no overview | Five visible steps with an accessible current-step indicator; review and costing remain separate parts of step 4 so saving is still required |
| Download and manually upload prepared JPEGs | Two **Try Demo Sample** buttons load the exact original registered files; upload, replacement and clear-photo controls remain available |
| Selected photo hidden in a collapsed sidebar | A shared photo preview beside both solutions, review, costing and quotation; one byte source drives both solutions |
| Tall composition table | Compact flower cards with consistent reference sizes, visible estimates, separate florist plans and unit costs; uncertainty notes in an expander |
| Long pricing form above the calculation | Itemized, right-aligned HKD table beside the reviewed price and delivery notes; adjustable costs, material details and calculation notes remain accessible in expanders |
| Repeated quotation output | Existing editable draft and explicit approval gate retained; finalized text available in an expander with downloads |
| Vase/table rose photo in the presentation catalog | One independently photographed rose-and-sunflower reference replaces it; eight reference candidates remain, with genuine CLIP/FAISS ranking |
| Faint captions and inconsistent detail styling | Forest-green palette retained; caption opacity corrected, consistent image frames, readable focus, button feedback, tabular prices and reduced-motion support |
| Six-step walkthrough | README, product guidance, photo manifest, license credits and presentation walkthrough updated |

The review editor now displays each selected material's costing unit. Counts and
clusters still never become florist quantities automatically. The save boundary,
Decimal calculations, template quotation, approval validation and invalidation
rules are unchanged. Presentation input values are retained across Back navigation
until an existing photo/review change explicitly invalidates them. Full workspace
and separate Live AI remain available.

## Automated verification

`output/phase4b-all-tests.log`: **109 / 109 passed** in 37.772 seconds.
All 104 original tests remain unchanged. Five new tests cover:

- Both sample buttons through real search, review, costing and final quotation.
- Switching samples clears the preceding review, pricing, draft and approval.
- Clearing a sample does not restore stale work on rerun.
- Choosing a sample replaces an existing upload with the original registered bytes.
- Returning from a finalized quotation retains reviewed price, delivery notes and
  custom cost inputs, including across earlier composition/review screens.

Tests block HTTP requests and use the existing cached CLIP model. No new model,
paid API, Ollama inference, dependency installation or training was used.

The independent offline smoke run also passes both photos through CLIP/FAISS and
the existing quotation engine. Results are saved in
`output/phase4-presentation-smoke.json` and `output/phase4b-offline-smoke.log`.

| Sample | Flower/material types | Materials | Suggested / reviewed mock price | Real Top 3, in returned order |
|---|---:|---:|---:|---|
| Peach Harmony | 6 | HK$457.00 | HK$881.55 | Peach & Calla Harmony; Hydrangea Blush; Sunset Mixed Bouquet |
| Sunshine Garden | 5 | HK$246.00 | HK$533.40 | Spring Festival; Golden Garden Bouquet; Sunset Mixed Bouquet |

Rankings document the actual run; they are not programmed matches or a measured
claim of retrieval accuracy. The new photo is an ordinary catalog candidate and
is not forced into either result list. Both sample JPEGs remain excluded from
the reference catalog.

## Actual browser verification

Both samples completed **Try Demo Sample → real Top 3 → predefined composition →
Save florist review → Calculate Mock Costs → Generate draft → named reviewer →
approval checkbox → finalization**. Finalization was tested with an explicitly
automated test reviewer; this is not an actual florist certification.

- Peach Harmony: native desktop Chrome. Six composition cards, saved quantities,
  HK$881.55 reviewed price and successful finalization were visible.
- Sunshine Garden: in-app browser at 333 px. Five composition cards, saved
  quantities, HK$533.40 reviewed price and successful finalization were visible.
- Returning from the finalized Sunshine quotation to pricing retained HK$533.40
  without a validation error; edited prices/costs and earlier-step return paths
  are covered by the additional regression test.
- Finalization was disabled until a reviewer name and the review checkbox were
  supplied. Finalized text and JSON download controls were visible for both.
- Narrow-screen document width and viewport width both measured 333 px; no
  horizontal page overflow. Data editor tables retain their own horizontal scroll.
- Rendered captions use `#4D5B50` at opacity 1; focus and reduced-motion styles
  remain available. No accessibility certification is claimed.

Screenshots are saved in `output/phase4b-ux/`. The presentation may still require
vertical scrolling on smaller displays, particularly for editable tables and
quotation approval. Details are collapsed where they do not need to be visible.

## Attribution and simulation disclosure

The new photograph is by PattayaPatrol, licensed **CC BY-SA 4.0**. The complete
composition is retained in the re-encoded JPEG; metadata is removed. Attribution,
source, license, dimensions, modification notes and SHA-256 are recorded in
[data/PRESENTATION_IMAGE_CREDITS.md](../data/PRESENTATION_IMAGE_CREDITS.md) and
[data/presentation-image-sources.json](../data/presentation-image-sources.json).
Its derivative remains under the source license. Result cards link directly to
the photographer's source and license.

Solution A remains genuine visual similarity retrieval. Solution B remains
**Demo Mode — Predefined Results, No AI Inference**. Sample composition and all
prices are illustrative Mock Data. Unknown photos still use manual composition;
quotation generation still uses the existing fixed template. No customer message
was sent during verification.
