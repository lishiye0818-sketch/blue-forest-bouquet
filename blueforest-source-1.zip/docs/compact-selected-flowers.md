# Compact selected flowers and one customer example

Checkpoint: `30b3bb3`.

The shared Customer photo picker presents one A00 example alongside the uploader.
The existing A00/B00 files, upload recognition and real similarity ranking are
unchanged. The separate original Staff/technical demo examples are unchanged.

Your flower selection reuses the material thumbnail component in a new 40×40px
mode (80px source thumbnail), with names and unit selling prices styled like the
quotation lines. Selected flowers share one white panel with thin separators,
two columns above 1100px and one column below. At 640px and narrower the native
quantity/Remove/Replace controls wrap beneath the flower description. Missing
photos retain an accessible placeholder. The available-material gallery and
Staff catalog keep their existing image sizes.

The existing draft keys, callback handlers, quantity validation, selling-price
function, catalogue and quotation snapshots are unchanged. Four selected flowers
measure 146px high at a 1280px viewport. At 390px, all controls fit inside the
list and there is no horizontal page overflow. Browser verification also checked
that changing White Rose from five to six recalculates HK$173 to HK$191 and back.

203 regression tests passed, including Customer DIY add/remove/replace/quantity,
both reference uploads, genuine CLIP/FAISS ranking, Staff edits/review and stored
quote versions. Tests exercise B00 through the actual upload callback now that
it has no visible demo button. Screenshot/geometry evidence, test log, database
backup and data-preservation checks are in `output/compact-selected-flowers/`.
