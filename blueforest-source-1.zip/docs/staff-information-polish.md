# Staff information panel

Checkpoint before editing: `f4d7938`.

| Before | After |
| --- | --- |
| Bouquet, contact, fulfilment and price spread across separate Streamlit blocks | One compact brief beside the existing reference/product photos. Bouquet name and selling price lead together. |
| Unlabelled contact, date and address | Aligned Contact, Collection/Delivery and Address rows; dates use a readable day/month/year format. Long values wrap on small screens. |
| Large default blue email link | Botanical-green email link with an understated underline and visible keyboard focus. The mailto destination is URL encoded. |
| Customer preferences and proposal messages dispersed on the page | Separate, labelled Customer preferences, Message for customer and Collection/delivery notes sections when supplied. Duplicate unlabelled proposal text is removed. |
| Prominent mock-price caption between loosely spaced fields | A small Catalogue price, Preliminary estimate or Florist-reviewed price label beside the selling price. The footer explanation, stored mock provenance and quotation exports remain unchanged. |
| Submission time/reference separated by large gaps | Quiet metadata footer with a thin divider and closely spaced timestamp/reference lines. |
| Large image-to-detail gap on mobile | Stacked layout with a 20px gap; compact label/value columns and responsive type. |

Only presentation code and CSS changed. The same panel is used on the Staff
enquiry detail screen and inside the quotation workspace's existing reference
disclosure. Photos, submitted values, states, review rules, costs and quotation
approval logic are unchanged. All user-supplied text is escaped before rendering.

## Verification

- **143 existing regression tests passed in 71.398 seconds**.
- Existing-bouquet Awaiting confirmation and custom-bouquet Completed/Pending
  requests were inspected without changing their states.
- Desktop information rows align with the heading and footer. Custom preferences
  and approved collection notes remain visible; existing-bouquet catalogue prices
  and custom preliminary/reviewed prices retain their distinctions.
- At 411px, the panel is 379px wide with no horizontal overflow; image-to-panel
  gap is 20px. Final spacing-only CSS adjustments were checked in the browser
  after regression testing. The temporary viewport override was reset.
- Email styling and the mailto destination were inspected. The browser blocked
  opening the external mail destination; this was not retried or bypassed.
- No model, API, search, recognition, pricing or approval engine changes; no
  server restart or external submission.

Log: `output/staff-information-regression.log`.

Screenshots: `output/staff-information-ux/existing-details.jpg`,
`output/staff-information-ux/custom-details.jpg`, and
`output/staff-information-ux/mobile-details.jpg`.
