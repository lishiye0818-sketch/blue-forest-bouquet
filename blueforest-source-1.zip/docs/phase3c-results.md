# Phase 3C results — 25 October 2026

**Decision: do not integrate the tested 2B configuration into Streamlit yet.**
Real local vision inference runs on this Mac, but the responses were not reliable
enough for florist-facing flower identification/counting. Existing app features
and Phase 3B quotation code are unchanged. No paid API or cloud inference was used.
No 4B weights were downloaded.

## Machine and setup

- MacBook Air, Apple M1, 8 CPU cores, 7 GPU cores, 8 GiB unified memory.
- macOS 26.5.1; Metal GPU inference confirmed by Ollama.
- Official portable Ollama v0.40.11, checksum verified, in
  `output/ollama-runtime/`. Weights are in `output/ollama-models/`.
- User approved 2B first, then separately approved the 2B Instruct variant.
- Server bound to `127.0.0.1:11434`; log confirms `Ollama cloud disabled: true`.
- The test client ignores proxy/host/key environment settings, rejects remote
  model metadata and cloud tags, blocks redirects, and cannot download models.
- Six existing licensed photos, JPEG preprocessing with maximum edge 1,024 px,
  context 4,096, temperature 0, seed 42, sequential inference, `keep_alive=0`.
  Latency includes loading; this was an exploratory run with other apps active,
  some concurrent unit testing and download activity, not a controlled benchmark.

## Three recorded experiments

| Model and profile | Completed responses | Passed observation validation | Wall-clock latency |
|---|---:|---:|---|
| qwen3-vl:2b, full | 6 of 6 | 0 of 6 | 67–105 s; median 82.3 s |
| qwen3-vl:2b-instruct, full | 3 of 6 | 0 of 3 | 95–110 s; median 106.5 s |
| qwen3-vl:2b-instruct, compact | 6 of 6 | 4 of 6 | 24.7–37.2 s; median 29.4 s |

**These are output-validation results, not flower-recognition accuracy.** Four
structurally valid responses do not mean four correct identifications.

The default 2B tag resolved to Thinking weights, digest prefix `0635d9d857d4`.
All six full-profile calls reached 1,800 generated tokens without final content,
despite `think=false`. Reasoning-only output was rejected, not extracted as a
partial recognition result.

The distinct Instruct weights, digest prefix `afc393e3572c`, produced JSON-like
text in the full profile but repeated rows/catalog entries and lengthy notes
until the same token limit. After three completed failures, the fourth request
was interrupted and the last two were not attempted in that profile. All saved
failures remain available. A complete six-image test followed with the compact
profile; it did not overwrite either earlier experiment.

The compact profile uses a shorter prompt/catalog, six output fields per flower,
bounded rows/notes, a 1,200-token limit and repeat penalty 1.1. Application code
adds mandatory human-review metadata only. It does not supply or repair flower
identities, counts, filler usage or uncertainty. Raw model outputs remain saved.

## Compact six-photo observations

All entries below are **unverified model claims**, never florist-approved counts
or stem quantities. `clusters` means whole hydrangea flower clusters.

| Photo ID | Seconds | Model output / rejection | Review concern |
|---|---:|---|---|
| rose_bouquet | 24.740 | Rose 20 heads, Tulip 15 heads, Hydrangea 20 clusters | Apparent extra flower types and inflated cluster count; two rows said uncertainty “none” |
| mixed_tulips | 33.208 | Rejected: filler usage assigned to non-fillers; baby's breath counted as individual heads | Invalid counting/usage policy; unsupported flowers not handled conservatively |
| mixed_carnations | 31.731 | Rose 2, Lisianthus 2, Carnation 1, Tulip 2 heads; Hydrangea 1 cluster | Broad type claims with high confidence and vague “low” uncertainty |
| mixed_hydrangeas | 27.049 | Hydrangea 10 clusters; Lisianthus 2, Tulip 1, Carnation 2 heads | Possible cluster/floret confusion and additional unsupported type claims; overlap acknowledged |
| unsupported_bouquet | 37.175 | All seven catalog types listed; six counts null; baby's breath usage light | Notes named lavender, but no Unknown row; listed types with “no visible heads” |
| filler_detail | 24.854 | Rejected: hydrangea given filler usage; also claimed Lisianthus 25 heads | Filler close-up was not represented as filler usage; counting unreliable |

The apparent visual errors above are qualitative review concerns from inspecting
the photos/outputs, **not independently reviewed botanical ground truth**. No
specific true head count is asserted. Some counting-policy problems require no
gold labels to detect: non-fillers received filler usage, a filler received an
individual count, rows repeated, and listed types contradicted their own notes.
Short bounded notes sometimes ended mid-sentence, so concise completion did not
guarantee useful explanations.

## Labels, uncertainty and accuracy

No independent florist-reviewed labels/counts were found. The template
`evaluation/local_vision_labels.json` therefore leaves all six photos unreviewed.
Demo fixtures, source titles and synthetic pricing reviews were never used as
ground truth or sent as expected answers. Sample IDs such as `mixed_carnations`
are organizational names, not verified identities.

Identity precision/recall and count error remain **unmeasured**, not zero. The
comparison code is ready for named independent human reviews tied to the original
image SHA-256. It reports missing/extra types separately and scores count errors
only on matched countable types. It never substitutes stems for visible heads.
Unknown is one coarse group. Human review is mandatory for every accepted result;
model confidence is not calibrated and “none/low” was not meaningful uncertainty.

## Resource findings and 4B assessment

The sampled peak Ollama model allocation was approximately **2.02 GiB** for 2B
Instruct, with the reported allocation on Metal. This is **not total process RAM**
or a complete peak-memory measurement. System-wide swap rose from about 4.5 GiB
at the hardware check to a sampled maximum of **7.53 GiB** during the experiments.
Other apps contributed, so that increase cannot be attributed entirely to Ollama.
No out-of-memory error or network failure occurred in the completed inference
requests; output limits and semantic validation were the failures.

The 4B download is approximately 3.3 GB according to
[Ollama's model listing](https://ollama.com/library/qwen3-vl:4b), versus about
1.9 GB per [2B Instruct download](https://ollama.com/library/qwen3-vl:2b-instruct).
Planning estimates were roughly 3–5 GB working memory for 2B and 5–7 GB for 4B at
short context; these estimates exclude other apps and are not guarantees. M1 is
supported, so 4B is potentially runnable with compromises, but this Mac's current
memory pressure makes it a poor next trial. **4B is untested and not approved for
download.** Nothing here establishes its quality or actual memory requirement.

## Evidence and repeat testing

- Committed machine-readable summary: `evaluation/local_vision_results.json`.
- Original 2B raw responses/errors: `output/local-vision/qwen3-vl-2b-six-photos.json`.
- Interrupted full Instruct run: `output/local-vision/qwen3-vl-2b-instruct-six-photos.json`.
- Complete compact run: `output/local-vision/qwen3-vl-2b-instruct-compact-six-photos.json`.
- Environment and three memory/swap monitor files: `output/local-vision/`.
- Contact sheet for independent review: `output/local-vision/photos-for-review.jpg`.
- Automated tests: **93 passing** including preserved app/demo/pricing tests,
  local-only transport, no automatic downloads/cloud fallback, error retention,
  compact/full schema handling, manual-label provenance and interruption handling.

Large runtime/weight/raw files stay in ignored `output/`; the code, blank label
template, compact summary and findings are tracked. The reports preserve model
digests, image hashes and settings. See [setup and rerun instructions](local-vision.md).
The test server was stopped after verification; no model remains loaded.
The approved runtime and both 2B weight sets are retained for reuse.

Keep Demo Mode/manual florist review for the current project workflow. Before a
future local integration, obtain independent labels, test additional held-out
mixed bouquets and demonstrate conservative Unknown/filler handling and much
better type/count reliability. A larger model is a hypothesis to test, not a
promised fix. No recognition output from this experiment enters pricing or a
customer quotation.
