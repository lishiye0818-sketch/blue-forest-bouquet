# Phase 3C — local vision feasibility experiment

This experiment is separate from Streamlit. Solution A, Demo Mode, Live OpenRouter
Mode and Phase 3B pricing/quotation code are unchanged. It uses real Ollama vision
inference only when explicitly run; it never substitutes fixture results.

## Hardware assessment (25 October 2026)

Measured on this Mac: MacBookAir10,1, Apple M1, 8 CPU cores, 7 GPU cores,
8 GiB unified memory, macOS 26.5.1, Metal support. About 26 GiB disk space was
available. The snapshot showed 4.5 GiB of swap in use and a reported 34% free
memory. These are changing snapshots, not a peak-memory benchmark.

Ollama was initially absent from PATH, standard application/binary locations and
Spotlight; its loopback service was unavailable. The user subsequently approved
the Ollama runtime and **2B only**. The official v0.40.11 portable runtime was
downloaded into the ignored `output/ollama-runtime/` folder (181 MB archive,
about 737 MiB including extracted files and the archive). Its SHA-256 matched
the official release metadata. Cloud features are disabled in the test server.
No 4B download is authorized.

The initial `qwen3-vl:2b` download resolved to a Thinking variant (digest prefix
`0635d9d857d4`). Early requests produced no final JSON before the token limit,
despite `think=false`. Its failures are retained. The user separately approved
another approximately 1.9 GB download for
[`qwen3-vl:2b-instruct`](https://ollama.com/library/qwen3-vl:2b-instruct).
These are different weights, tested in separate runs. No 4B weights are installed.

| Model | Published download | Planning estimate of working memory | Assessment |
|---|---:|---:|---|
| qwen3-vl:2b, Q4_K_M | 1.9 GB | roughly 3–5 GB | Try first, one image at a time |
| qwen3-vl:4b, Q4_K_M | 3.3 GB | roughly 5–7 GB | Tight on an 8 GiB Mac; defer |

Working-memory figures are estimates for a resized image and 4,096-token context,
not Ollama guarantees or measurements. Model weights alone understate runtime
memory. macOS and other apps also need memory. Extra swap, long latency or an
out-of-memory error are possible, especially for 4B. The Ollama runtime requires
additional download/disk space. Both models together need about 5.2 GB of model
downloads before runtime files; allow additional free space for swap.

Primary sources, checked 25 October 2026:

- [Ollama 2B size and minimum version](https://ollama.com/library/qwen3-vl:2b)
- [Ollama 4B size](https://ollama.com/library/qwen3-vl:4b)
- [macOS and Apple Silicon support](https://docs.ollama.com/macos)
- [Context, memory, local-only mode and model storage](https://docs.ollama.com/faq)
- [Vision image encoding](https://docs.ollama.com/capabilities/vision)
- [Chat JSON schema, timing fields and keep-alive](https://docs.ollama.com/api/chat)

## Run without downloading anything

From the project directory, using the existing environment:

```bash
.venv/bin/python -m evaluation.local_vision
.venv/bin/python -m unittest discover -s tests -v
```

The first command prepares the existing six photos, verifies the label template's
photo hashes and writes a timestamped report under `output/local-vision/`.
It performs **no inference and no network requests**. Tests use synthetic
responses, not real model inference. No new Python dependencies are required.

## Install and run only after download approval

Install [Ollama for macOS](https://ollama.com/download/mac), version 0.12.7 or newer.
The default model size is 1.9 GB for 2B. Download only the model explicitly
approved. No account, API key, API credits or cloud model is needed.

Quit another running Ollama instance before starting a dedicated local-only
server in a terminal. Close memory-heavy apps if practical. Keep this terminal open:

```bash
OLLAMA_NO_CLOUD=1 OLLAMA_HOST=127.0.0.1:11434 OLLAMA_NUM_PARALLEL=1 OLLAMA_MAX_LOADED_MODELS=1 ollama serve
```

For the portable runtime installed in this checkout, use this instead (no global
installation or PATH changes are needed):

```bash
OLLAMA_MODELS="$PWD/output/ollama-models" OLLAMA_NO_CLOUD=1 OLLAMA_HOST=127.0.0.1:11434 OLLAMA_NUM_PARALLEL=1 OLLAMA_MAX_LOADED_MODELS=1 OLLAMA_CONTEXT_LENGTH=4096 OLLAMA_KEEP_ALIVE=0 ./output/ollama-runtime/ollama serve
```

The local test stores weights in `output/ollama-models/`. Use
`./output/ollama-runtime/ollama` in place of `ollama` for CLI commands below.

In another terminal, after approval:

```bash
OLLAMA_HOST=127.0.0.1:11434 ollama pull qwen3-vl:2b
.venv/bin/python -m evaluation.local_vision --check --model qwen3-vl:2b
.venv/bin/python -m evaluation.local_vision --run --model qwen3-vl:2b
```

`--check` reads local version/weight/vision metadata; it does not generate.
`--run` sends the six images to the local server sequentially. The harness cannot
pull models. It ignores `OLLAMA_HOST`, API keys and proxy variables itself and
uses literal `127.0.0.1`. Use `--port` if you deliberately start the local server
on another port. Remote/cloud tags and remote-model metadata are rejected, and
redirects are blocked. `OLLAMA_NO_CLOUD=1` disables cloud features in the server.

Full-profile requests use a maximum 1,024-pixel image edge, temperature 0, seed 42,
4,096-token context, 1,800 generated-token limit and request no thinking output.
`keep_alive=0` unloads the model after each photo to limit memory use. Reported
wall-clock latency therefore includes model loading; it is not warm app latency.
The default read timeout is 240 seconds per request; `--timeout` accepts 1–600.
There are no automatic retries, downloads, JSON repairs or cloud fallbacks.
Failures are evidence and stay in the report.

The client requests `think=false`; this is not a guarantee that a model obeys it.
Raw response fields distinguish reasoning from final content. Reasoning-only or
truncated output is a failure, never a recognized-flower result. For the approved
Instruct variant, explicitly use:

```bash
.venv/bin/python -m evaluation.local_vision --run --model qwen3-vl:2b-instruct
```

The separate compact profile keeps the same image size/context and asks for six
fields per flower: identity, visible count, counting unit, filler usage,
confidence and uncertainty. It uses a shorter catalog/prompt, at most eight rows,
160-character uncertainty/overall notes, a 1,200-token limit and repeat penalty
1.1. Mandatory human-review booleans/flags are added deterministically by the
application; identities, counts and uncertainty are always model outputs. This
profile is recorded as `phase3c-v2-compact`, distinct from the original full
profile `phase3c-v1`. It does not change the Streamlit/OpenRouter prompt.

```bash
.venv/bin/python -m evaluation.local_vision --run --model qwen3-vl:2b-instruct --profile compact
```

If 4B is separately approved, pull `qwen3-vl:4b` and repeat with `--model
qwen3-vl:4b`. Run models separately; do not assume that downloading a model means
it will fit in memory. In another terminal, `ollama ps`, Activity Monitor and
`sysctl vm.swapusage` can help observe GPU use, memory and swap during a run.
Stop with Control-C if the machine becomes unresponsive. Interruptions preserve
completed cases in the JSON report; an in-flight response may not be saved.

## Six existing licensed images

| Sample ID | File | Evaluation role |
|---|---|---|
| rose_bouquet | data/images/bouquet-07.jpg | Dense overlapping heads |
| mixed_tulips | data/images/bouquet-01.jpg | Mixed arrangement |
| mixed_carnations | data/images/bouquet-02.jpg | Mixed arrangement, ambiguous types |
| mixed_hydrangeas | data/images/bouquet-04.jpg | Clusters versus individual heads |
| unsupported_bouquet | data/images/bouquet-12.jpg | Out-of-catalog handling |
| filler_detail | data/images/materials/babys_breath.jpg | Filler close-up, not a full bouquet |

Sample IDs/source titles are organizational names, not verified identities.
Only the photo and catalog descriptions enter the prompt: no photo name, source
title, demo output, cost, manual label or expected answer is sent to the model.
The catalog has seven materials; unsupported flowers should be `unknown`.
The sixth photo does not establish bouquet-wide filler usage. Existing photo
licenses remain in `data/IMAGE_CREDITS.md` and `data/MATERIAL_IMAGE_CREDITS.md`.

## Independent manual review and comparison

`evaluation/local_vision_labels.json` is a blank template. All six entries are
**unreviewed**. It is not ground truth. No florist-verified labels/counts were
found in the project. Demo fixtures, source titles and synthetic pricing reviews
are excluded. The loader explicitly rejects the existing demo fixture format.

For a real comparison, inspect the original image independently of the model
and demo results. In a copy of the template, enter each verified flower using:

```json
{
  "material_id": "rose",
  "visible_heads": null,
  "counting_unit": "flower_head",
  "usage_category": null,
  "notes": "Describe the independently observed evidence and count limitations."
}
```

This is an example of the format, not a label for any sample. Use a count only
when independently countable. Hydrangeas use `flower_cluster`. Baby's breath uses
`usage_category`, null counts and `light`, `moderate`, `heavy` or `uncertain`.
Unknown uses `unresolved` and null count/usage. Set a sample's `status` to
`reviewed`, enter `reviewed_by` and replace its null `flowers` with the reviewed
list. An empty list explicitly means no flowers. Keep unreviewed samples null.
Do not change the stored photo SHA-256; changed photos require fresh review.

```bash
.venv/bin/python -m evaluation.local_vision --init-labels output/my-manual-labels.json
.venv/bin/python -m evaluation.local_vision --run --labels output/my-manual-labels.json
```

Template creation refuses to overwrite an existing file. Reports compare only
completed, named human reviews for the same photo hash. They record missed/extra
types, absolute count errors on matched countable types and filler-category
agreement. Null/unreliable counts are not scored. Missing types are reported
separately, never silently assigned zero counts. `unknown` is one coarse group,
so matching it does not prove which unsupported species was seen. Metrics cover
only successful responses with reviewed labels; inspect failed cases separately.

## Report and integration decision

Each report saves model version/digest/disk size, prompt version, generation
settings, image hashes, prepared image sizes, raw model envelopes, validated
observations, wall-clock latency, Ollama timing fields, errors and uncertainty.
Visible-count observations are always flagged for human count checking; manual
disagreements are listed separately as possible counting mistakes. Model
uncertainty alone is not proof that a particular count is wrong or right.

**Current decision: do not integrate this tested configuration yet.** Real
inference has completed on all six photos, using the approved 2B and 2B Instruct
weights. The compact Instruct run took 24.7–37.2 seconds per photo; four responses
passed structural validation, but qualitative type/count concerns, filler-policy
errors and weak uncertainty remain. The full profiles hit output limits.
Independent recognition/count accuracy is still unmeasured. See the
[full results and limitations](phase3c-results.md) and
`evaluation/local_vision_results.json`.

After a real run, examine unsupported-flower hallucinations, confused identities,
cluster/head mistakes, overlap, conservative nulls, filler handling, failure rate,
latency and memory pressure. Collect independent reviews and additional held-out
bouquets before recommending integration. Even if suitable as a florist aid,
visible-head estimates must not become stem quantities or quotations
automatically. Phase 3B continues to use separately reviewed quantities.
