# Phase 5D — Compact flower selection and shop-only Top 2

Checkpoint before changes: **`d583be1`**.

## Customer flower selection

Edit my bouquet now uses horizontal cards with **104 × 104px** image frames,
reduced to **96 × 96px** below 520px. Images use `object-fit: contain`; cached
thumbnail data is at most 208 × 208px for sharper displays. Original PNG files
are untouched. Staff material photography and other bouquet images retain their
existing sizing.

Each card groups the photo, English/Chinese name, current selling price/unit and
native Streamlit controls. Selected flowers have quantity, Remove and Replace;
unselected flowers have Add to bouquet. Two columns become one below 1100px,
and phone controls move under the photo/details. The live total stays visible;
its line-by-line breakdown can be expanded.

## Active customer search catalog

Previously the customer screen queried `data/presentation_bouquets.csv`, whose
FAISS image index contained eight legacy references, then separately listed four
shop designs. Customer search now reads the **existing `shop_bouquets` table**
through the same `shop_products()` adapter used for BOM selling prices:

- A01 — Blue & White Harmony
- A02 — Blue & White Romance
- B01 — Bright Garden Delight
- B02 — Sunny Garden Bouquet

No second product catalog, fixed prices or product group rules were introduced.
Only active products with valid local photos and complete current prices are
eligible. A00/B00 are upload examples and have no shop product rows, so they do
not enter this index. Legacy references are not customer search candidates;
the separate original technical reference workspace remains available.

The existing cached `openai/clip-vit-base-patch32` model embeds the four photos.
The existing FAISS `IndexFlatL2` implementation searches their normalized CLIP
vectors with `k=2`. Results retain FAISS distance order; a smaller catalog produces
fewer results. Images, permanent IDs and model/preprocessing version fingerprint
the disk cache under **`indexes/shop-bouquets/<fingerprint>/`**. Product names and
BOM prices are refreshed from SQLite, rather than stored as pricing inputs in
the index. Changing catalog membership or photo bytes selects a new cache.

The two matches are selectable shop cards. Other available designs appear once
in **Browse the rest of the shop collection**, excluding the matched IDs.

## Preservation and verification

No database/schema, material image, selling price, BOM or submitted quotation
changes are part of this phase. Pricing remains the shared
`SUM(unit_selling_price_hkd × quantity)`, with additional charges at HK$0.

The regression suite contains **187 tests**, including ten new checks for the
shop-only catalog, true nearest-neighbor ranking, cache reuse with live prices,
inactive/missing/unpriced products, zero/one available result, failed-image ID
mapping, all twenty compact images, customer controls and duplicate-free results.
Real offline CLIP retrieval is independently compared with the full four-vector
L2 ranking. The existing Staff approval, quotation snapshot, role switching and
Demo Mode tests remain in the suite.

Local verification artifacts, the pre-change SQLite backup, image hashes and
desktop/390px screenshots are saved in **`output/phase5d/`**. A full Streamlit
restart was needed to clear old imported component signatures in the running
process. The application continues at **http://127.0.0.1:8504/**.

## Changed files

- `product_search/app/flower_materials.py`: optional compact thumbnails/cards and grouped native controls.
- `product_search/app/customer.css`: scoped compact-card, total-panel and responsive styles.
- `product_search/app/selling_prices.py`: optional collapsible breakdown; calculation unchanged.
- `product_search/app/customer_app.py`: shop-only Top 2, nonduplicated choices and compact DIY total.
- `product_search/shop_search.py` (new): active shop catalog adapter, image-keyed index and real retrieval.
- `tests/test_shop_search.py` (new): ten focused catalog, ranking, thumbnail and workflow tests.
- `tests/test_customer_experience.py`: customer Top 2 expectations and search-boundary assertions.
- `README.md`, `PRODUCT.md` and this guide: current behavior and verification notes.
