# Quotation photos and shop similarity refinement

Checkpoint before this change: `a682c9b`.

Quotation versions now uses the existing selling-summary renderer with 40×40px
flower thumbnails (80px source thumbnails for sharpness). This applies to the
original request and every reviewed proposal in both Customer and Staff views.
Photos are resolved by material ID, including inactive materials. Valid captured
DIY photos take precedence, with current catalog photos filling older missing
paths. An unavailable image shows the existing placeholder. No quotation is
recalculated or updated: historical names, quantities, units, unit prices and
totals still come exclusively from the captured price snapshot.

The previous index was neither stale nor mapped to the wrong products. It
contained A01, A02, B01 and B02, and its vectors matched newly computed whole-photo
CLIP vectors exactly. A00's original squared-L2 order was A01 (0.207382), B02
(0.237213), A02 (0.286569), B01 (0.320309). The screenshot accurately reflected
that ranking; there was no reference-group guarantee.

Shop search now applies one general image representation to every product and
query: encode the full photo and its centred square spanning 75% of the shorter
side with the existing cached CLIP model, sum the two normalized vectors with
equal weight, and normalize again. FAISS ranks the resulting 512-dimensional
vectors by squared L2 and returns at most the nearest two available products.
This retains whole-photo context and adds a closer view of the bouquet. The
comparison suggests background/wrapping context contributed to the old mismatch;
this is an inference, not botanical recognition or a guarantee for every photo.

The index key/build report includes `clip-full-and-center-075-v1`, so old vectors
cannot be mixed with the new query vectors. Old in-session results refresh when
the results page is visited; photos, drafts and enquiry state are preserved.
The customer demo matcher, shared CLIP model class and original technical search
are unchanged. No IDs, filenames, demo classifications, palettes or colour-group
rules take part in the search algorithm. A00/B00 remain query examples only.

Measured results on the actual local reference files (smaller distance is closer):

| Query | Rank 1 | Rank 2 | Other products |
| --- | --- | --- | --- |
| A00 | A01 · 0.113171 | A02 · 0.203053 | B02 · 0.215816; B01 · 0.251459 |
| B00 | B01 · 0.288559 | B02 · 0.291923 | A01 · 0.393041; A02 · 0.481850 |

The genuine CLIP tests independently reconstruct all four product vectors and
query vectors and compare the complete distance order against FAISS, with network
requests blocked. They also verify every product self-match and the older test
references. Focused coverage includes failed images/product mappings, live prices
with cached vectors, stale-session refresh, all 20 material photos, historical
quotation images/amounts and Customer/Staff quotation revisions.

Verification: 202 regression tests passed. Runtime screenshots, the index/ranking
audit, database backup and data-preservation checks are saved under
`output/quotation-photos-search/`. No database schema, catalog records, material
or product photos, selling-price formula, BOMs or stored quotations were changed.
