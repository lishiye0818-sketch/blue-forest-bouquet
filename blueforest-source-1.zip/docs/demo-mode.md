# Zero-cost Demo Mode — Phase 3A extension

Both **Find Similar Bouquets** and **Custom Bouquet** remain available. The
pre-extension implementation is saved in commit `eacfa42`; search code, live vision
API code, original photos and catalog data are preserved by this extension.

## Run and switch modes

```bash
.venv/bin/python -m streamlit run product_search/app/streamlit_app.py
```

Open **Custom Bouquet → Analysis mode**:

- **Demo Mode (Mock AI, no API calls)** is the default. No key, credits, network,
  additional package or model download is required. Select **Demo sample**, click
  **Load demo results**, then inspect and edit the florist review.
- **Live AI Mode** retains the existing OpenRouter integration. Configure
  `OPENROUTER_API_KEY` in the ignored `.env` and restart the server. Upload a photo
  and explicitly click **Identify flowers**. The model is still selected by
  `BOUQUET_VISION_MODEL`, default `openai/gpt-4.1-mini`. A click in this mode can
  incur provider charges. Do not use it when demonstrating at zero cost.

Switching modes clears previous analysis and saved review, so demo observations
cannot be presented as live results. Tab changes, editing, saving, mock cost
previews and downloads do not call a model. Demo never falls back to Live.
Solution A's separate semantic-search option retains its own API requirements;
its Keyword and cached/local image-search behavior is unchanged.

## Predefined fixtures

`data/custom_bouquet_demo.json` contains six manually authored, explicitly
simulated fixtures corresponding to the six existing Phase 3A smoke-test images.
Five are bouquets/arrangements and the sixth is a filler detail:

| Sample ID | Existing photo | Illustrative result |
| --- | --- | --- |
| `rose_bouquet` | `data/images/bouquet-07.jpg` | Rose, approximately 24 visible heads |
| `mixed_tulips` | `data/images/bouquet-01.jpg` | Tulip, approximately 7 heads; other material Unknown |
| `mixed_carnations` | `data/images/bouquet-02.jpg` | Carnation, approximately 4 heads with deliberately low confidence; other heads Unknown |
| `mixed_hydrangeas` | `data/images/bouquet-04.jpg` | Hydrangea, approximately 3 whole clusters; chrysanthemums Unknown |
| `unsupported_bouquet` | `data/images/bouquet-12.jpg` | Unknown for out-of-catalog lavender; no count |
| `filler_detail` | `data/images/materials/babys_breath.jpg` | Baby's breath, uncertain usage; no individual head count |

These are teaching examples, not AI inference, florist-verified counts or
accuracy claims. The mixed-carnation fixture explicitly warns that some visible
heads may instead be chrysanthemums; it is useful for demonstrating corrections.
The filler close-up cannot establish usage in a complete bouquet, so its rough
usage category is `uncertain`. Filler usage supports `light`, `moderate`, `heavy`
and `uncertain`; no category implies bunch or portion quantity.

Every simulated result is labelled:

**Demo Mode — Predefined Results, No AI Inference**

The label appears in the interface, analysis notes and download provenance.
Result/review tables also carry a source column so their built-in CSV exports
retain the Demo context. Mock
quotation drafts retain it too. Fixtures contain the same structured observation
fields as Live results: catalog flower ID, visible-head/cluster estimate or null,
counting unit, filler usage or null, uncertainty, confidence and mandatory human
review flags. Confidence in a fixture is also a preset, not a model assessment.

Each entry stores a stable sample ID and the SHA-256 hash of the original photo
bytes. The loader validates schema, supported units and photo hashes. The picker
selects registered IDs; uploaded files match only by exact hash. Renaming a photo
still matches. Cropping, recompression or changing its bytes makes it an
unregistered upload; there is no nearest-image fallback.

For unregistered uploads, Demo produces **no recognition result**. Use the flower
selection and quantity editor, add/remove rows, and save a manual review. Manual
exports are identified as manual and retain the Demo/no-inference label. Broken
fixture data displays an error and leaves manual review and Solution A usable.

The existing photo licenses and attribution manifests are unchanged. No additional
image assets were downloaded for this extension.

## Review and mock quotation preparation

The shared florist editor preserves editable flower types, reviewed visible
counts, filler usage and notes. **Florist quantity** remains separate and starts
blank. Enter whole stems or fractional bunches/portions as appropriate. Units are
recomputed when changing a flower type; Unknown has an unresolved unit and cannot
be assigned a material quantity until resolved in the catalog.

After saving the review, expand **Next phase · Mock costs and quotation draft**:

- Unit costs come from `mock_unit_cost_hkd` in the material catalog.
- Each mock line cost is entered quantity × mock unit cost, rounded to HKD cents
  with decimal arithmetic. Visible-head counts and filler usage never enter this
  calculation. Zero quantity excludes a known material.
- Missing quantities and Unknown materials leave the draft incomplete. A known
  material subtotal may still be displayed, but the complete material total is
  null until all rows are resolved and a positive quantity exists.
- Download an internal text draft or structured mock cost JSON. They are marked
  **Mock quotation draft — For review only, not a supplier or customer quotation**.
  Labour, wrapping, delivery, markup, tax and supplier availability are excluded.

Editing the review after saving hides the saved draft until it is saved again.
Changing photo, mode, catalog, live model or analysis resets the review/draft.
The original material-only draft remains available. [Phase 3B](mock-pricing.md)
adds complete Mock Data pricing and locally finalized customer quotations after
florist approval. There is no supplier quote, customer submission, order or
external publication.

## Demo extension verification — 25 October 2026

This records the 57-test Demo checkpoint `74bd5c5`. Current Phase 3B coverage is
documented in [mock-pricing.md](mock-pricing.md).

```bash
.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python -m evaluation.custom_bouquet_demo
```

The Demo smoke evaluator blocks HTTP calls and live inference, loads all six
samples through Streamlit, checks their provenance and saves each review with
material quantities still blank. It writes
`output/demo-bouquet-smoke.json` and reports zero HTTP requests and zero live
inference attempts. Run it without a key or with an existing key; it never uses
the key for a model call.

**57 tests pass**, including the 44 existing tests and 13 Demo/mock-cost tests.
New coverage includes hash-bound fixtures, all six sample flows with and without
credentials, changed/unregistered uploads, renamed originals, copied fixture
isolation, invalid/stale fixtures, manual review and costing, mode/sample reset,
Solution A availability on fixture failure, decimal rounding, missing/unknown
quantities, and separation of heads/filler usage from pricing quantities.
A browser check also loaded predefined results, edited the rose material quantity
to 3 stems while keeping the preset 24 visible heads, and verified the mock
subtotal of HK$54.00 and both Demo/mock-draft labels.

Live-mode request construction and failure handling remain covered by mocked
API tests. No paid API calls, credit purchase, package installation or large model
download was performed. Live recognition accuracy and latency remain unverified;
Demo fixtures provide no evidence about either.
