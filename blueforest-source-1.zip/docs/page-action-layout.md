# Consistent page actions

Checkpoint before this refinement: `ed1bbbc`.

The current Customer and Staff interface uses the existing enquiry-page pattern:
navigation at the top left, followed by the heading with page commands at the
top right. `product_search/app/page_actions.py` supplies the reusable containers.
On small screens, the heading and commands stack while retaining their alignment.

| Page / state | Top-left navigation | Top-right commands |
| --- | --- | --- |
| Find Similar · photo | Back to Home | Find Similar Bouquets |
| Find Similar · results | Back to photo | Product selection stays on each card |
| Shop bouquet details | Back to bouquets | Continue to preferences |
| Custom Bouquet · photo | Back to Home | Start without a photo, Explore Flower Composition |
| Flower Composition | Back to photo | Continue to estimated price |
| Estimated Price | Back to your flowers | Continue to preferences |
| Preferences · both paths | Back | Create enquiry |
| Pending enquiry | Home / enquiries, another bouquet / design | Cancel enquiry |
| Proposal ready | Same navigation | Cancel enquiry, Request changes, Confirm proposal |
| Request changes | Same navigation, Back to proposal | Cancel enquiry, Submit changes |
| Cancellation confirmation | Same navigation, Keep enquiry | Confirm cancellation |
| Completed / cancelled enquiry | Same navigation | No stale confirmation or cancellation actions |
| Staff inbox | Flower Materials | Row-specific Open enquiry stays on its row |
| Staff enquiry details | Back to enquiries | Cancel enquiry, Submit reply; flowers, amount and reply edit on this page |
| Staff cancellation confirmation | Back to enquiries, Keep enquiry | Confirm cancellation |
| Staff Flower Materials | Back to enquiries | Reload / Save / Add at the top right of the editor form |

Home's two journey cards, material Add/Remove/Replace controls, enquiry View status
and downloads retain their contextual locations. Your enquiries remains the
fourth navigation entry. The separate original technical/presentation workspaces
retain their layouts; optional action containers leave their default rendering
unchanged.

Preference and material forms retain native form submission. The single-message
change-request editor keeps its session key and requires an explicit Submit
changes button; typing never sends a request. Cancellation still requires its
confirmation. The current Staff flow uses explicit Submit reply in place of the
separate review/pricing/quotation pages; see [the current workflow](staff-inline-replies.md).
The original technical/presentation workspaces retain their own approval controls.

Verification: 199 regression tests passed. Existing Customer/Staff workflow tests
also inspect each page-level button's container: navigation belongs to the left
region and commands to the right region. Upload tests run the actual callback
before rendering, matching native Streamlit callback order. Runtime screenshots
and data-preservation checks are saved under `output/consistent-page-actions/`.
