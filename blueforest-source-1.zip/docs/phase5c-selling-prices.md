# Phase 5C — Customer DIY, dynamic selling prices and quotation versions

Pre-change Git checkpoint: **d9d2e95**. The existing SQLite database was backed
up to `output/phase5c-before.sqlite3` before migration. Phase 5C supersedes the
interrupted Phase 5B request: no inventory workflow or stock deduction was added.

## Customer experience

- Flower inspiration keeps its existing suggestion cards. The repeated
  per-flower explanation was removed. One short disclosure identifies the
  suggestions as a Demo Mode starting palette, without claiming verified AI
  identification or inferring stem quantities from photographs.
- Edit my bouquet shows a compact selling-price summary above the material
  editor: flower, integer quantity, pricing unit, unit selling price, line
  subtotal and total. Every add, removal, increment, decrement and replacement
  reruns the same calculation on this page. Continuing is not required to see
  the new price.
- Replace is a compact popover on each selected material. Replacing within the
  same pricing unit keeps the requested quantity; switching units starts at one
  with an explanation, avoiding an implied conversion from stems to portions.
- The estimate, submitted request, Staff price review and approved quotation use
  the same line calculation and captured unit prices.
- Eight existing flower images are unchanged. Twelve missing images retain the
  consistent card frame and a restrained sage placeholder. Existing Staff image
  upload/replacement remains available; unique upload paths and modification-time
  cache keys allow subsequent customer renders to pick up replacements.

## One selling-price source

`product_search/selling_pricing.py` owns the customer/shop/Staff calculation:

```text
total_selling_price_hkd = SUM(unit_selling_price_hkd × integer quantity)
packaging = labour = waste = markup = delivery = HK$0.00
```

Decimal amounts round half up to HKD cents. Quantities must be finite,
nonnegative whole numbers from 0 to 10,000 for every pricing unit. A zero
quantity contributes no line; a valid zero unit price is allowed. Missing prices,
unknown IDs, duplicate materials and conflicting units produce explicit
validation errors. A missing price is never silently replaced with zero.

The required example calculates **HK$216.00**:

| Material | Quantity | Unit selling price | Line total |
| --- | ---: | ---: | ---: |
| FM02 White Rose | 5 stems | 18.00 | 90.00 |
| FM04 Blue Hydrangea | 2 stems | 45.00 | 90.00 |
| FM06 Peach-Pink Carnation | 3 stems | 12.00 | 36.00 |

The main Staff workflow reuses the existing review editor, deterministic
quotation template, reviewer-name requirement, explicit approval and stale-draft
invalidation. Its price field is calculated and read-only. A price revision is
made by changing composition/quantities, rather than entering an unrelated
override. The legacy technical and presentation workspaces retain their original
isolated evaluation/pricing behavior for compatibility; they do not calculate
new customer-shop quotes.

## Material migration and preservation

Storage remains **`data/flower_materials.sqlite3`**; no second material catalog
was created. A new nullable TEXT column, **unit_selling_price_hkd**, is the
authoritative selling-price field.

When upgrading a database that does not yet have this column, a single additive
migration copies each current `selling_price_hkd` value when supplied, otherwise
its current legacy `unit_cost_hkd` value. It reads the current database rather
than an older seed or a preview CSV. Existing names, images, units, prices,
Active flags, reserved stock fields and timestamps are preserved. Legacy price
columns remain intact for historical records and the isolated technical demo;
the customer/shop pricing function does not use them after migration.

Staff → Flower Materials now edits **Unit selling price (HKD)**. Future DIY and
shop calculations read that field. A later restart neither resets a Staff edit
nor refills a deliberately missing selling price. Fresh installations still use
the original insert-only material seeding.

## Four shop bouquet BOMs

The supplied files were found at:

- `import_staging/Bouquet_BOM_Draft.csv`
- `import_staging/Bouquet_Products_4.csv`

They contain literal line-break markers; normalized runtime copies are versioned
as `data/bouquet_bom_seed.csv` and `data/bouquet_products_seed.csv`. All four
products and all **17 BOM lines** are imported into the existing SQLite database.

| Table | Contents |
| --- | --- |
| shop_bouquets | product_id PK, names, local image path, Active flag, draft status, notes, updated_at; **no price column** |
| bouquet_bom | product_id + material_id PK, integer quantity, catalog pricing unit |
| bouquet_seed_imports | one-time import marker per product, so a Staff-deleted seed line is not restored on restart |

Products are inserted only when missing. Existing saved compositions are not
replaced by seed lines. Staff → **Shop Bouquets** edits each composition, previews
its recalculated total and saves transactionally, with stale-edit protection.
Recipes remain labelled **simulated drafts requiring florist verification**.
Neither their species nor quantities are treated as measured photo evidence.

The CSV preview prices differ from the existing database for five materials.
Preserving the current database therefore produces:

| Product | Preserved current catalog | Supplied preview reference |
| --- | ---: | ---: |
| A01 | 198.00 | 198.00 |
| A02 | 246.00 | 264.00 |
| B01 | 250.00 | 282.00 |
| B02 | 189.00 | 223.00 |

Differences come from FM17 (12 versus preview 30), FM15 (20 versus 28), FM18
(8 versus 12), FM13 (22 versus 28) and FM12 (28 versus 35). These values were
**not overwritten**. Tests additionally confirm all four preview totals are
calculated correctly if those preview unit prices are explicitly applied in an
isolated test database. No total is hardcoded.

The four product images were copied unchanged from the supplied asset archive
to `data/images/shop_bouquets/A01.jpg`, `A02.jpg`, `B01.jpg`, `B02.jpg`. Their
hashes match the archive metadata. They were not generated or downloaded; their
public-use rights remain unverified as stated in the supplied archive.

The original eight-photo CLIP/FAISS reference index, embedding model, retrieval
code, distances and Top 3 ordering are unchanged. Search results continue to
show those ranked **photo references**, without their old fixed listing prices.
The four provided shop designs appear in a separate selection section with live
BOM totals. This preserves actual retrieval rankings without fabricating a
mapping between the old reference IDs and the new four product IDs. Pre-5C
enquiries referencing an older product keep their historical selection.

## Quote snapshots and revisions

Saving an estimate captures the material definitions and computed price details.
Submission stores a deep copy in the existing enquiry's `price_snapshot` and
appends it to SQLite:

```text
quotation_snapshots(
  snapshot_id TEXT PRIMARY KEY,
  enquiry_reference TEXT NOT NULL,
  kind TEXT NOT NULL,             -- original, proposal_1, proposal_2, ...
  snapshot_json TEXT NOT NULL,
  created_at TEXT NOT NULL
)
```

Snapshots contain material IDs, names, quantities, units, unit selling prices,
line subtotals, zero charges and total. They contain no procurement-cost or
profit fields. The append operation is idempotent; it never replaces an original
snapshot. Captured request material prices are used for Staff composition
revisions, so catalog changes do not silently reprice submitted quotations.

Approved revisions use the existing proposal/version history and append their
own snapshot. **Quotation versions** shows the original and reviewed versions
in both roles. Editing a saved review invalidates its approval; a fresh named
approval is required to publish the revision. Original request records and
previous proposals remain intact.

Pre-5C requests without the new snapshot retain their captured original price.
Staff must explicitly choose **Prepare catalog-priced revision** to move one
into the new pricing flow. Historical prices are not retroactively reconstructed
from today's catalog.

Enquiries/photos themselves remain in the existing browser-session queue.
Price snapshots and catalog/BOM records are persistent; this phase does not
introduce account-level enquiry recovery or authentication.

## Changed files

New implementation:

- `product_search/selling_pricing.py` — shared calculation and quantity validation.
- `product_search/shop_bouquets.py` — insert-only BOM import, shop projections and edits.
- `product_search/app/selling_prices.py` — live summary and selling-only Staff pricing.
- `product_search/app/shop_bouquets.py` — Staff composition editor.
- `data/bouquet_bom_seed.csv`, `data/bouquet_products_seed.csv`, four shop images.
- `tests/test_selling_prices.py` — focused unit and workflow coverage.
- `docs/phase5c-selling-prices.md` — this guide.

Updated:

- `product_search/material_store.py` — additive canonical-price migration and snapshots.
- `product_search/app/customer_app.py` — same-page pricing, short disclosure,
  shop product selection, snapshots, historical requests and Staff entry points.
- `product_search/app/customer_presenter.py` — use shared selling-price calculation.
- `product_search/app/enquiry_session.py` — snapshot persistence and proposal projection.
- `product_search/app/flower_materials.py` — canonical price editor and integer replacements.
- `product_search/app/custom_bouquet.py` — optional integer-only review and clearer Staff labels.
- `product_search/app/bouquet_pricing.py` — extract/reuse existing approval controls.
- `product_search/bouquet_pricing.py` — optional zero-price support for new selling-only quotes;
  default legacy behavior unchanged.
- `product_search/app/customer.css` — compact price panel and consistent placeholder outline.
- Existing customer/material tests — new formula, product IDs and composition-based revisions.
- `README.md`, `PRODUCT.md`, previous phase guide — current behavior and supersession notes.

## Verification — 26 October 2026

Baseline: **165 tests passed**. Final regression: **177 tests passed**, including
12 new selling-price tests. Commands:

```bash
.venv/bin/python -m unittest discover -s tests
.venv/bin/python -m evaluation.presentation_demo
.venv/bin/python -m evaluation.custom_bouquet_pricing
```

Coverage includes live add/remove/quantity/replacement, the exact HK$216 example,
estimate equality, BOM/DIY equivalence, alternate preview-price inputs, Staff
price and recipe editing, integer/price validation, additive migration, removed
BOM lines surviving a fresh Python process, manual design from an uploaded-file
callback, named Staff approval and immutable original/revised snapshots. File
upload tests use the actual callback with the uploaded-file interface because
AppTest has no native file-upload driver.

All 20 original database rows were compared with the pre-migration backup:
every pre-existing field/value, price, image path and timestamp was preserved.
The original eight material images and newly copied four bouquet images retain
their original hashes. The real offline CLIP/FAISS check returned the same
rankings for both prepared photos, and the legacy quotation smoke test passed
with zero HTTP requests.

An actual fresh Streamlit process on **http://127.0.0.1:8504** was also exercised
through the browser. A prepared reference sample was selected, the six-material
starter plan edited to White Rose × 5, Blue Hydrangea × 2 and Carnation × 3,
and **HK$216 appeared on the DIY page immediately**. Estimate and submission
retained HK$216. Staff opened the request, saved the review, checked the identical
breakdown, generated a draft and completed named approval. The customer then
saw the HK$216 proposal awaiting confirmation and separate original/reviewed
versions. SQLite contains both captured HK$216 snapshots for runtime demo
request **BF-B-DA4A5CAC**. The browser test used a prepared sample rather than
interacting with the operating-system file picker.

Runtime screenshot: `output/phase5c-live-price-216.png`. Database backup, smoke
reports and screenshots stay in ignored `output/`.

No inventory, deduction, supplier, real-order/payment, generated-flower-image,
new AI integration, or new procurement/profit calculation was implemented.
