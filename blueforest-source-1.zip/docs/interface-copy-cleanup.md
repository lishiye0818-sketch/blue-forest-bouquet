# Interface copy cleanup — blue forest florist

Checkpoint: `158d172`, preserving the completed Phase 4F role-switching work.

| Before | After |
| --- | --- |
| Blue Forest / AI Bouquet Copilot header, old footer and browser title | Lowercase blue forest florist in the header, footer and browser title; existing two-line serif wordmark layout retained |
| Original technical tools & Live AI panel, its explanatory paragraph and long buttons in the main Staff workflow | Main panel removed. Tools and Presentation links live inside the Staff profile menu; existing original applications remain accessible |
| Demo Mode — Predefined Results, No AI Inference prominent Staff caption and customer suggestion details | Short Demo · Simulated results caption; full original provenance remains in stored records and quotation/review exports |
| Status followed by Local demo enquiry | Status alone |
| Long dashboard demo/authentication caption and duplicate role-menu explanation | No dashboard repetition; compact Demo view · No login remains inside the profile menu |
| Repeated explanation that the ordering options are independent | Existing equal choices and descriptions retained; duplicate trailing caption removed |
| Existing-bouquet note explaining why custom material calculation is unnecessary | Redundant note removed; selected product and its normal review action retained |
| Mock Data · Submitted timestamp | Submitted timestamp |
| Create mock order enquiry / Your mock enquiry is ready | Create enquiry / Your enquiry is ready |
| Long local-only enquiry notes | Demo enquiry · Not sent |
| UI tests checking the previous copy | Same workflow scenarios now check concise disclosures, preserved original provenance, new visible brand, absence of the removed Staff copy and continued access to the relocated tools |
| Product and README guidance reflecting the old visible branding/location | Current shop name, concise-copy guidance and Staff-menu tool location documented |

No recognition, search, pricing, approval or queue logic was changed. Original
technical applications and exported records retain their original detailed
provenance. Photography attribution and short simulation labels remain.

Verification:

- All **130 regression tests passed in 63.058 seconds**.
- Focused customer suite: **13 passed**.
- Actual browser checks confirmed all three attached phrases absent from the
  main Staff review page, the new branding visible and the original approved
  request/photo/quantities retained across role switching.
- Existing technical and presentation destinations remain in the Staff menu.
- Desktop and 411 px mobile branding verified; no mobile horizontal overflow.
- `git diff --check` passed. No models installed or paid APIs called.

Logs: `output/copy-cleanup-regression.log`,
`output/copy-cleanup-customer-tests.log`.

Screenshots: `output/copy-cleanup-ux/home-desktop.png`, `home-mobile.png`,
`staff-enquiry.png` and `staff-review.png`.
