# Custom Bouquet — Phase 3A

Solution B defaults to a zero-cost, predefined Demo Mode and retains real
multimodal recognition in an explicitly selected Live AI Mode. Both support
human corrections. Solution A remains
a separate **Find Similar Bouquets** tab with its original CLIP/FAISS retrieval.
The Demo extension adds internal material-cost drafts. [Phase 3B](mock-pricing.md)
extends saved florist quantities with full Mock Data cost inputs, a reviewed
selling price and a deterministic customer quotation requiring florist approval.
No training, detection model or automatic stem inference is added.

The pre-change workspace is saved in Git checkpoint **`40fd1aa`**. The earlier
working visual-search checkpoint is **`10c1025`**. No changes to Solution A's app
function, catalog, original photos, embedding/search modules or indexes are needed.

## Run

Use Python 3.12+ and the existing environment:

```bash
.venv/bin/python -m streamlit run product_search/app/streamlit_app.py
```

For a fresh checkout, `uv sync` installs the base app. Use `uv sync --extra image`
for Solution A's CLIP image search; Solution B adds no dependencies.

Demo Mode needs no API key or internet connection. Choose a sample and click
**Load demo results**; unregistered photos use manual review. Read the
[Demo Mode guide](demo-mode.md) for fixture matching, exports and mock cost drafts.

For **Live AI Mode** only, copy `.env.example` to `.env` if it does not already
exist. Set:

```dotenv
OPENROUTER_API_KEY=your_key_here
BOUQUET_VISION_MODEL=openai/gpt-4.1-mini
```

Keep `.env` private and ignored by Git. An exported environment variable takes
precedence over `.env`. Restart Streamlit after changing credentials, model or
Python module code. A replacement vision model/provider must accept image input
and strict JSON-schema outputs. Unsupported routes fail visibly; the app does not
substitute predefined demo observations in Live AI Mode. Network requests use a 5-second connection
and 60-second read timeout, with no automatic retries or repeated billable calls.

The integration follows OpenRouter's [structured-output contract](https://openrouter.ai/docs/guides/features/structured-outputs)
and uses its [GPT-4.1 Mini route](https://openrouter.ai/openai/gpt-4.1-mini).
Provider/model access and account credits must be checked with a live request.

## Use

1. Open **Custom Bouquet**. In **Analysis mode**, select **Live AI Mode** for the
   workflow below, or keep the default Demo Mode to load samples without API calls.
   Upload a complete JPEG/PNG bouquet photo, up to
   15 MB and 20 megapixels. Invalid images display an error and disable analysis.
2. Click **Identify flowers**. This sends one resized image plus catalog names,
   categories, counting units and identification cues to OpenRouter and its
   serving model provider. Reference photos and mock costs are not model inputs.
3. Inspect the uploaded photo alongside the AI observation table: names,
   reference thumbnails, approximate visible counts, counting units, filler
   usage, qualitative confidence, uncertainty and review flags. Unknown means
   unreliable or out-of-catalog identity; a blank count means no reliable count.
4. Correct **Flower**, **Reviewed visible count** or **Filler usage** in the
   separate review table. Add missed materials or delete unwanted suggestions.
   The original AI observations remain visible and unchanged.
5. Enter **Florist quantity** independently, in the material's pricing unit
   shown below the editor. This starts blank. Whole stems are required, while
   bunch/portion quantities can be fractional. Clear head counts for fillers
   and Unknown; clear filler usage for ordinary flowers. Unknown quantities stay
   blank until the material and its unit can be resolved.
6. **Save florist review** validates and keeps corrections in the current browser
   session. Download the analysis or saved review as JSON if a durable copy is
   needed. A new/removed photo, mode switch, catalog change, live model change or new analysis
   clears the previous analysis/review. Failed reanalysis also clears stale data.

Without a key, Demo Mode, catalog browsing and manual review remain available. Editing,
saving, downloading and switching tabs never automatically call the model.
Photos are oriented, resized to a maximum 1600-pixel side, flattened onto white
and encoded as JPEG without EXIF metadata. The app does not save uploads to disk.
Provider handling follows the selected account/provider's policies.

## Catalog and extension

`data/flower_materials_mock.json` is independent of product/bouquet search data.
The initial seven types are **Rose, Lily, Hydrangea, Lisianthus, Carnation, Tulip,
and Baby's breath**. Unknown is a reserved fallback rather than a priced material.

| Catalog field | Meaning |
| --- | --- |
| `id`, `name` | Stable unique model ID and display name; `unknown` / `Unknown` are reserved |
| `reference_image` | Local permitted image under `data/images` |
| `reference_note` | Context about the particular reference and mixed arrangements |
| `visual_cues` | Identification notes supplied to the vision model |
| `category` | `flower` or `filler` |
| `counting_unit` | `flower_head`, `flower_cluster` or `usage_category` |
| `pricing_unit` | Future material quantity unit, e.g. `stem`, `bunch`, `portion` |
| `mock_unit_cost_hkd` | Finite nonnegative synthetic cost for internal mock material drafts |
| `reference_credit`, `reference_source_url` | Attribution/license and source page |

To expand to 30–40 types, add rows with these fields and permitted local reference
photos. The model schema, prompt and editable type options derive from the file;
no training, detector installation or search-index rebuild is required. Validation
rejects duplicate/reserved IDs, invalid costs/units and missing local images.

Existing bouquet references retain their [original credits](../data/IMAGE_CREDITS.md).
The new lily, lisianthus and baby's-breath references have [separate credits](../data/MATERIAL_IMAGE_CREDITS.md)
and source/license/hash records in `data/material-image-sources.json`. Garden
references and mixed arrangements illustrate appearance; they are not supplier
standards or verified fine-grained cultivar references.

## Structured output and counting rules

The model must return an object with `flowers`, `notes` and
`human_review_required`. Every observation contains:

| JSON field | Meaning |
| --- | --- |
| `material_id` | Loaded catalog ID, or `unknown` |
| `visible_heads` | Positive approximate integer for visible heads/clusters, or `null`; never actual stems |
| `counting_unit` | Catalog counting unit; `unresolved` for Unknown |
| `usage_category` | Fillers: `light`, `moderate`, `heavy`, `uncertain`; otherwise `null` |
| `confidence` | Model's `low`, `medium` or `high` self-assessment; not a calibrated score |
| `uncertainty` | Evidence, overlap, occlusion and possible identity/count problems |
| `review_required` | Human review flag; enforced as `true` locally |
| `review_flags` | Relevant issues: `occlusion`, `possible_misidentification`, `count_uncertain`, `unknown_material`, `filler_usage_estimate`, `heads_not_stems` |

For hydrangeas, `visible_heads` counts whole visible clusters, never the tiny
florets. For baby's breath and any added filler types, `visible_heads` must be
`null`: rough usage means a few accents (`light`), spread throughout (`moderate`),
a dominant filler mass (`heavy`), or an unreliable estimate (`uncertain`). These
categories never imply numbers of bunches or portions. Unknown also has a null
count and unresolved unit. A photo without flowers can return an empty array.

The request uses strict schema output and requires provider parameter support.
Local validation also rejects unsupported/duplicate IDs, inconsistent counting
units, numeric filler counts, invalid confidence/flags, missing uncertainty,
malformed JSON, refusals and truncated responses. Every observation still requires
human review even if the model incorrectly clears a flag. These checks establish
format and unit consistency, **not recognition accuracy**.

## Verify and evaluate

Run the zero-cost Demo smoke check (all HTTP and live-inference attempts are blocked):

```bash
.venv/bin/python -m evaluation.custom_bouquet_demo
```

Run the basic suite (API responses in Live unit tests are mocked):

```bash
.venv/bin/python -m unittest discover -s tests -v
```

Prepare six real licensed images without credentials or API calls:

```bash
.venv/bin/python -m evaluation.custom_bouquet_smoke
```

With credentials configured, run real inference on those images:

```bash
.venv/bin/python -m evaluation.custom_bouquet_smoke --live
```

`--live` makes six billable API requests: one rose bouquet, three mixed bouquets,
one unsupported lavender bouquet and one filler close-up. Reports include image
hashes, prepared sizes, returned JSON, latency and errors in
`output/phase3a-photo-smoke.json` (ignored local output). Missing credentials are
explicitly recorded and return exit code 2; a skipped run is never reported as a
successful live test. Preparation-only runs do not claim recognition occurred.

Inspect each response against its photo, especially calla lily vs. true lily,
carnation vs. lisianthus, hydrangea clusters, filler usage and Unknown. Source-title
suggestions in the evaluator are **not** verified ground-truth labels or counts.
For accuracy evaluation, have a florist independently label identities and visible
head/cluster counts, then compare results. Record missed types, wrong types,
Unknown usage, count errors, occlusion and latency separately from stem quantities.
Include difficult mixed/occluded images and a real no-flower negative.

Current Demo extension verification is in [demo-mode.md](demo-mode.md).
The initial Phase 3A validation results and remaining limits are recorded in
[phase3a-validation.md](phase3a-validation.md). Reference photos do not cover every
cultivar; hidden flowers cannot be counted reliably, and valid JSON can still be
visually wrong. Supplier pricing, inventory, margins, labour and final quotations remain future work;
Phase 3B now supports full mock cost-plus pricing and locally finalized mock
customer quotations after explicit florist approval. See [mock-pricing.md](mock-pricing.md).
