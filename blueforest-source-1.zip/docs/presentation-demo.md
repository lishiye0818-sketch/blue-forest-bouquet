# Phase 4B presentation demo

One selected photo drives both solutions. The presentation has five guided steps:
**Upload or select photo → Top 3 bouquets → Flower composition → Florist review
and cost calculation → Customer quotation**. Review and calculation are two
parts of step 4, retaining the existing save boundary.

## Start the presentation

From `/Users/lili/Desktop/BlueForest-AI`:

```bash
.venv/bin/python -m streamlit run product_search/app/presentation_app.py --server.port 8504
```

Open <http://localhost:8504>. Click either **Try Demo Sample** button to load the
original registered JPEG directly. You can also use **Upload Bouquet Photo** for
a JPEG or PNG, including files from `data/images/presentation/uploads/`:

| Upload file | Prepared name | Demonstration materials |
|---|---|---|
| 01-peach-harmony.jpg | Peach Harmony | Rose, Calla lily, Dahlia, Craspedia, Tulip, Mixed greenery |
| 02-sunshine-garden.jpg | Sunshine Garden | Rose, Sunflower, Gerbera, Carnation, Mixed greenery |

Both are complete licensed photographs, resized without cutting off the bouquet
composition. No image-generation service was used. The preparation plan is
illustrative; the smaller white blooms in Peach Harmony are represented as
Tulip for the demonstration and still require florist verification. Counts
are approximate predefined examples, not botanical ground truth.

The presentation uses the **already cached CLIP model**. It never downloads model
weights, calls a paid API or invokes Ollama. If the local model cache is missing,
it reports the problem instead of downloading anything. Existing caches live
under `output/huggingface/hub/`; `indexes/presentation-clip-local/` links the cached
configuration/tokenizer and safetensors weights into one offline load directory.
No `.env` or API key is needed for the presentation.

## Present either bouquet

1. **Upload or select photo.** Click **Try Demo Sample** under Peach Harmony or
   Sunshine Garden, or upload your own photo. The selected photo is previewed;
   click **Find Similar Bouquets**. Both solutions receive the same original bytes.
2. **Top 3 bouquets · Solution A.** Show the three genuinely ranked references,
   consistent image sizes, bouquet names, Mock Data prices and photo attribution.
   Click **View Flower Composition**.
3. **Flower composition · Solution B.** Show the compact flower cards, visible
   estimates or filler usage, independent florist plan and mock unit costs. The
   banner says **Demo Mode — Predefined Results, No AI Inference**. Uncertainty
   notes are available in an expander. Click **Review Florist Quantities**.
4. **Florist review and cost calculation.** Edit the prepared classroom plan,
   then **Save florist review** and **Calculate Mock Costs**. Saving remains
   mandatory. The calculation shows itemized mock costs alongside the reviewed
   price and delivery/collection notes. Expand **Adjust mock costs & customer
   budget** for packaging, labour, waste, overhead, markup, delivery and budget.
   Material quantities and unit costs remain available in their own expander.
   Click **Prepare Final Mock Quotation** when the reviewed details are ready.
5. **Customer quotation.** Generate the existing deterministic draft, review its
   wording, enter the reviewing florist name and explicitly confirm the review
   checkbox before finalizing. Download the finalized mock quotation as text or
   JSON. Nothing is sent to a customer.

Use **Back** to revisit an earlier step. Open **Change bouquet photo** to upload a replacement, select the other sample
or clear the selected photo. A photo change clears retrieval results, the florist review,
pricing and prior approval. Review edits invalidate the quotation; price,
delivery or draft changes require fresh approval. Saved review quantities survive
step navigation. Both solutions record the same upload SHA-256.

For an unknown uploaded file, Solution A still performs real retrieval. Solution
B supplies no invented composition: select materials manually in Florist Review.
Unresolved or missing quantities block a final customer quotation.

## Expected pricing with the prepared plans

With packaging HK$20, labour HK$50, overhead HK$15, 10% material waste, 50%
production-cost markup and no delivery:

| Mock Data calculation | Peach Harmony | Sunshine Garden |
|---|---:|---:|
| Material cost | HK$457.00 | HK$246.00 |
| Waste | HK$45.70 | HK$24.60 |
| Total estimated production cost | HK$587.70 | HK$355.60 |
| Suggested selling price | **HK$881.55** | **HK$533.40** |
| Estimated profit after listed costs | HK$293.85 | HK$177.80 |
| Markup / profit margin | 50% / 33.33% | 50% / 33.33% |

The prepared quantities are independent recipes; visible heads do not determine
stem quantities. In Peach Harmony, for example, six visible Tulip heads are
separate from a mock plan of five stems. Supplier prices, availability, exact
identities/counts and actual production quantities are unverified.

## Real search versus simulated composition

Solution A uses the existing `ImageEmbeddingGenerator`, normalized CLIP image
features and the existing FAISS `VectorDatabase.search_by_image(k=3)`. The new
eight-photo CSV catalog is `data/presentation_bouquets.csv`. Both uploaded sample
photos are excluded from that reference catalog, including their exact hashes.
There is no sample-to-result mapping or forced ordering. Query vectors are
computed from the uploaded photo; cached results are keyed by its bytes and the
catalog fingerprint. Replacing a reference image invalidates the index.

The observed rankings on this Mac were:

- Peach Harmony: Peach & Calla Harmony, Hydrangea Blush, Sunset Mixed Bouquet.
- Sunshine Garden: Spring Festival, Golden Garden Bouquet, Sunset Mixed Bouquet.

Phase 4B replaces the vase/table rose reference with a licensed pink-rose and
sunflower photograph (PattayaPatrol, CC BY-SA 4.0). The catalog remains eight
independent photographs, with both upload samples excluded. This broadens the
reference coverage without changing CLIP, FAISS, or result ordering. The new
photo is an additional candidate; it is not forced into either Top 3.

These observations document the real run; they are not programmed outputs or a
claim of retrieval accuracy. CLIP reflects overall appearance rather than a
verified matching flower recipe.

Solution B uses the existing `load_demo_samples` / `match_demo_photo` mechanism,
with a separate `data/presentation_demo.json`. Only the two exact original JPEGs
match their SHA-256 fixtures; filenames can change, image bytes cannot. Editing,
re-encoding or screenshotting a sample creates an unknown file and invokes the
manual path. `data/presentation_materials.json` extends copies of the original
seven materials for this view; the original catalog and six demo fixtures remain
unchanged. All original mock unit costs are retained.

The florist editor and Phase 3B UI/calculations/quotation functions are reused,
with presentation options for stage navigation and concise display. The pricing
and quotation business logic was not rebuilt.

## Full workspace and Live AI

Open the sidebar and enable **Full workspace** for the original Find Similar
Bouquets and Custom Bouquet tabs, including the original Demo Mode and separate
Live OpenRouter mode. Switching views resets the current presentation review.
The original entry point also remains available:

```bash
.venv/bin/python -m streamlit run product_search/app/streamlit_app.py
```

Keep the presentation in its default view during class to avoid API calls.
Live AI requires deliberate use of the existing separate controls and credentials.

## Verification

All **109 tests passed** on 25 October 2026: all 104 original tests, unchanged,
plus five presentation photo-source and navigation regressions. Actual browser checks completed
both demo-button workflows through final mock quotation approval: Peach Harmony
in desktop Chrome and Sunshine Garden in the narrow in-app browser (333 px).
The earlier Phase 4 acceptance also verified native file upload.

See [Phase 4B changes and verification](phase4b-ux.md) for the current results.

```bash
.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python -m evaluation.presentation_demo
```

The smoke run blocks HTTP requests, loads only existing local CLIP files, indexes
all eight reference photos, queries both real uploads and passes their separate
prepared florist plans through the existing Decimal pricing, deterministic draft
and named mock-finalization functions. It writes
`output/phase4-presentation-smoke.json`. Its finalizations are explicitly automated
demo tests, not actual florist approvals.

Streamlit tests exercise both complete five-step workflows with real CLIP/FAISS,
direct sample buttons, the same shared photo, simulation labels, save-before-pricing, approval gates,
photo replacement/removal/invalid-image cleanup, unknown-photo manual review,
quantity and price edits, step navigation, and access to the preserved full
workspace/Live mode. File uploads and editor cell events are supplied at the
widget boundary because Streamlit AppTest does not drive native file dialogs or
data-editor cells. Business logic and retrieval are real, with network blocked.

See [photo attribution and derivative licenses](../data/PRESENTATION_IMAGE_CREDITS.md)
and `data/presentation-image-sources.json` for source URLs, image hashes,
dimensions and resizing/cropping details. No new Python dependencies, model
downloads, paid inference calls or custom training were used.
