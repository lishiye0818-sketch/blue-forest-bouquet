"""Prepare exactly the existing CLIP artifacts during image build, never at runtime."""

import argparse
import hashlib
import json
from pathlib import Path


def digest(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def prepare_model(destination, manifest, *, download=None, verify_only=False):
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    for name, specification in manifest["files"].items():
        if Path(name).name != name or name.startswith("."):
            raise ValueError("Model filenames must be plain filenames.")
        target = destination / name
        if target.is_file() and digest(target) == specification["sha256"]:
            continue
        if verify_only:
            raise ValueError(f"Missing or changed model file: {name}")
        if download is None:
            from huggingface_hub import hf_hub_download
            download = hf_hub_download
        download(repo_id=manifest["model_id"], filename=name, revision=specification["revision"],
                 local_dir=str(destination))
        if not target.is_file() or digest(target) != specification["sha256"]:
            raise ValueError(f"Model checksum mismatch: {name}")
    return destination


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("destination", type=Path)
    parser.add_argument("--manifest", type=Path, default=Path(__file__).with_name("model-manifest.json"))
    parser.add_argument("--verify-only", action="store_true")
    options = parser.parse_args()
    prepare_model(options.destination, json.loads(options.manifest.read_text()), verify_only=options.verify_only)
    print("CLIP artifacts verified.")
